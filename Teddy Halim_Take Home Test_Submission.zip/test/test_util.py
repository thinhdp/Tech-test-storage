import unittest
from unittest.mock import patch

from src.util import get_splitted_input, get_stripped_input, get_xy_from_dimension


class TestInput(unittest.TestCase):
    def test_get_xy_from_dimension(self):
        self.assertEqual(get_xy_from_dimension([10, 10]), (10, 10))

    def test_invalid_dimension_input(self):
        with self.assertRaises(ValueError):
            get_xy_from_dimension([-1, -1])

    @patch("builtins.input")
    def test_get_stripped_input(self, mock_input):
        mock_input.return_value = "  FFR   "
        self.assertEqual(get_stripped_input(mock_input), "FFR")

    @patch("builtins.input")
    def test_get_spliited_input(self, mock_input):
        mock_input.return_value = "  1 2 N   "
        self.assertEqual(get_splitted_input(mock_input), ["1", "2", "N"])
