import unittest

from src.car import Car


class TestCar(unittest.TestCase):
    # Set up the car for the test with fixed details below instead of asking user input
    def setUp(self):
        self.car = Car("A", 1, 2, "N", "FFRL")

    def tearDown(self):
        del self.car

    def test_rotate_left(self):
        self.car.rotate_left()
        self.assertEqual(self.car.direction, "W")

    def test_rotate_right(self):
        self.car.rotate_right()
        self.assertEqual(self.car.direction, "E")

    def test_move(self):
        self.car.move()
        self.assertEqual((self.car.x_position, self.car.y_position), (1, 3))
