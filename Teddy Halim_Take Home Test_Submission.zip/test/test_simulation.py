import unittest

from src.car import Car
from src.simulation import Simulation


class TestSimulation(unittest.TestCase):
    # Set up the simulation for the test with a 10x10 grid instead of asking user input
    def setUp(self):
        self.simulation = Simulation(10, 10)

    def tearDown(self):
        del self.simulation

    def test_add_car_to_simulation(self):
        car1 = Car("A", 1, 2, "N", "FFR")
        self.simulation.add_car_to_simulation(car1)
        car2 = Car("B", 7, 8, "W", "FFL")
        self.simulation.add_car_to_simulation(car2)
        self.assertEqual(self.simulation.cars, {"A": car1, "B": car2})

    def test_process_command(self):
        car1 = Car("A", 1, 2, "N", "FF")
        self.simulation.add_car_to_simulation(car1)
        self.simulation.process_command(car1, 0)
        self.assertEqual(
            (
                self.simulation.cars.get("A").x_position,
                self.simulation.cars.get("A").y_position,
            ),
            (1, 3),
        )

    def test_run_simulation(self):
        car1 = Car("A", 1, 2, "N", "FFRFFFFRRL")
        self.simulation.add_car_to_simulation(car1)
        car2 = Car("B", 7, 8, "W", "FFLFFFFFFF")
        self.simulation.add_car_to_simulation(car2)
        car3 = Car("C", 0, 0, "N", "FF")
        self.simulation.add_car_to_simulation(car3)
        self.simulation.run_simulation()
        self.assertEqual(
            str(self.simulation.cars.get("A")),
            """- A, collides with B at (5,4) at step 7""",
        )
        self.assertEqual(
            str(self.simulation.cars.get("B")),
            """- B, collides with A at (5,4) at step 7""",
        )
        self.assertEqual(str(self.simulation.cars.get("C")), """- C, (0,2) N""")

    def test_check_collision(self):
        car1 = Car("A", 1, 2, "N", "FF")
        self.simulation.add_car_to_simulation(car1)
        car2 = Car("B", 1, 4, "S", "FF")
        self.simulation.add_car_to_simulation(car2)
        self.simulation.run_simulation()
        self.assertEqual(car1.collide, car2.collide)

    def test_is_car_out_of_bounds(self):
        car = Car("A", 1, 10, "N", "FF")
        self.assertTrue(self.simulation.is_car_out_of_bounds(car))
        car = Car("A", 0, -1, "N", "FF")
        self.assertTrue(self.simulation.is_car_out_of_bounds(car))

    def test_validate_initial_position(self):
        self.assertTrue(self.simulation.validate_initial_position(["1", "2", "N"]))
        self.assertFalse(self.simulation.validate_initial_position(["1", "10", "N"]))
        self.assertFalse(self.simulation.validate_initial_position(["a", "B", "N"]))
