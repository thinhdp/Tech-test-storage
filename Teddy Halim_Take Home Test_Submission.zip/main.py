import sys

from src.car import Car
from src.simulation import Simulation
from src.util import ask_dimension


def main():
    print("Welcome to Auto Driving Car Simulation\n")
    width, height = ask_dimension()
    simulation = Simulation(width, height)
    print(f"You have created a field of {simulation.width} x {simulation.height}\n")
    command = Simulation.first_prompt()
    while True:
        try:
            # This is for when user want to add a car
            if int(command) == 1:
                # Ask and validate the name of the car
                car_name = simulation.ask_car_name()
                
                # Ask and validate the initial position of the car and separate it into 3 attributes
                initial_position = simulation.ask_car_position(car_name)
                x, y, direction = (
                    int(initial_position[0]),
                    int(initial_position[1]),
                    initial_position[2],
                )

                # Ask and validate the car command
                command = simulation.ask_car_command(car_name)

                simulation.add_car_to_simulation(
                    Car(car_name, x, y, direction, command)
                )

                print(f"\nYour current list of cars are:\n{simulation} \n")
                command = Simulation.first_prompt()
            # This is for when user want to run the simulation
            elif int(command) == 2:
                print(f"\nYour current list of cars are:\n{simulation} \n")
                simulation.run_simulation()

                after_command = Simulation.second_prompt()
                # If user want to start over, call the main function again
                if int(after_command) == 1:
                    main()
                # If user want to exit, call the exit function
                elif int(after_command) == 2:
                    print("Thankyou for running the simulation. Goodbye!")
                    sys.exit(0)
            else:
                print("Invalid response. You can only enter 1 or 2 as your options")
                command = Simulation.first_prompt()
        # Catch any type of error. Probably better if we can catch the specific error so we don't have a generic exception
        except Exception:
            print("Invalid response. You can only enter 1 or 2 as your options")
            command = Simulation.first_prompt()


if __name__ == "__main__":
    main()
