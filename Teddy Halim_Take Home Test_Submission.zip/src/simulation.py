import re
from typing import List

from src.car import Car
from src.util import (
    get_splitted_input,
    get_stripped_input,
)


class Simulation:
    """
    Creating the simulation for multiple cars to move around the grid

    Parameters
    ----------
    width: int
        The width of the grid. If the width is 10 then the maximum x position is 9 since the start is 0
    height: int
        The height of the grid. If the height is 10 then the maximum y position is 9 since the start is 0
    """

    def __init__(self, width: int, height: int):
        self.width: int = width
        self.height: int = height
        self.cars: dict[str, Car] = {}

    def add_car_to_simulation(self, car: Car):
        """
        Add car to simulation. The checks here is a safeguard.
        Input check is already done on the input so the Car object in the parameter should already have been validated

        Parameters
        ----------
        car: Car
            The Car object to be added to the simulation. The details comes from user input

        """
        if car.name in self.cars:
            # We have already added the check on the input, this shouldn't be reached at all by the code
            print(
                f"Car with name {car.name} already exist in the field. Please choose different name"
            )
            return
        elif self.is_car_out_of_bounds(car):
            # We have already added the check on the input, this shouldn't be reached at all by the code
            print("Car cannot be added because the position is out of bounds")
            return
        self.cars[car.name] = car

    def process_command(self, car: Car, count: int):
        """
        Process command for each car and check if the car is out of bounds or have collision after moving.
        If car is stopped or no more commands available for the car, then return

        Parameters
        ----------
        car: Car
            the car object that process the command
        count: int
            the number of iteration that the simulation have gone through
        """
        commands = car.commands

        if car.stopped:
            return
        if not commands:
            car.stopped = True
            return

        command = commands[0]
        initial_x, initial_y = car.x_position, car.y_position

        if command == "L":
            car.rotate_left()
        elif command == "R":
            car.rotate_right()
        elif command == "F":
            car.move()
        car.commands = commands[1:]

        if self.is_car_out_of_bounds(car):
            car.x_position, car.y_position = initial_x, initial_y
        self.check_collision(car, count)

    def run_simulation(self):
        """
        Run the simulation by processing each command per car every time.
        If all car has stopped then simulation also stop and print the car final position

        If there is car A with command FR and car B with command RL,
        then the sequnce of comand will be
        Car A - F
        Car B - R
        Car A - R
        Car B - L
        """
        count = 1
        while True:
            if all([car.stopped for car in self.cars.values()]):
                break
            for car in self.cars.values():
                self.process_command(car, count)
            count += 1

        print("After simulation, the result is:")
        for car in self.cars.values():
            print(car)
        print("\n")

    def is_car_same_position(self, car_moving: Car, car: Car):
        """
        Check if the moving car collides with another car in the simulation after moving.

        Parameters
        ----------
        car_moving: Car
            the moving car in the simulation
        car: Car
            all the other cars in the simulation
        """
        return (car_moving.name != car.name) and (
            car_moving.x_position == car.x_position
            and car_moving.y_position == car.y_position
        )

    def check_collision(self, car_moving: Car, count: int):
        """
        Check if the moving car collides with another car in the simulation after moving.
        If so, record the moving car and stationary car as collided and stopped.

        Parameters
        ----------
        car_moving: Car
            the moving car in the simulation
        count: int
            the number of iteration the simulation has gone through
        """
        for car in self.cars.values():
            if self.is_car_same_position(car_moving, car):
                car_moving.collide = True
                car_moving.stopped = True
                car_moving.collide_after = count
                car_moving.collide_with.append(car.name)
                car.collide_with.append(car_moving.name)

                if car.collide:
                    continue
                else:
                    car.collide = True
                    car.stopped = True
                    car.collide_after = count

    def is_car_out_of_bounds(self, car: Car) -> bool:
        """
        Check if the car is within the bounds of the simulation grid

        Parameters
        ----------
        car: Car
            the car which the position is checked
        """
        return (car.x_position < 0 or car.y_position < 0) or (
            car.x_position >= self.width or car.y_position >= self.height
        )

    @staticmethod
    def first_prompt() -> str:
        """
        Show prompt for user to choose between adding car to the field or run the simulation
        """
        input_prompt = "Please choose from the following options:\n[1] Add a car to field\n[2] Run simulation\n"
        return get_stripped_input(input_prompt)
    
    @staticmethod
    def second_prompt() -> str:
        """
        Show prompt for user to choose between start over or exit
        """
        input_prompt = (
            "Please choose from the following options:\n[1] Start over\n[2] Exit\n"
        )
        return get_stripped_input(input_prompt)

    def ask_car_name(self) -> str:
        """
        Show prompt for user to input the car name

        Parameters
        ----------
        simulation:Simulation
            the simulation class to validate the car name
        """
        input_prompt = "Please enter the name of the car: "
        car_name = get_stripped_input(input_prompt)
        while car_name in self.cars:
            print(
                "The car name already exist in the simulation. Please choose a different name"
            )
            car_name = get_stripped_input(input_prompt)
        return str(car_name)

    def ask_car_position(self, car_name: str) -> List[str]:
        """
        Show prompt for user to input the car initial position

        Parameters
        ----------
        car_name:str
            the name of the car attached to the position
        simulation:Simulation
            the simulation class to validate the initial position
        """
        input_prompt = (
            f"Please enter initial position of car {car_name} in x y Direction format: "
        )
        initial_position = get_splitted_input(input_prompt)
        while not self.validate_initial_position(initial_position):
            initial_position = get_splitted_input(input_prompt)
        return initial_position

    def ask_car_command(self, car_name: str):
        """
        Show prompt for user to input the car command list

        Parameters
        ----------
        car_name: str
            the name of the car attached to the command
        """
        input_prompt = f"Please enter the command (L,R,F) for car {car_name}: "
        command = get_stripped_input(input_prompt)
        while re.search(r"[^FLR]", command) is not None:
            print(
                "Command can only have L,R,F in a continous string format (e.g RFLRFLRFL)"
            )
            command = get_stripped_input(input_prompt)
        return command

    def validate_initial_position(self, initial_position: List[str]) -> bool:
        """
        Validating the initial position of the car.
        Firstly, check if there are existing car in the same position in the simulation already
        Secondly, check the car position is within the boundary of simulation

        Parameters
        ----------
        simulation: Simulation
            the simulation class to validate the car position
        initial_position: List[str]
            the initial position of the car as inputted by user splitted to list
        """
        try:
            x_position = int(initial_position[0])
            y_position = int(initial_position[1])
            direction = initial_position[2]
            for car in self.cars.values():
                if (x_position == car.x_position) and (y_position == car.y_position):
                    print(
                        "There are already car in the simulation with the same position, please choose different position for the car"
                    )
                    return False
            if (
                (x_position < self.width and x_position >= 0)
                and (y_position < self.height and y_position >= 0)
                and (direction in ["N", "S", "W", "E"])
            ):
                return True
            else:
                return False
        except ValueError:
            print("Input need to be in x y direction format (e.g 1 2 N)")
            return False

    def __str__(self) -> str:
        return "\n".join(
            [
                f"- {car.name}, ({car.x_position},{car.y_position}) {car.direction}, {car.commands}"
                for car in self.cars.values()
            ]
        )
