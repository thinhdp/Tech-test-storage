from typing import List


class Car:
    """
    Containing the car object for each car in the simulation

    Parameters
    ----------
    name: str
        The name of the car
    x: int
        The x position on the grid of the car
    y: int
        The y position on the grid of the car
    commands: list
        The list of commands for the car, this will be a string combination of L/R/F
    """

    def __init__(self, name: str, x: int, y: int, direction: str, commands: str):
        self.name: str = name
        self.x_position: int = x
        self.y_position: int = y
        self.direction: str = direction
        self.commands: str = commands
        self.available_directions: List[str] = ["N", "E", "S", "W"]

        # These are flags to check if the car has stopped/collided with another car
        self.stopped: bool = False
        self.collide: bool = False
        self.collide_after: int = 0
        self.collide_with: List[str] = []

    def rotate_left(self):
        """
        Set the direction of the car by rotating the car 90 degress to the left using available_directions

        If current direction of the car is N, then by rotating left,
        we can get the index of N in available_directions and -1 to get the index position for direction 90 degress to the left
        """
        self.direction = self.available_directions[
            (self.available_directions.index(self.direction) - 1) % 4
        ]

    def rotate_right(self):
        """
        Same as rotate left but +1 to the index to get the direction 90 degrees to the right
        """
        self.direction = self.available_directions[
            (self.available_directions.index(self.direction) + 1) % 4
        ]

    def move(self):
        """
        Move the car 1 grid forward.
        Depending on the direction of the car, either move forward/back the x/y position

        """
        if self.direction == "N":
            self.y_position += 1
        elif self.direction == "S":
            self.y_position -= 1
        elif self.direction == "E":
            self.x_position += 1
        elif self.direction == "W":
            self.x_position -= 1

    def __str__(self) -> str:
        if self.collide:
            return f"- {self.name}, collides with {','.join(self.collide_with)} at ({self.x_position},{self.y_position}) at step {self.collide_after}"
        else:
            return (
                f"- {self.name}, ({self.x_position},{self.y_position}) {self.direction}"
            )

    def __eq__(self, other):
        if isinstance(other, Car):
            return self.name == other.name
        return False
