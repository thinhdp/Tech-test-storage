import sys
from typing import List, Tuple


def get_splitted_input(input_prompt: str) -> List[str]:
    """
    Get user input that has been stripped of additional space and splitted into list

    Parameters
    ----------
    input_prompt: str
        the text to be shown to user
    """
    return input(input_prompt).strip().split()


def get_stripped_input(input_prompt: str) -> str:
    """
    Get user input that has been stripped of additional space

    Parameters
    ----------
    input_prompt: str
        the text to be shown to user
    """
    return input(input_prompt).strip()


def get_xy_from_dimension(dimension: List[str]) -> Tuple[int, ...]:
    """
    Do basic check about the min and max size of the grid.
    Otherwise, x y as an integer tuple

    Parameters
    ----------
    dimension: List[str]
        the dimension in the form of [x,y]
    """
    x, y = map(int, dimension)
    if (x <= 0 or y <= 0) or (x >= sys.maxsize or y >= sys.maxsize):
        raise ValueError()
    return x, y


def ask_dimension() -> Tuple[int, ...]:
    """
    Show prompt for user to get the dimension of the simulation
    """
    input_prompt = (
        "Please enter the width and height of the simulation field in x y format: "
    )
    dimension = get_splitted_input(input_prompt)
    while dimension is not None:
        try:
            return get_xy_from_dimension(dimension)
        except ValueError:
            print(
                "There is error with the dimensions. Value need to be at least 0 for both dimensions and cannot be more than 9223372036854775807"
            )
            dimension = get_splitted_input(input_prompt)
