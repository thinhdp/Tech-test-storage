from Raffle import Raffle
from PlayerManager import PlayerManager


def rafle_game():
    global remaining_pot, status_game, total_pot
    remaining_pot = 0
    status_game = False
    total_pot = 0

    while True:
        raffle = Raffle()
        print("~~~")
        print("Welcome to My Raffle App")
        if not status_game:
            print("Status: Draw has not started")
        else:
            print(f"Status: Draw is ongoing. Raffle pot size is ${total_pot}")
        print("""\n[1] Start a New Draw
                \n[2] Buy Tickets
                \n[3] Run Raffle""")
        print("\n\n~~~")
        print("\nUser can enter `1`, `2` or `3` to proceed")
        print("input:")
        user_choice = int(input())
        match user_choice:
            case 1:
                if not status_game:
                    # Start a new Draw
                    status_game = True
                    total_pot = raffle.get_total_pot(remaining_pot)
                    ## Reset players ##
                    player_manager = PlayerManager()
                    print("```")
                    print(f"New Raffle draw has been started. Initial pot size: ${total_pot}")
                    input("Press any key to return to the main menu\n```")
                else:
                    continue
            case 2:
                if not status_game:
                    continue
                else:
                    # Register new player
                    print("""~~~\nEnter your name, no of tickets to purchase\n~~~""")
                    new_player = player_manager.register_new_player(input())
                    player_manager.joining_players, total_pot = player_manager.add_new_player(new_player, player_manager.joining_players, total_pot)
                    input("\nPress any key to return to the main menu\n~~~")
            case 3:
                if not status_game:
                    continue
                else:
                    print("~~~\nRunning Raffle..")
                    raffle.wining_ticket = raffle.random_winning_ticket()
                    print(f"""Winning Ticket is {" ".join(map(str, raffle.wining_ticket))}\n""")
                    result_wining_groups = raffle.wining_groups(raffle.wining_ticket, player_manager.joining_players)
                    remaining_pot = raffle.reward(result_wining_groups, total_pot)
                    status_game = False
                    input("Press any key to return to the main menu\n~~~")

def main():
    rafle_game()

if __name__ == '__main__':
    main()