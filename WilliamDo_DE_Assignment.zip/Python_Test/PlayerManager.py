from typing import Any

from Player import Player

class PlayerManager:
    def __init__(self):
        self.joining_players = {}

    def __getattribute__(self, name: str) -> Any:
        return super().__getattribute__(name)


    def add_new_player(self, new_player, joining_players, total_pot):
        print(
            f"""~~~\nHi {new_player.name.capitalize()}, you have purchased {len(new_player.list_tickets)} ticket(s)-""")
        # Check player has bought tickets or not. If yes, add new tickets for user
        if new_player.name.lower() in joining_players.keys():
            for row_number, ticket in enumerate(new_player.list_tickets):
                print(f"Ticket {row_number + 1}: {ticket}")
                joining_players[new_player.name.lower()].append(ticket)
        else:
            joining_players[new_player.name.lower()] = new_player.list_tickets
            for row_number, ticket in enumerate(new_player.list_tickets):
                print(f"Ticket {row_number + 1}: {ticket}")
        ## tickets sale contribute directly to the pot
        total_pot += len(new_player.list_tickets) * 5
        return joining_players, total_pot

    def register_new_player(self, input_str):
        while True:
            try:
                player_info = str(input_str.strip()).split(',')
                player_name = str(player_info[0].strip())
                player_number_ticket = int(player_info[1].strip())
            except ValueError:
                print(
                    "ValueError:Wrong Format Player Information. Please retry with format <player_name(String)>,<number_tickets(Integer)>")
                self.register_new_player(input())
                continue
            if player_number_ticket > 5 or player_number_ticket < 0:
                print(
                    "Player can purchase up to a maximum of 5 tickets per draw\nYour number of tickets isn't available. Please retry.")
                self.register_new_player(input())
                continue
            else:
                break
        return Player(player_name, player_number_ticket)