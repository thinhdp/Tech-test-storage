from Player import Player
from Raffle import Raffle
from PlayerManager import PlayerManager
import main as main

# Option 1
def start_new_game():
    #The game starts for the first time
    remaining_pot = 0
    raffle = Raffle()
    assert raffle.get_total_pot(remaining_pot) == 100, "Should be $100"
    # Game starts 2nd time
    remaining_pot = 60
    raffle = Raffle()
    assert raffle.get_total_pot(remaining_pot) == 160, "Should be $160"

# Option 2
def buy_tickets():
    player_manager = PlayerManager()
    new_player_A = player_manager.register_new_player("James,1")
    assert len(new_player_A.list_tickets) == 1, "Should be 1 ticket"
    assert new_player_A.name.lower() == 'james', "Should be james"
    new_player_B = player_manager.register_new_player("Ben,2")
    assert len(new_player_B.list_tickets) == 2, "Should be 2 tickets"
    assert new_player_B.name.lower() == 'ben', "Should be ben"

def buy_multiple_times():
    player_manager = PlayerManager()
    joining_players = {}
    total_pot = 100
    new_player = Player("James", 1)
    joining_players, total_pot = player_manager.add_new_player(new_player, joining_players, total_pot)
    assert total_pot == 105, "Should be $105"
    assert joining_players["james"] != [], "Not Empty tickets"
    assert len(joining_players["james"]) == 1, "Have 1 ticket"
    new_player_2 = Player("James", 2)
    joining_players, total_pot = player_manager.add_new_player(new_player_2, joining_players, total_pot)
    assert total_pot == 115, "Should be $115"
    assert joining_players["james"] != [], "Not Empty tickets"
    assert len(joining_players["james"]) == 3, "Should be 3 tickets for James"

# Option 3:
def winning_player():
    raffle = Raffle()
    winning_ticket = [3, 8, 7, 11, 12]
    joining_players = {'james': [[4,7,8,13,14]],
                       'ben': [[3,6,9,11,13], [3,7,8,11,14]],
                      'romeo': [[3,7,9,14,15], [4,5,10,12,15], [1, 2, 7, 12, 13]]}
    result_wining_groups = raffle.wining_groups(winning_ticket, joining_players)
    assert result_wining_groups['Group 2 Winners'].count('romeo') == 2, "Should be 2"
    assert result_wining_groups['Group 2 Winners'].count('james') == 1, "Should be 1"
    assert result_wining_groups['Group 2 Winners'].count('ben') == 1, "Should be 1"
    assert result_wining_groups['Group 4 Winners'].count('ben') == 1, "Should be 1"
    total_pot = 130
    remaining_pot = raffle.reward(result_wining_groups, total_pot)
    assert remaining_pot == 84.5, "Should be $84.5"

if __name__ == '__main__':
    start_new_game()
    buy_tickets()
    buy_multiple_times()
    winning_player()
    print("\n~~~All test cases success~~~")