Raffle Application
=============================

# Running Raffle Application
python main.py

# Running Unit Test 
python unit_test.py
