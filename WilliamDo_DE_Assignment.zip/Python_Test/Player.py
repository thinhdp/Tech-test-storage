import random
from typing import Any


class Player():
    def __init__(self, name, number_tickets):
        self.name = name
        self.number_ticket = number_tickets
        self.list_tickets = [random.sample(range(1, 15), 5) for _ in range(number_tickets)]

    def __getattribute__(self, name: str) -> Any:
        return super().__getattribute__(name)