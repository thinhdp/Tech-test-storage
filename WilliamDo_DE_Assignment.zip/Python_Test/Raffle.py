import random
from typing import Any

class Raffle():
    def __init__(self):
        self.init_pot = 100
        self.wining_ticket = []

    def __getattribute__(self, name: str) -> Any:
        return super().__getattribute__(name)

    def random_winning_ticket(self):
        self.wining_ticket = random.sample(range(1, 15), 5)
        return self.wining_ticket

    def get_total_pot(self, remaining_pot):
        return self.init_pot + remaining_pot

    def common_numbers(self, wining_ticket, player_ticket):
        wining_ticket_set = set(wining_ticket)
        player_ticket_set = set(player_ticket)

        if wining_ticket_set & player_ticket_set:
            result = list(wining_ticket_set & player_ticket_set)
            return len(result)
        return 0

    def wining_groups(self, wining_ticket, joining_players):
        result_wining_groups = {
            "Group 2 Winners": [],
            "Group 3 Winners": [],
            "Group 4 Winners": [],
            "Group 5 Winners": []
        }
        for player_name, player_tickets in joining_players.items():
            for ticket in player_tickets:
                number_of_common_numbers = self.common_numbers(wining_ticket, ticket)
                if number_of_common_numbers > 1:
                    result_wining_groups[f"Group {number_of_common_numbers} Winners"].append(player_name)
        return result_wining_groups

    def reward(self, result_wining_groups, total_pot):
        for group, list_player in result_wining_groups.items():
            # When Group winning have people
            print(f"\n{group}")
            if list_player:
                if group == 'Group 2 Winners':
                    for player in set(list_player):
                        print(f"{player.capitalize()} with {list_player.count(player)} winning ticket(s)- "
                              f"${round(total_pot * 0.1 * list_player.count(player) / len(list_player), 2)}")
                elif group == 'Group 3 Winners':
                    for player in set(list_player):
                        print(f"{player.capitalize()} with {list_player.count(player)} winning ticket(s)- "
                              f"${round(total_pot * 0.15 * list_player.count(player) / len(list_player), 2)}")
                elif group == 'Group 4 Winners':
                    for player in set(list_player):
                        print(f"{player.capitalize()} with {list_player.count(player)} winning ticket(s)- "
                              f"${round(total_pot * 0.25 * list_player.count(player) / len(list_player), 2)}")
                else:
                    for player in set(list_player):
                        print(f"{player.capitalize()} with {list_player.count(player)} winning ticket(s)- "
                              f"${round(total_pot * 0.5 * list_player.count(player) / len(list_player), 2)}")
            # When Group winning empty
            else:
                print("\nNil")
        remaining_pot = total_pot * (1 - (0.1 * (1 if len(result_wining_groups['Group 2 Winners']) > 0 else 0))
                                     - (0.15 * (1 if len(result_wining_groups['Group 3 Winners']) > 0 else 0))
                                     - (0.25 * (1 if len(result_wining_groups['Group 4 Winners']) > 0 else 0))
                                     - (0.5 * (1 if len(result_wining_groups['Group 5 Winners']) > 0 else 0)))
        return remaining_pot