User Guide
=============================

# SQL Test
SQL_Test.txt is my answer for SQL take home test.txt

# Python Test
The source code for Raffle Game in Python_Test folder.
Please refer to README.md file in Python_Test folder to run the application 