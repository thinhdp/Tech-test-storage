from enum import Enum


class Direction(Enum):
    """
    Represents the possible directions a car can face.
    """
    # note direction order matters. used in turning do not change
    NORTH = 'N'
    EAST = 'E'
    SOUTH = 'S'
    WEST = 'W'

    def left(self):
        """
        Returns the direction to the left of the current direction.
        """
        directions = list(Direction)
        current_index = directions.index(self)
        return directions[(current_index - 1) % len(directions)]

    def right(self):
        """
        Returns the direction to the right of the current direction.
        """
        directions = list(Direction)
        current_index = directions.index(self)
        return directions[(current_index + 1) % len(directions)]


class Car:
    """
    Represents an autonomous driving car

    Attributes:
        name (str): The unique name of the car
        position (tuple[int, int]): The current (x, y) coordinates of the car
        direction (Direction): The current direction the car is facing (N, S, E, W)
        commands (str): The sequence of commands for the car to execute
        has_collided (bool):  Flag indicating if the car has been involved in a collision
        curr_step (int): Current step count
    """
    FORWARD_DIRECTION = {
        Direction.NORTH: (0, 1),
        Direction.EAST: (1, 0),
        Direction.SOUTH: (0, -1),
        Direction.WEST: (-1, 0)
    }

    def __init__(self, name: str, position: tuple[int, int], direction: Direction, commands: str, has_collided: bool = False):
        """
        Initializes a Car object

        Args:
            name (str): The unique name of the car
            position (tuple[int, int]): The (x, y) coordinates of the car
            direction (Direction): The initial direction the car is facing
            commands (str): The sequence of commands for the car to execute

        Raises:
            ValueError: If the inputs is invalid.
        """
        if not isinstance(name, str) or not name:
            raise ValueError("Car name must be a non-empty string")
        if not isinstance(position, tuple) or \
                len(position) != 2 or not all(isinstance(coord, int) for coord in position):
            raise ValueError(
                "Position must be a tuple of two integers (x, y)")
        if not isinstance(direction, Direction):
            raise ValueError(
                "direction must be an instance of the Direction enum")
        if not isinstance(commands, str):
            raise ValueError("Commands must be a string")
        for char in commands:
            if char not in ["F", "L", "R"]:
                raise ValueError(
                    f"Invalid command {char} in commands. Must be one of F L R.")
        self.name = name
        self.position = position
        self.direction = direction
        self.commands = commands
        self.has_collided = has_collided
        self.curr_step = 0

    def __str__(self):
        """
        Returns a string representation of the car by overriding default string

        Returns:
            str: A string representing the car's name, position, and direction.
        """
        return f"{self.name}, {self.position} {self.direction.value}, {self.commands}"

    def move(self, field_max_x: int, field_max_y: int):
        """
        Used only in tests. Executes the commands within boundaries
        Checks for collision before moving
        Args:
            field_max_x (int): the width of the field
            field_max_y (int): the height of the field
        """
        if not isinstance(field_max_x, int) or field_max_x < 0:
            raise ValueError("field_max_x must be a non-negative integer")
        if not isinstance(field_max_y, int) or field_max_y < 0:
            raise ValueError("field_max_y must be a non-negative integer")
        for step in self.commands:
            if self.has_collided:
                # stop processing after collision
                break
            self.move_step(self.curr_step, field_max_x, field_max_y)

    def move_step(self, step_num: int, field_max_x: int, field_max_y: int) -> None:
        """
        Executes the next command within boundaries
        Checks for collision before moving
        Checks for step num == curr_step to ensure each command only execute once 
        Args:
            field_max_x (int): the width of the field
            field_max_y (int): the height of the field
        """
        if not isinstance(field_max_x, int) or field_max_x < 0:
            raise ValueError("field_max_x must be a non-negative integer")
        if not isinstance(field_max_y, int) or field_max_y < 0:
            raise ValueError("field_max_y must be a non-negative integer")
        if self.has_collided:
            # stop processing after collision
            return
        if step_num >= len(self.commands):
            return  # ignore if step num more than commands
        if step_num != self.curr_step:
            raise ValueError(
                "Step number provided not in sync with current step")
        cmd = self.commands[step_num]
        if cmd == "L":
            self.direction = self.direction.left()
        elif cmd == "R":
            self.direction = self.direction.right()
        elif cmd == "F":
            dx, dy = self.FORWARD_DIRECTION[self.direction]
            new_x = self.position[0] + dx
            new_y = self.position[1] + dy
            if 0 <= new_x < field_max_x and 0 <= new_y < field_max_y:
                self.position = (new_x, new_y)
            else:
                print(
                    f"Step {step_num}: Car {self.name} attempted to move out of bounds and command '{cmd}' was ignored")
        self.curr_step += 1

    def set_collided(self):
        """
        Set collison flag to True
        """
        self.has_collided = True
