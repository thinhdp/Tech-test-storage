from typing import Optional
from src.field import Field, CollisionPosition
from src.car import Car, Direction


class ConsoleUI:
    """
    Controls the flow of user interaction
    """
    DIRECTION_INPUT_MAP = {
        'N': Direction.NORTH,
        'S': Direction.SOUTH,
        'E': Direction.EAST,
        'W': Direction.WEST,
    }

    def display_welcome_msg(self) -> None:
        """
        Print welcome msg to console
        """
        print("Welcome to Auto Driving Car Simulation!\n")

    def display_end_msg(self) -> None:
        """
        Print ending msg to console
        """
        print("Thank you for running the simulation. Goodbye!")

    def get_field_dimensions(self) -> Optional[Field]:
        """
        Loops until field dimensions are provided by the user

        Returns:
            Field
        """

        while True:
            try:
                dimensions_input = input(
                    "Please enter the width and height of the simulation field in x y format:\n")
                dimensions = dimensions_input.split()
                if len(dimensions) != 2:
                    print(
                        "Invalid input. Please enter two numbers separated by a space.")
                    continue
                width, height = map(int, dimensions)
                field = Field(width, height)
                print(
                    f"You have created a field of {field.width} x {field.height}.\n")
                return field
            except ValueError:
                print(
                    "Invalid input. Please enter two postive integers separated by a space.")

    def get_display_options(self) -> None:
        """
        Displays the options and get user input
        """
        while True:
            print("Please choose from the following options:")
            print("[1] Add a car to field")
            print("[2] Run simulation")
            choice = input()
            if choice not in ['1', '2']:
                print(f"Invalid choice {choice}. Please try again")
                continue
            return choice

    def get_car_inputs(self) -> Car:
        """
        Get inputs from user to create car object
        Return:
            car (Car)
        """
        try:
            name = input("Please enter the name of the car: ")
            position_input = input(
                f"Please enter initial position of car {name} in x y Direction format: ")
            parts = position_input.split()
            if len(parts) != 3:
                print("Invalid input format. Please use 'x y Direction'.")
                return
            x, y, direction = parts

            try:
                position = (int(x), int(y))
            except ValueError as e:
                print("Invalid integer for x and y.")

            direction = self.DIRECTION_INPUT_MAP.get(direction)
            if direction is None:
                print("Invalid direction. Direction can only be N S W E.")

            commands = input(f"Please enter the commands for car {name}: ")
            car = Car(name, position, direction, commands)
            return car

        except (ValueError, TypeError) as e:
            print(f"Error: {e}")  # print the error message
            # Don't add the car if there's an error

    def display_current_cars(self, cars: list[Car]) -> None:
        """
        Displays the current list of cars in the field.
        """

        if not cars:  # check if the car list is empty
            print("No cars in the field.")
            return

        print("Your current list of cars are:")
        for car in cars:
            print(f"- {car}")
        print()

    def display_simulation_results(self, collisions: list[CollisionPosition], cars_final: list[Car]) -> None:
        """
        Print console outputs based on results
        """
        print("After simulation, the result is:")
        collided_car = []
        for collision in collisions:
            print(collision)
            collided_car.extend(collision.cars)
        for car in cars_final:
            if car.name not in collided_car:
                print(f"- {car.name}, {car.position} {car.direction.value}")
        print()

    def get_end_choice(self) -> None:
        """
        Displays the options at the end of the simulation.
        """
        while True:
            print("Please choose from the following options:")
            print("[1] Start over")
            print("[2] Exit")
            choice = input()
            if choice not in ['1', '2']:
                print(f"Invalid choice {choice}. Please try again")
                continue
            return choice
