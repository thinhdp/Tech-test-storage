from typing import Optional

from src.field import Field
from src.console_ui import ConsoleUI


def main():
    """
    Main entry point for whole program
    """
    ui = ConsoleUI()
    field: Optional[Field] = None
    while True:
        ui.display_welcome_msg()
        if not field:
            field = ui.get_field_dimensions()
        if field:
            while True:
                display_choice = ui.get_display_options()
                if display_choice == '1':
                    car = ui.get_car_inputs()
                    if car:
                        field.add_car(car)
                    all_cars = field.get_cars()
                    ui.display_current_cars(all_cars)

                elif display_choice == '2':
                    cars = field.get_cars()

                    ui.display_current_cars(cars)
                    collisions = field.move_cars()
                    cars_final = field.get_cars()
                    ui.display_simulation_results(collisions, cars_final)
                    break
                # choice is always valid

            end_choice = ui.get_end_choice()
            if end_choice == '1':
                field = None
                continue
            elif end_choice == '2':
                ui.display_end_msg()
                break


if __name__ == "__main__":
    main()
