from collections import defaultdict
from dataclasses import dataclass
from src.car import Car
from typing import Optional


@dataclass
class CollisionPosition:
    """
    Dataclass to record collisions
    Attributes:
        cars (list[str]): names of cars that are involved
        poisiton (tuple[int,int]): x,y coordinates on field where collision occured
        step (int): which step number when collision occured. 0-index

    """
    cars: list[str]
    position: tuple[int, int]
    step: int

    def __str__(self):
        string = ""
        self.cars.sort()
        for car in self.cars:
            other = self.cars.copy()
            other.remove(car)
            if len(other) == 1:
                other = other[0]
            string += (
                f"- {car}, collides with {other} at {self.position} at step {self.step+1}\n")

        return string[:-1]


class Field:
    """
    Attributes:
        width (int): width of field
        height (int): height of field    
        cars (dict[str, Car]): Dictionary of cars on the filed. With car names as keys  
    """

    def __init__(self, width: int, height: int):
        """
        Initialises a Field object
        Args:
            width (int): width of field
            height (int): height of field
        """
        if not isinstance(width, int) or width <= 0:
            raise ValueError("Width must be a positive integer.")
        if not isinstance(height, int) or height <= 0:
            raise ValueError("Height must be a positive integer.")
        self.width = width
        self.height = height
        self.cars: dict[str, Car] = {}

    def add_car(self, car: Car) -> None:
        """
        Add a car to the field
        Args:
            car (Car): an instance of Car
        Raises: 
            TypeError: If car is not type Car
            ValueError: if car with the same name is on the field
            ValueError: if car is not within the boundaries of the field

        """
        if not isinstance(car, Car):
            raise TypeError("car must be of type Car")
        if car.name in self.cars:
            raise ValueError(
                f"Uable to add car with name {car.name}. Car with {car.name} already exists")
        if not (0 <= car.position[0] < self.width and 0 <= car.position[1] < self.height):
            raise ValueError(
                f"Car '{car.name}' start position {car.position} is outside the field boundaries.")
        self.cars[car.name] = car

    def _check_collision_with_stationary(
        self, car: Car, positions_before: dict[tuple[int, int], list[str]], step: int
    ) -> Optional[CollisionPosition]:
        """Checks for collision with stationary cars and updates their state."""
        if car.position in positions_before:
            for stationary_car_name in positions_before[car.position]:
                if car.name != stationary_car_name and not self.cars[stationary_car_name].has_collided:
                    # print(
                    #     f"Collision at step {step}, position {car.position}: Car '{car.name}' collided with stationary car '{stationary_car_name}'"
                    # )
                    collided_cars = [car.name, stationary_car_name]
                    car.set_collided()
                    self.cars[stationary_car_name].set_collided()
                    return CollisionPosition(collided_cars, car.position, step)
        return None

    def _check_collision_with_moved(
        self, car: Car, positions_after: dict[tuple[int, int], list[str]], step: int
    ) -> Optional[CollisionPosition]:
        """Checks for collision with other moving cars and updates their state."""
        if car.position in positions_after:
            other_car_names = positions_after[car.position]
            if car.name not in other_car_names:
                # print(
                #     f"Collision at step {step}, position {car.position}: Car '{car.name}' collided with moving car '{other_car_names}'"
                # )
                collided_cars = [car.name] + other_car_names
                car.set_collided()
                for name in other_car_names:
                    self.cars[name].set_collided()
                return CollisionPosition(collided_cars, car.position, step)
        return None

    def move_cars(self) -> list[CollisionPosition]:
        """
        Moves the cars within the field. Detects if any collisions and returns the 
        collision position

        """
        collisions: list[CollisionPosition] = []  # records collisions
        if len(self.cars) == 0:
            return []
        max_steps = max([len(car.commands) for car in self.cars.values()])

        for step in range(max_steps):
            # records the position at each step. used to check for collisions
            positions_before: dict[tuple[int, int],
                                   list[str]] = defaultdict(list)
            positions_after: dict[tuple[int, int],
                                  list[str]] = defaultdict(list)

            # add current locations of cars before moving
            for car in self.cars.values():
                positions_before[car.position].append(car.name)

            #  moving
            for car in self.cars.values():
                if car.has_collided:
                    continue
                before_position = car.position
                car.move_step(step, self.width, self.height)
                del positions_before[before_position]

                # check whether collide with any car who hasnt move
                new_collision = self._check_collision_with_stationary(
                    car, positions_before, step)
                if new_collision:
                    collisions.append(new_collision)

                # Check for collision with moved cars
                new_collision = self._check_collision_with_moved(
                    car, positions_after, step)
                if new_collision:
                    collisions.append(new_collision)
                positions_after[car.position].append(car.name)

        return collisions

    def get_cars(self) -> list[Car]:
        """
        Gets the list of cars in the field
        Returns:
            list[Car]: A list of Car objects
        """
        return list(self.cars.values())
