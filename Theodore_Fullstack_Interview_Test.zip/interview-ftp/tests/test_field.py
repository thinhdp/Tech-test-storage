import pytest
from src.field import CollisionPosition, Field
from src.car import Car, Direction


def test_field_init():
    field = Field(10, 4)
    assert field.width == 10
    assert field.height == 4


def test_field_invalid_init():
    with pytest.raises(ValueError):
        field = Field(-1, 4)
    with pytest.raises(ValueError):
        field = Field(1, -4)
    with pytest.raises(ValueError):
        field = Field(1, "-4")


def test_add_car():
    field = Field(5, 6)
    car = Car("A", (0, 0), Direction.NORTH, "FLFRFRR")
    field.add_car(car)
    assert field.cars["A"] == car


def test_add_car_invalid_type():
    field = Field(5, 6)
    with pytest.raises(TypeError):
        field.add_car("car")


def test_add_car_dup_name():
    field = Field(5, 6)
    car = Car("A", (0, 0), Direction.NORTH, "FLFRFRR")
    field.add_car(car)
    with pytest.raises(ValueError):
        field.add_car(car)


def test_add_car_invalid_start_position():
    field = Field(5, 6)
    car = Car("A", (6, 6), Direction.NORTH, "FLFRFRR")
    with pytest.raises(ValueError):
        field.add_car(car)


def test_move_cars_no_collision():
    field = Field(5, 6)
    carA = Car("A", (1, 1), Direction.NORTH, "FRFL")
    carB = Car("B", (2, 2), Direction.NORTH, "FRFLF")
    field.add_car(carA)
    field.add_car(carB)
    collision = field.move_cars()
    assert len(collision) == 0
    assert field.cars["A"].position == (2, 2)
    assert field.cars["B"].position == (3, 4)


def test_move_cars_lagging_no_collisions():
    field = Field(5, 6)
    carA = Car("A", (1, 1), Direction.NORTH, "FFRF")
    carB = Car("B", (1, 0), Direction.NORTH, "FFRF")
    field.add_car(carA)
    field.add_car(carB)
    collision = field.move_cars()
    assert len(collision) == 0
    assert field.cars["A"].position == (2, 3)
    assert field.cars["B"].position == (2, 2)


def test_move_cars_collision_with_stationary():
    field = Field(5, 6)
    carA = Car("A", (1, 1), Direction.NORTH, "FRFL")
    carB = Car("B", (2, 1), Direction.NORTH, "FLFLF")
    field.add_car(carA)
    field.add_car(carB)
    collision = field.move_cars()
    assert len(collision) == 1
    assert field.cars["A"].position == (2, 2)
    assert field.cars["B"].position == (2, 2)
    assert collision[0] == CollisionPosition(["A", "B"], (2, 2), 2)


def test_move_cars_collision_after_moved():
    field = Field(5, 6)
    carA = Car("A", (1, 1), Direction.NORTH, "FRFF")
    carB = Car("B", (3, 1), Direction.NORTH, "FLF")
    field.add_car(carA)
    field.add_car(carB)
    collision = field.move_cars()
    assert len(collision) == 1
    assert field.cars["A"].position == (2, 2)
    assert field.cars["B"].position == (2, 2)
    assert collision[0] == CollisionPosition(["B", "A"], (2, 2), 2)


def test_move_cars_with_collision():
    # scenario2
    field = Field(10, 10)
    carA = Car("A", (1, 2), Direction.NORTH, "FFRFFFFRRL")
    carB = Car("B", (7, 8), Direction.WEST, "FFLFFFFFFF")
    field.add_car(carA)
    field.add_car(carB)
    collision = field.move_cars()
    assert len(collision) == 1
    assert field.cars["A"].position == (5, 4)
    assert field.cars["B"].position == (5, 4)
    assert collision[0] == CollisionPosition(["B", "A"], (5, 4), 6)

# test car added to same location
