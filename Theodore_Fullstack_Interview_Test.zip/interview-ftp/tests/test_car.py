import pytest
from src.car import Car, Direction


def test_car_init():
    car = Car("A", (1, 2), Direction.NORTH, "FFRFFFFRRL")
    assert car.name == "A"
    assert car.position == (1, 2)
    assert car.direction == Direction.NORTH
    assert car.commands == "FFRFFFFRRL"
    assert car.has_collided == False


def test_car_init_invalid_name():
    with pytest.raises(ValueError):
        car = Car("", (1, 2), Direction.NORTH, "FFR")


def test_car_init_invalid_position():
    with pytest.raises(ValueError):
        car = Car("A", (1.1, 2), Direction.NORTH, "FFR")
    with pytest.raises(ValueError):
        car = Car("A", ('A', 2), Direction.NORTH, "FFR")


def test_car_init_invalid_direction():
    with pytest.raises(ValueError):
        car = Car("A", (1, 2), "A", "FFR")


def test_car_init_invalid_commands():
    with pytest.raises(ValueError):
        car = Car("A", (1, 2), Direction.NORTH, None)
    with pytest.raises(ValueError):
        car = Car("A", (1, 2), Direction.NORTH, "FFAR")


def test_car_turning():
    car = Car("A", (1, 2), Direction.NORTH, "LL")
    car.move(5, 5)
    assert car.direction == Direction.SOUTH
    car = Car("B", (1, 2), Direction.NORTH, "R")
    car.move(5, 5)
    assert car.direction == Direction.EAST


def test_car_move_forward():
    car = Car("A", (1, 2), Direction.NORTH, "FF")
    car.move(5, 5)
    assert car.direction == Direction.NORTH
    assert car.position == (1, 4)

    car = Car("B", (1, 2), Direction.EAST, "F")
    car.move(5, 5)
    assert car.direction == Direction.EAST
    assert car.position == (2, 2)

    car = Car("C", (1, 2), Direction.WEST, "F")
    car.move(5, 5)
    assert car.direction == Direction.WEST
    assert car.position == (0, 2)

    car = Car("D", (1, 2), Direction.SOUTH, "F")
    car.move(5, 5)
    assert car.direction == Direction.SOUTH
    assert car.position == (1, 1)


def test_car_move_sequence():
    # Scenario 1
    car = Car("A", (1, 2), Direction.NORTH, "FFRFFFFRRL")
    car.move(10, 10)
    assert car.direction == Direction.SOUTH
    assert car.position == (5, 4)


def test_car_move_out_of_bounds():
    # test y min
    car = Car("A", (0, 0), Direction.SOUTH, "F")
    car.move(5, 5)
    assert car.position == (0, 0)
    # test y max
    car = Car("B", (0, 5), Direction.NORTH, "F")
    car.move(5, 5)
    assert car.position == (0, 5)
    # test x min
    car = Car("C", (0, 5), Direction.WEST, "FF")
    car.move(5, 5)
    assert car.position == (0, 5)
    # test x max
    car = Car("D", (5, 4), Direction.EAST, "FF")
    car.move(5, 5)
    assert car.position == (5, 4)


def test_car_invalid_boundaries():
    car = Car("A", (0, 0), Direction.SOUTH, "F")
    with pytest.raises(ValueError):
        car.move(0, -5)


def test_car_has_collided():
    car = Car("D", (5, 4), Direction.EAST, "LRFF")
    car.set_collided()
    car.move(15, 15)
    assert car.direction == Direction.EAST
    assert car.position == (5, 4)
