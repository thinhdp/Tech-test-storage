import pytest
from unittest.mock import patch, MagicMock

from src.console_ui import ConsoleUI
from src.field import Field, CollisionPosition
from src.car import Car, Direction


# @patch('builtins.input', return_value='6 5')
# def test_get_field_dimensions_valid_input(mock_input):
#     """
#     Tests that ConsoleUI.get_field_dimensions() returns Field if input is valid
#     """
#     ui = ConsoleUI()
#     field = ui.get_field_dimensions()
#     assert isinstance(field, Field)
#     assert field.width == 6
#     assert field.height == 5


@patch('builtins.input', side_effect=["a", '6 5'])
def test_get_field_dimensions_invalid_then_valid_input(mock_input):
    """
    Tests that ConsoleUI.get_field_dimensions() prompts again if input is invalid
    and returns Field if input is valid
    """
    ui = ConsoleUI()
    field = ui.get_field_dimensions()
    assert isinstance(field, Field)
    assert field.width == 6
    assert field.height == 5


@patch('builtins.input', return_value='1')
def test_get_options_valid_input(mock_input, capsys):
    """
    Tests that ConsoleUI.get_display_options() returns choice if input is valid
    """
    ui = ConsoleUI()
    choice = ui.get_display_options()
    captured = capsys.readouterr()
    assert captured.out == "Please choose from the following options:\n" +\
        "[1] Add a car to field\n" +\
        "[2] Run simulation\n"
    assert choice == "1"


@patch('builtins.input', side_effect=["a", '2'])
def test_get_options_invalid_then_valid_input(mock_input, capsys):
    """
    Tests that ConsoleUI.get_display_options() prompts again if input is invalid
    and ends if input is valid
    """
    ui = ConsoleUI()
    choice = ui.get_display_options()
    captured = capsys.readouterr()
    assert captured.out == "Please choose from the following options:\n" +\
        "[1] Add a car to field\n" +\
        "[2] Run simulation\n" +\
        "Invalid choice a. Please try again\n" +\
        "Please choose from the following options:\n" +\
        "[1] Add a car to field\n" +\
        "[2] Run simulation\n"
    assert choice == "2"


@patch('builtins.input', side_effect=["a", '2 2 N', 'FFF'])
def test_add_car_valid_input(mock_input):
    """
    Tests that ConsoleUI.get_car_inputs() outputs car list
    """
    ui = ConsoleUI()
    car = ui.get_car_inputs()
    assert car.name == "a"
    assert car.position == (2, 2)
    assert car.direction == Direction.NORTH
    assert car.commands == 'FFF'


def test_display_simulation_results(capsys):
    """
    Tests that ConsoleUI.display_simulation_results() outputs correctly
    """
    ui = ConsoleUI()
    carA = Car("A", (1, 2), Direction.NORTH, "FFRFFFFRRL")
    carB = Car("B", (7, 8), Direction.WEST, "FFLFFFFFFF")
    cars_initial = [carA, carB]
    carA_aft = Car("A", (5, 4), Direction.NORTH, "FFRFFFFRRL")
    carB_aft = Car("B", (5, 4), Direction.WEST, "FFLFFFFFFF")
    cars_after = [carA_aft, carB_aft]
    collisions = [
        CollisionPosition(['A', 'B'], (5, 4), 6)
    ]
    ui.display_current_cars(cars_initial)
    ui.display_simulation_results(collisions, cars_after)
    captured = capsys.readouterr()
    assert captured.out == ("Your current list of cars are:\n" +
                            "- A, (1, 2) N, FFRFFFFRRL\n" +
                            "- B, (7, 8) W, FFLFFFFFFF\n\n" +
                            "After simulation, the result is:\n" +
                            "- A, collides with B at (5, 4) at step 7\n" +
                            "- B, collides with A at (5, 4) at step 7\n\n")


@patch('builtins.input', side_effect=["a", '2'])
def test_get_end_option_invalid_then_valid_input(mock_input, capsys):
    """
    Tests that ConsoleUI.get_end_choice() prompts again if input is invaid
    and ends if input is valid
    """
    ui = ConsoleUI()
    choice = ui.get_end_choice()
    captured = capsys.readouterr()
    assert captured.out == ("Please choose from the following options:\n" +
                            "[1] Start over\n" +
                            "[2] Exit\n" +
                            "Invalid choice a. Please try again\n" +
                            "Please choose from the following options:\n" +
                            "[1] Start over\n" +
                            "[2] Exit\n")
    assert choice == "2"


def test_welcome_msg(capsys):
    """Tests welcom msg"""
    ui = ConsoleUI()
    ui.display_welcome_msg()
    captured = capsys.readouterr()
    assert captured.out == "Welcome to Auto Driving Car Simulation!\n\n"


def test_end_msg(capsys):
    """Tests end msg"""
    ui = ConsoleUI()
    ui.display_end_msg()
    captured = capsys.readouterr()
    assert captured.out == "Thank you for running the simulation. Goodbye!\n"
