from unittest.mock import patch

from src.main import main


@patch('builtins.input', side_effect=["10 10", "2", "1", "2 2", "2", "2"])
def test_main_loop_twice(mock_input, capsys):
    """Tests the user is able start over the app and end via inputs"""
    main()
    captured = capsys.readouterr()
    last_sentence = captured.out.split("\n")[-2]
    assert last_sentence == "Thank you for running the simulation. Goodbye!"


@patch('builtins.input', side_effect=["10 10", "1", "A", "1 2 N", "FFRFFFFRRL", "2", "2"])
def test_integration_scenario_1(mock_input, capsys):
    """Tests the user is able start over the simulator and end via inputs"""
    main()

    captured = capsys.readouterr()
    expected_output = (
        "Welcome to Auto Driving Car Simulation!\n\n" +
        "You have created a field of 10 x 10.\n\n" +
        "Please choose from the following options:\n" +
        "[1] Add a car to field\n" +
        "[2] Run simulation\n" +
        "Your current list of cars are:\n" +
        "- A, (1, 2) N, FFRFFFFRRL\n\n" +
        "Please choose from the following options:\n" +
        "[1] Add a car to field\n" +
        "[2] Run simulation\n" +
        "Your current list of cars are:\n" +
        "- A, (1, 2) N, FFRFFFFRRL\n\n" +
        "After simulation, the result is:\n" +
        "- A, (5, 4) S\n\n" +
        "Please choose from the following options:\n" +
        "[1] Start over\n" +
        "[2] Exit\n" +
        "Thank you for running the simulation. Goodbye!\n"
    )
    assert captured.out == expected_output


@patch('builtins.input', side_effect=["10 10", "1", "A", "1 2 N", "FFRFFFFRRL",
                                      "1", "B", "7 8 W", "FFLFFFFFFF", "2", "2"])
def test_integration_scenario_2(mock_input, capsys):
    """Tests the user is able start over the simulator and end via inputs"""
    main()

    captured = capsys.readouterr()
    expected_output = (
        "Welcome to Auto Driving Car Simulation!\n\n" +
        "You have created a field of 10 x 10.\n\n" +
        "Please choose from the following options:\n" +
        "[1] Add a car to field\n" +
        "[2] Run simulation\n" +
        "Your current list of cars are:\n" +
        "- A, (1, 2) N, FFRFFFFRRL\n\n" +
        "Please choose from the following options:\n" +
        "[1] Add a car to field\n" +
        "[2] Run simulation\n" +
        "Your current list of cars are:\n" +
        "- A, (1, 2) N, FFRFFFFRRL\n" +
        "- B, (7, 8) W, FFLFFFFFFF\n\n" +
        "Please choose from the following options:\n" +
        "[1] Add a car to field\n" +
        "[2] Run simulation\n" +
        "Your current list of cars are:\n" +
        "- A, (1, 2) N, FFRFFFFRRL\n" +
        "- B, (7, 8) W, FFLFFFFFFF\n\n" +
        "After simulation, the result is:\n" +
        "- A, collides with B at (5, 4) at step 7\n" +
        "- B, collides with A at (5, 4) at step 7\n\n" +
        "Please choose from the following options:\n" +
        "[1] Start over\n" +
        "[2] Exit\n" +
        "Thank you for running the simulation. Goodbye!\n"
    )
    assert captured.out == expected_output
