# About Auto Driving Car Simulation

## Requirements
The program is designed to run on any operating system that supports Python 3.7 or later. 

Pytest is the only dependent library. To run test please also install `pytest`.

`pip install -r requirements.txt`

## To Run Application
1. Install Python: Ensure you have Python 3.9 or later installed on your system. 
2. Run the Simulation: In the current directory execute the following command:
`python -m src.main`

3. Follow the Prompts: The program will then guide you through the simulation process:
    - Enter the field dimensions
    - Add cars to the field, providing their names, initial positions, directions, and command sequences
    - Run the simulation
    - View the results
    - Choose to start over or exit



## Run Tests
Ensure that the pytest library is installed 

`pip install -r requirements.txt`

1. Run the Tests: In the current directory execute the following command:
`python -m pytest`

2. Include the `-v` flag to see more verbose outputs
`python -m pytest -v`

## Code Design
The code implements a basic autonomous driving car simulation. The design is structured around three core entities: `Car`, `Field`, and `ConsoleUI`, with supporting helper classes `Direction` and `CollisionPosition`.
The `main` function acts as the application's state machine, guiding the user through the simulation process and coordinating actions between the `ConsoleUI` and `Field`

The classes are:
- The `Car` class manages individual car states and movements 
- The `Field` class oversees the simulation area, car collection, and collision detection
- The `ConsoleUI` handles all displays and user inputs 
- Helper classes like `Direction` (for movement) and `CollisionPosition` (for tracking collisions) support the core logic.

The separation of classes follows Model-View-Controller (MVC) architectural pattern:
- The Model is represented by the `Car`, `Field`, `Direction`, and `CollisionPosition` classes, which encapsulate data and business logic.
- The View is implemented by the `ConsoleUI` class, handling all presentation and input gathering.
- The Controller is fulfilled by the `main` function, acting as the intermediary, interpreting user input, updating the Model, and telling the View what to display.

## Assumptions
- Coordinates are integers.
- The program assumes that the user will enter valid input.  However, it does include basic input validation and error handling (e.g., checking for integer dimensions, valid directions, and command formats).
- Cars execute one command at a time in a round-robin fashion in order of when it is added to field. 
    - (Step1 )A->B-> (Step 2) A->B, 
    - if A is initially at (1,1) and moves to (2,1). No collision if B moves to (1,1) during the same step
    - if B is intially at (1,1) and supposed to move to (2,1). There will be colision if A moves to (2,1) during the same step
- When cars collide, they stop moving and no further commands are processed.  The simulation reports the collision positions and the cars involved. The simulation will continue for cars that were not involved in the collision.
- The field is a rectangle, with the bottom-left corner at (0, 0).
- Each car has a unique name.
-  Cars accept a set of commands ('L', 'R', 'F').
- No Obstacles: The field is assumed to be empty except for the cars.  There are no other obstacles.

