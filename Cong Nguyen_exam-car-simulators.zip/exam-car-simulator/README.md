# Auto Driving Car Simulator

This project is a simulation program for autonomous driving cars, designed to demonstrate clean code, object-oriented principles, and adherence to SOLID principles.

## Features
- SimulationEngine.js: A core module that orchestrates the simulation.Handles car movement, collision detection, and simulation steps.
- Simulates a rectangular field where cars can move and interact.
- Supports adding multiple cars with unique names, starting positions, and directions.
- Processes commands (`L`, `R`, `F`) for each car to rotate or move.
- Detects collisions between cars and stops further movement for collided cars.
- Fully interactive command-line interface (CLI).
# Collision Detection Logic
The detectCollision method in the SimulationEngine class is responsible for identifying collisions between cars during the simulation. Here's how it works:
Tracking Positions:

1. Tracking Positions: The method in the field class and it uses a Map data structure to track the positions of all cars on the field.
Each car's position is stored as a key in the map, and the car object is stored as the value.

2. Collision Detection: As each car moves, its new position is checked against the map.
If the position already exists in the map, it means another car is already at that position, and a collision is detected.

3. Collision Handling:
When a collision is detected:
    Both cars involved in the collision are marked as collided.
    The method returns the details of the collision, including the cars involved and the position of the collision


---

## Project Structure
    .
    ├── src/
        ├── car.js # Car class: Handles car properties and movement logic│ 
        ├── field.js # Field class: Manages the field and cars
        ├── simulation.js # Simulation class: Handles CLI and      simulation logic 
        ├── tests/ │ 
        ├── car.test.js # Unit tests for the Car class │ 
        ├── field.test.js # Unit tests for the Field class │ 
        ├── index.js # Entry point for the application 
        ├── package.json # Project dependencies and scripts 
        └── README.md # Project documentation
---

## How to Start

### Prerequisites
- Node.js (v18 or higher)
- npm (Node Package Manager)

### Installation
1. Clone the repository:
   ```bash
   unzip the exam-car-simulator.zip
   cd exam-car-simulator
   ```
2. Install dependencies:
```bash
    npm install
```
3. Run app
```bash
    npm start
```

### Testing
1. Run all tests using Jest:
```bash
    npm test
```

### Adherence to SOLID Principles
1. Single Responsibility Principle (SRP)
Each class (Car, Field, Simulation) has a single responsibility:
Car: Handles car properties and movement logic.
Field: Manages the field and cars.
Simulation: Handles user interaction and simulation flow.

2. Open/Closed Principle (OCP)
The code is open for extension but closed for modification:
New commands or features can be added without modifying existing classes.

3. Liskov Substitution Principle (LSP)
Objects of a superclass (Car, Field) can be replaced with objects of their subclasses without breaking the program.

4. Interface Segregation Principle (ISP)
The Simulation class provides a clean interface for interacting with the simulation, without exposing unnecessary details.

5. Dependency Inversion Principle (DIP)
High-level modules (e.g., Simulation) depend on abstractions (Car, Field), not on low-level details.

### Applied Design pattern
1. Command Classes, each command (RotateLeft, RotateRight, MoveForward) is encapsulated in its own class.
These classes implement an execute method that performs the specific action on the Car object.

2. The Singleton Pattern is applied to the CLIConsole class to ensure that only one instance of the console exists throughout the application. This design pattern is particularly useful for managing shared resources like the command-line interface (CLI) and ensuring consistent behavior across the application.

3. The Factory Pattern is applied to the Car class to encapsulate the creation logic of Car objects. This design pattern provides a centralized and consistent way to create Car instances, improving code readability, maintainability, and scalability

4. DI: SimulationEngine class that has passed dependencies like the Field object and other potential collaborators (e.g., collision detection strategies) as constructor arguments. This approach decouples the SimulationEngine from specific implementations, making it more flexible, testable, and easier to maintain

### Test-Driven Development (TDD) Note
1. Write Tests First:

Before implementing a feature, unit tests were written to define the expected behavior.
For example, tests for the Car class ensured correct movement, rotation, and command execution before the implementation.

2. Red-Green-Refactor Cycle:

Red: Write failing tests for unimplemented features.
Green: Implement the feature to make the tests pass.
Refactor: Clean up the code while ensuring all tests still pass.

3. Comprehensive Test Coverage:
Unit tests cover all core functionalities:
Car Class: Initialization, movement, rotation, and command execution.
Field Class: Adding cars, collision detection, and simulation steps.
