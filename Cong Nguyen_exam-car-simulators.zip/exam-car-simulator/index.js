const CLIConsole = require('./src/cliConsole');

const cliConsole = new CLIConsole();
cliConsole.startSimulation();