class Field {
  constructor(width, height) {
    this.width = width;
    this.height = height;
    this.cars = [];
  }

  addCar(car) {
    if (car.x < 0 || car.x >= this.width || car.y < 0 || car.y >= this.height) {
      throw new Error('Car position is out of bounds.');
    }
    if (this.cars.some((existingCar) => existingCar.name === car.name)) {
      throw new Error('Car with the same name already exists.');
    }
    this.cars.push(car);
  }
  getCarStatuses() {
    return this.cars.map((car) => car.getStatus());
  }
}
class FieldFactory {
  static createField(width, height) {
    return new Field(width, height);
  }
}

module.exports = { Field, FieldFactory };