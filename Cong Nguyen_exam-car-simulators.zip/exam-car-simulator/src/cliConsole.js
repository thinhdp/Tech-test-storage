const { CarFactory } = require('./car');
const { FieldFactory } = require('./field');
const { SimulationEngine } = require('./simulationEngine');
const readline = require('readline');

class CLIConsole {
  static instance;
  constructor() {
    if (SimulationEngine.instance) {
      return SimulationEngine.instance;
    }
    this.rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
    });
    this.simulationEngine = null;
    SimulationEngine.instance = this;
  }

  async askQuestion(query) {
    return new Promise((resolve) => {
      this.rl.question(query, (answer) => resolve(answer));
    });
  }

  async mainMenu() {
    console.log('\nPlease choose from the following options:');
    console.log('[1] Add a car to the field');
    console.log('[2] Run simulation');
    console.log('[3] Start over');
    console.log('[4] Exit');
    const choice = await this.askQuestion('Enter your choice: ');

    switch (choice) {
      case '1':
        await this.addCarMenu();
        break;
      case '2':
        await this.runSimulation();
        break;
      case '3':
        await this.startSimulation();
        break;
      case '4':
        console.log('Thank you for running the simulation. Goodbye!');
        this.rl.close();
        break;
      default:
        console.log('Invalid choice. Please try again.');
        await this.mainMenu();
    }
  }

  async addCarMenu() {
    const name = await this.askQuestion('Please enter the name of the car: ');
    const position = await this.askQuestion(`Please enter the initial position of car ${name} in x y Direction format: `);
    const [x, y, direction] = position.split(' ');
    try {
      const commands = await this.askQuestion(`Please enter the commands for car ${name}: `);
      const car = CarFactory.createCar(name, parseInt(x), parseInt(y), direction, commands);
      this.simulationEngine.field.addCar(car);
      console.log(`Car ${name} added at (${x}, ${y}) facing ${direction} with commands: ${commands}`);
      console.log('Your current list of cars are:');
      this.simulationEngine.field.getCarStatuses().forEach((status) => console.log(`- ${status}`));
      await this.mainMenu();
    } catch (error) {
      console.log(error.message);
      await this.addCarMenu();
    }
  }

  async runSimulation() {
    if (this.simulationEngine.field.cars.length === 0) {
      console.log('No cars in the field. Please add a car first.');
      return await this.mainMenu();
    }

    console.log('Your current list of cars are:');
    this.simulationEngine.field.getCarStatuses().forEach((status) => console.log(`- ${status}`));
    const result = this.simulationEngine.simulate() // Updated to use step-by-step simulation
    console.log('After simulation, the result is:');
    if (result.collided) {
        const { collision, step } = result;
        const collisions = [
          `- ${collision.car1.name}, collides with ${collision.car2.name} at (${collision.position}) at step ${step}`,
          `- ${collision.car2.name}, collides with ${collision.car1.name} at (${collision.position}) at step ${step}`,
        ];
        collisions.forEach((collision) => console.log(collision));
    } else {
      console.log('Simulation completed without collisions.');
      this.simulationEngine.field.getCarStatuses().forEach((status) => console.log(`- ${status}`));
    }
    await this.mainMenu();
  }

  async startSimulation() {
    console.log('Welcome to Auto Driving Car Simulation!');
    const dimensions = await this.askQuestion('Please enter the width and height of the simulation field in x y format: ');
    const [width, height] = dimensions.split(' ').map(Number);

    if (isNaN(width) || isNaN(height) || width <= 0 || height <= 0) {
      console.log('Invalid field dimensions. Please try again.');
      return await this.startSimulation();
    }

    this.simulationEngine = new SimulationEngine(FieldFactory.createField(width, height));
    console.log(`You have created a field of ${width} x ${height}.`);
    await this.mainMenu();
  }
}

module.exports = CLIConsole;