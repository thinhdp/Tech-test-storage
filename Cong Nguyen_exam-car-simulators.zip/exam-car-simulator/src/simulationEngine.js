class SimulationEngine {
  constructor(field) {
    this._field = field; // The field object containing cars and dimensions
  }
  get field() {
    return this._field;
  }
  set field(value) {
    if (value instanceof Field) {
      this._field = value;
    } else {
      throw new Error('Invalid field object');
    }
  }
  moveCar(car) {
    if (car.collided) return; // Skip cars that have already collided

    const command = car.commands[0];
    if (!command) return; // No commands left to execute

    car.executeCommand(command, this.field.width, this.field.height);
    car.commands = car.commands.slice(1); // Remove the executed command
  }

  detectCollision() {
    const positions = new Map();
    for (const car of this.field.cars) {
      if (car.collided) continue; // Skip cars that have already collided
      const position = `${car.x},${car.y}`;
      if (positions.has(position)) {
        const otherCar = positions.get(position);
        car.collided = true;
        otherCar.collided = true;
        return { car1: car, car2: otherCar, position };
      }
      positions.set(position, car);
    }
    return null; // No collision detected
  }

  simulateStep() {
    for (const car of this.field.cars) {
      this.moveCar(car);
    }
    return this.detectCollision();
  }

  simulate() {
    let step = 0;
    while (this.field.cars.some((car) => car.commands.length > 0 && !car.collided)) {
      step++;
      const collision = this.simulateStep();
      if (collision) {
        return {
          message: `Collision detected between ${collision.car1.name} and ${collision.car2.name} at (${collision.position}) on step ${step}.`,
          collided: true,
          collision,
          step,
        };
      }
    }
    return { collided: false };
  }
}

module.exports = { SimulationEngine };