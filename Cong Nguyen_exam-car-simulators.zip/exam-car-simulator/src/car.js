class RotateLeftCommand {
  execute(car) {
    const currentIndex = car.constructor.DIRECTIONS.indexOf(car.direction);
    car.direction = car.constructor.DIRECTIONS[(currentIndex - 1 + 4) % 4];
  }
}

class RotateRightCommand {
  execute(car) {
    const currentIndex = car.constructor.DIRECTIONS.indexOf(car.direction);
    car.direction = car.constructor.DIRECTIONS[(currentIndex + 1) % 4];
  }
}

class MoveForwardCommand {
  execute(car) {
    if (car.direction === 'N' && car.y < car.height - 1) {
      car.y += 1;
    } else if (car.direction === 'E' && car.x < car.width - 1) {
      car.x += 1;
    } else if (car.direction === 'S' && car.y > 0) {
      car.y -= 1;
    } else if (car.direction === 'W' && car.x > 0) {
      car.x -= 1;
    }
  }
}
class Car {
  static DIRECTIONS = ['N', 'E', 'S', 'W']; // North, East, South, West

  constructor(name, x, y, direction, commands = '', width = 10, height = 10) {
    if (!Car.DIRECTIONS.includes(direction)) {
      throw new Error('Invalid direction. Please use N, E, S, or W.');
    }
    this.name = name;
    this.x = x;
    this.y = y;
    this.direction = direction;
    this.commands = commands;
    this.collided = false;
    this.width = width;
    this.height = height;
  }

  executeCommand(command) {
    let commandInstance;
    if (command === 'L') {
      commandInstance = new RotateLeftCommand();
    } else if (command === 'R') {
      commandInstance = new RotateRightCommand();
    } else if (command === 'F') {
      commandInstance = new MoveForwardCommand();
    } else {
      throw new Error(`Invalid command: ${command}`);
    }
    commandInstance.execute(this);
  }

  simulate() {
    for (const command of this.commands) {
      this.executeCommand(command, this.width, this.height);
    }
  }

  getStatus() {
    let status = `${this.name}, (${this.x},${this.y}) ${this.direction}`
    if (this.commands) {
      status+= `, ${this.commands}`
    }
    return status;
  }

}
class CarFactory {
  static createCar(name, x, y, direction, commands = '') {
    return new Car(name, parseInt(x), parseInt(y), direction, commands);
  }
}
module.exports = { Car, CarFactory };