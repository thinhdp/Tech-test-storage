const { Field } = require('../src/field');
const { Car } = require('../src/car');

describe('Field Class', () => {
  test('should throw an error add add out of bound', () => {
    const field = new Field(10, 10);
    const carA = new Car('A', 11, 2, 'N');
    const carB = new Car('A', 3, 11, 'E'); // Duplicate name
    expect(() => field.addCar(carA)).toThrow('Car position is out of bounds.');
  });
    test('should detect collisions correctly', () => {
    const field = new Field(10, 10);
    const carA = new Car('A', 1, 2, 'N', 'FFRFFFFRRL');
    const carB = new Car('B', 7, 8, 'W', 'FFLFFFFFFF');
    field.addCar(carA);
    field.addCar(carB);
    expect(carA).toBe(field.cars[0]);
    expect(carB).toBe(field.cars[1]);
  });

});