const { Car } = require('../src/car');

describe('Car Class', () => {
  test('should throw an error for invalid direction', () => {
    expect(() => new Car('A', 1, 2, 'GG', 'FFR')).toThrow('Invalid direction. Please use N, E, S, or W.');
  });
  
  test('should initialize a car with correct properties', () => {
    const car = new Car('A', 1, 2, 'N', 'FFR');
    expect(car.name).toBe('A');
    expect(car.x).toBe(1);
    expect(car.y).toBe(2);
    expect(car.direction).toBe('N');
    expect(car.commands).toBe('FFR');
    expect(car.collided).toBe(false);
  });

  test('should rotate left correctly', () => {
    const car = new Car('A', 1, 2, 'N');
    car.executeCommand('L');
    expect(car.direction).toBe('W');
    car.executeCommand('L');
    expect(car.direction).toBe('S');
  });

  test('should rotate right correctly', () => {
    const car = new Car('A', 1, 2, 'N');
    car.executeCommand('R');
    expect(car.direction).toBe('E');
    car.executeCommand('R');
    expect(car.direction).toBe('S');
  });

  test('should not move forward out of bounds', () => {
    const car = new Car('A', 0, 0, 'S');
    car.executeCommand('F');
    expect(car.y).toBe(0);
    car.direction = 'W';
    car.executeCommand('F');
    expect(car.x).toBe(0);
  });

  test('should simulate commands correctly', () => {
        const car = new Car('A', 1, 2, 'N', 'FFRFFFFRRL');
        car.simulate();
        expect(car.x).toBe(5);
        expect(car.y).toBe(4);
        expect(car.direction).toBe('S');
  });
   test('should move forward correctly within bounds', () => {
    const car = new Car('A', 1, 2, 'N');
    car.executeCommand('F');
    expect(car.y).toBe(3);
    car.direction = 'E';
    car.executeCommand('F');
    expect(car.x).toBe(2);
  });

  test('should execute commands correctly', () => {
    const car = new Car('A', 1, 2, 'N', 'FFR');
    car.executeCommand('F');
    expect(car.y).toBe(3);
    car.executeCommand('R');
    expect(car.direction).toBe('E');
  });

  test('should return correct status', () => {
    const car = new Car('A', 1, 2, 'N', 'FFR');
    expect(car.getStatus()).toBe('A, (1,2) N, FFR');
  });
});