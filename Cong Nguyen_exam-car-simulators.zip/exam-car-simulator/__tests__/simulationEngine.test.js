const { Field } = require('../src/field');
const { Car } = require('../src/car');
const { SimulationEngine } = require('../src/simulationEngine');

describe('SimulationEngine Class', () => {
  test('should move a car forward correctly', () => {
    const field = new Field(10, 10);
    const car = new Car('A', 1, 2, 'N', 'F');
    field.addCar(car);
    const engine = new SimulationEngine(field);
    engine.moveCar(car);
    expect(car.x).toBe(1);
    expect(car.y).toBe(3); // Car moves forward
    expect(car.commands).toBe(''); // Command is consumed
  });

  test('should detect collisions between cars', () => {
    const field = new Field(10, 10);
    const carA = new Car('A', 1, 2, 'N', 'L');
    const carB = new Car('B', 1, 2, 'S', 'R');
    field.addCar(carA);
    field.addCar(carB);
    const engine = new SimulationEngine(field);
    const result = engine.simulate();
    expect(result.collided).toBeTruthy();
    expect(result.collision.car1).toBe(carB);
    expect(result.collision.car2).toBe(carA);
    expect(result.collision.position).toBe('1,2');
  });

  test('should simulate step-by-step without collisions', () => {
    const field = new Field(10, 10);
    const carA = new Car('A', 1, 2, 'N', 'F');
    const carB = new Car('B', 3, 3, 'E', 'F');
    field.addCar(carA);
    field.addCar(carB);
    const engine = new SimulationEngine(field);
    const result = engine.simulate();
    expect(result.message).toBe(undefined);
  });

  test('should simulate step-by-step with collisions', () => {
    const field = new Field(10, 10);
    const carA = new Car('A', 1, 2, 'N', 'R');
    const carB = new Car('B', 1, 2, 'S', 'L');
    field.addCar(carA);
    field.addCar(carB);

    const engine = new SimulationEngine(field);
    const result = engine.simulate();

    expect(result.message).toBe(
      'Collision detected between B and A at (1,2) on step 1.'
    );
    expect(result.collision.car1).toBe(carB);
    expect(result.collision.car2).toBe(carA);
    expect(result.collision.position).toBe('1,2');
  });

});