## Candidate Information:
Name: CHNG Soon Siang

Email: jymchng@hotmail.com

## Technical Information:
Language Used: Python

Python Version: 3.10.6

Operating System: Windows

Python Build Tool Used: poetry

## Foreword
Thank you for this opportunity to write this application. I had a lot of fun working on it!

## Pre-Steps

In all of the technical instructions listed below, please do this step beforehand:

1. Make sure your terminal is at the `gic-assignment` folder, it is the folder with the hyphen `-` (i.e. **NOT** `gic_assignment`, the one with an `'_'`). It is also where both `pyproject.toml` and this `README.md` files are located.
2. Install Python version 3.10.6 ([installation link](https://www.python.org/downloads/release/python-3106/)) or any Python executable of a higher version for your own operating system.

## To Run the Application

1. Run the following command:
```bash
python -m gic_assignment.app
```
2. You should see the following output:
```bash
Welcome to Auto Driving Car Simulation!
Please enter the width and height of the simulation field in x y format:
```
3. Enjoy!

### Troubleshooting

1. If you encounter any error, do make sure that you have at least Python version 3.10.6 and above, please try again after ensuring this.
2. If the error is insurmountable, feel free to contact the author of this application at the email address stated at the top of this document.

## To Print Debug Statements While Running the Application

1. Set an environment variable named `DEBUG_PRINT` and set its value to `1`, on `bash` it is like so (find out how to set environment variables on your specific terminal):
```bash
export DEBUG_PRINT=1
```
2. Run the application (see above).

## To Run the Tests

1. Run the following command:
```bash
python -m pytest tests
```

2. If you do not have `pytest` installed or you saw this error `No module named pytest` while running the previous command, then run the following:
```bash
python -m pip install pytest
```

3. An **example** output is like so (yours may differ, do not be alarmed):
```bash
F:\py_projects\gic-assignment>python -m pytest tests
======================================================================================== test session starts =========================================================================================
platform win32 -- Python 3.10.6, pytest-8.0.2, pluggy-1.4.0
rootdir: F:\py_projects\gic-assignment
collected 10 items

tests\test_bounded_int.py ...                                                                                                                                                                   [ 30%] 
tests\test_command.py ..                                                                                                                                                                        [ 50%] 
tests\test_direction.py ..                                                                                                                                                                      [ 70%] 
tests\test_position.py ...                                                                                                                                                                      [100%]

========================================================================================= 10 passed in 0.20s ========================================================================================= 
```

## Writeup on the Assignment

## Feature of the Application

The application can also detect collisions with multiple cars and at different steps.

If you run the following command:

```bash
python -m scripts.run_simulation_adhoc
```

You will see the following output:
```bash
Your current list of cars are:
- A, (1,2) N, FFRFFFFRRL
- B, (7,8) W, FFLFFFFFFF
- C, (4,4) E, FFFFFFRRFFFFFF

After simulation, the result is:
- A, collides with B at (5,4) at step 7
- A, collides with C at (5,4) at step 13
- B, collides with A at (5,4) at step 7
- B, collides with C at (5,4) at step 13
- C, collides with A, B at (5,4) at step 13
```

This shows that the program can detect that car A first collides with car B at step 7, then again with car C at step 13 because car C moved into position (5,4) at step 13.
Car C is shown to have collided into both cars A and B at (5,4) at step 13 when it moves into that position at that step.

## Design Principles

Overview: 
1. Software Engineering is almost always about **changes**. Changes in purpose of the application, changes in requirements and many more.
2. Hence, good software engineering practices aim to make change as easy as possible.
3. Many design patterns strive to make the engineers' lives easier by making refactoring and code changes as easy as possible.

## Design Principle: Always make codes modular and reusable

Even though the assignment is on building an application, a good engineer with foresight will write most parts of this application as libraries or packages, so that they can be stored in a package/artifact repository (e.g. Nexus, Azure DevOps) and be reused by others.

In this assignment, the folder `gic_assignment/core` stores all the modules that are **reusable**. The application itself resides within the `gic_assignment/app` folder, has only 2 classes `App` and `AppState` in `core.app` module and these are only relevant to the application itself (or in binary of other languages like Rust). The application uses almost all components that are found in `core` and likewise, other engineers can use classes like `BoundedInt` once the `core` package is checked into the artifact repository.

The `__main__.py` file in `gic_assignment/app` is only a few lines long:
```python
from gic_assignment.app.app import (
    App,
    AppState,
)

app = App()
state = None

try:
    while state is not AppState.QUIT:
        state = app.run()
except Exception as err:
    print("[ERROR]: Unrecoverable error, please file a ticket with the administrator of this App.")
    print(f"[ERROR-MESSAGE]: {err}")
    import sys
    sys.exit(1)
```

## Design Principle: (TDD) Test Driven Development

**Examples**

I am a firm believer of TDD, because of two reasons:

1. It ensures the codes are working correctly, and,
2. Most importantly, it removes the toil of manually checking the codes are working correctly after a major refactoring; this removes a big hurdle that engineers typically face when trying to refactor large codebases.

These modules, namely, `bounded_int`, `command`, `direction`, `position` and `simulation`, have unit tests written.

Notably, the `App` from `gic_assignment.app.app` have **end-to-end** integration tests done.

```
@pytest.fixture
def app_ready_to_run_simulation(app_to_add_car_or_run: "App"):
    
    fake_adding_car_a = pseudo_add_car_a()
    fake_adding_car_b = pseudo_add_car_b()
    
    with MockInputFunction(side_effect=list(fake_adding_car_a)):
        rv = app_to_add_car_or_run.add_car_or_run_simulation()
        assert rv is AppState.REPLAY
        
    with MockInputFunction(side_effect=list(fake_adding_car_b)):
        rv = app_to_add_car_or_run.add_car_or_run_simulation()
        assert rv is AppState.REPLAY
        
    return app_to_add_car_or_run


def test_simulation_is_working_and_quit(app_ready_to_run_simulation: "App", capfd: "CaptureFixture"):
    
    with MockInputFunction(side_effect="2"):
        rv = app_ready_to_run_simulation.run_simulation()
        assert rv is AppState.QUIT
    
    out, _ = capfd.readouterr()
    
    assert out == 'Your current list of cars are:\n- A, (1,2) N, FFRFFFFRRL\n- B, (7,8) W, FFLFFFFFFF\n\nAfter simulation, the result is:\n- A, collides with B at (5,4) at step 7\n- B, collides with A at (5,4) at step 7\n\nPlease choose from the following options:\n[1] Start Over\n[2] Exit\n2\nThank you for running the simulation. Goodbye!\n'
```

`app_ready_to_run_simulation` is a fixture that 'fast-forward' the `App` to the state where it is ready to run the simulation, then `test_simulation_is_working_and_quit` tests if it does run and outputs the expected output to the console.

A variant of TDD is the Type Driven Development, which is popularized by the Rust programming language.

For example, in my crate (Rust's parlance for a library) [`sosecrets-rs`](https://github.com/jymchng/sosecrets-rs/blob/master/src/secret.rs#L50), the type [`Secret<T, MEC, EC>`](https://github.com/jymchng/sosecrets-rs/blob/master/src/secret.rs#L50) where `MEC` represents a type level unsigned integer (i.e. 0 or greater), which also represents semantically, the maximally exposure count for the encapsulated secret of type `T`. Because `MEC` must fulfil the trait `Unsigned`, it cannot be smaller than 0 and is guaranteed by the type system and hence, no tests are written for this. You can use `trybuild` crate to test that a code with the type argument not fulfilling the trait bound will not be compilable, but it is almost practically redundant to write test for it.

```rust
pub struct Secret<
    #[cfg(feature = "zeroize")] T: Zeroize,
    #[cfg(not(feature = "zeroize"))] T,
    MEC: Unsigned, // <-- `Unsigned` is a trait
    EC: Add<U1> + IsLessOrEqual<MEC, Output = True> + Unsigned = U0,
>(ManuallyDrop<T>, PhantomData<(MEC, EC)>);
```

## Design Principle: (OOP) Separation of Responsibilities and Encapsulation

**Examples**

1. `BoundedInt` residing in `core.bounded_int` takes care of its own addition and subtraction behaviours. Itself is an integer that is bounded by the `self.upper_bound` and `self.lower_bound` instance variables and will not exceed the bounds either during addition and subtraction.
2. Enum-like classes, `Command` in `core.command` and `Direction` in `core.direction`, are encapsulated as a single domain entity, either as a `Command` for the execution of the `Car` or as a `Direction` for similar intent. `Direction` also took care of rotating itself when receiving `Command.ROTATE_LEFT` or `Command.ROTATE_RIGHT` in the `rotate(...)` method.
3. `BoundedPosition` residing in `core.position`, took care of how it updates itself to a new position via its method `move_to_new_position(...)`, given both inputs of type `Direction` and `Command`.
4. `Car`, residing in `core.simulation`, took care of its `bounded_position: "BoundedPosition"` field and its execution of the individual commands it receive by updating its `direction` and `bounded_position` fields. It also took care of its own state, whether it is collided or not, and maintain its own list of `CollisionInfo` to preserve this information.
5. `Simulation` in `core.simulation` takes care of maintaining a list of `Car`s and drive the execution of `Command` of each of the `Car` through each step. It also took care of detecting collisions between cars and let each `Car` knows whether it has been collided through `Car`'s public API, `add_collision_info(...)`. It is `Car`'s own responsbility to determine if the `CollisionInfo` that `Simulation` wants it to add into `Car`'s own list of `CollisionInfo` makes sense.
6. All classes took care of its own serialization and deserialization. E.g. `Simulation` does not need to know how to serialize each `Car` in its maintained list of `Car`s.

## Design Principle: If the program is going to fail, then it should fail as early as possible and with as much information as possible

**Example One**

If my program is going to fail, as it would realistically, I would make sure that the error messages are as informative as possible, so that I would be able to identify right away what are the problems.

I wrote the `ErrorsHandler` (in `gic_assignment.core.error` module) class to collate all the errors that I anticipate during the program flow and display them all at once so that I can deal with many errors at one go. For example:

If you write to create an instance of `BoundedPosition` like so
```python
bounded_position = BoundedPosition(5, 2, 0, 0)
```

You will get an error message like so:
```bash
[ERROR]: List of Errors encountered =>
Exception: UpperBoundMustBeGreaterThanLowerBound; Message: [ERROR]: `upper_bound` = `0` must be strictly greater than `lower_bound` = `0`.
Exception: ValueError; Message: [Error]: `BoundedInt` `upper_bound` must be strictly larger than zero; instead it is 0
```

This way, the engineer can fix two errors at one go, instead of fixing one, then running the application only to get another error to fix.

**Example Two**

The class `BoundedInt` inherits from `int` directly, instead of keeping an `int` typed instance variable (maybe named as `._value`).

```python
class BoundedInt(int):

    upper_bound: "int"
    lower_bound: "int" = 0
    # ... omitted ...
    # no `_value: "int"` defined
```

As Python does not support private variables, encapsulation of integer types by composition may not ensure that `BoundedInt` will not be misused as users can modify the inner integer typed field. This way of inheriting from `int` ensures that getting an instance of `BoundedInt` means it is far less likely that its class invariance is violated.

**Example Three**

In Python, there is no concept of compile time. However, there is the idea of 'class definition' time, which is the time during which the interpretor parses the codes scoped by the `class` keyword. This is where metaclass programming can come in handy. In this assignment, I have not used any serious metaclass programming, although I have used a mild version of it in writing the `Direction` and `Command` enum-like classes (because I need the enum variants to be singletons and classes are singletons).

You can see more metaclass programming on one of my published Python libraries, [`truconsts`](https://github.com/jymchng/truconsts/blob/master/src/truconsts/constmeta.pyx#L28), which is also written in Cython.

Pushing checks to compile time is a trait strongly demonstrated in one of my Rust's libraries, [`sosecrets-rs`](https://github.com/jymchng/sosecrets-rs/blob/master/src/secret.rs#L126). `Secret<T, MEC, EC>` is a Rust type where the secret cannot be exposed more than `MEC` number of times, and if the codes do otherwise, the program becomes uncompilable. In other words, all programs that use this library can be guaranteed that secrets stored in `Secret<T, MEC, EC>` are **never** exposed more than `MEC` number of times.

## Design Principle: (OOP) Making classes easy to extend but close for modifications

An example would be the `Command` class. Note that `STAY_PUT: STAY_PUT` is a variable declaration with type annotation, the actual class variable is injected in the `__init_subclass__` method of `CommandVariant`. This way, new variant (optionally, you may choose to write its type annotation under the `Command` class, it is perfectly fine even if you don't) can be added to `Command` without adding it directly to the `Command` class definition.

```python
class Command(CommandVariant):

    STAY_PUT: STAY_PUT
    ROTATE_LEFT: ROTATE_LEFT
    ROTATE_RIGHT: ROTATE_RIGHT
    MOVE_FORWARD: MOVE_FORWARD

    @classmethod
    def from_char(
            cls,
            ch: "Union[Literal[' '], Literal['L'], Literal['R'], Literal['F']]"
    ) -> "Union[STAY_PUT, ROTATE_LEFT, ROTATE_RIGHT, MOVE_FORWARD]":

        whitespace = WHITESPACE
        for command in CommandVariant._command_subclasses:
            if command.as_char == ch:
                return command
            if ch == whitespace:
                return STAY_PUT

        raise TypeError(
            f"[Error]: `Command.from_char` expects an input of type `str`,\
            instead got: {type(ch)}.")

    @classmethod
    def valid_chars(_cls) -> "str":
        return 'FRL'
```
