from gic_assignment.core.simulation import (
    Car,
    Simulation,
)
from gic_assignment.core.direction import (
    Direction,
)
from gic_assignment.core.position import (
    BoundedPosition,
)

simulation = Simulation(10, 10)

direction = Direction.from_char('N')
bounded_position = BoundedPosition(1, 2, 10, 10)

car_a = Car(
    'A',
    bounded_position=bounded_position,
    direction=direction,
    commands=Car.parse_string_into_list_of_commands('FFRFFFFRRL'))

simulation.add_car_to_simulation(car_a)

direction = Direction.from_char('W')
bounded_position = BoundedPosition(7, 8, 10, 10)

car_b = Car(
    'B',
    bounded_position=bounded_position,
    direction=direction,
    commands=Car.parse_string_into_list_of_commands('FFLFFFFFFF'))
simulation.add_car_to_simulation(car_b)

car_c = Car(
    'C',
    bounded_position=BoundedPosition(4, 4, 10, 10),
    direction=Direction.from_char('E'),
    commands=Car.parse_string_into_list_of_commands('FFFFFFRRFFFFFF'))
simulation.add_car_to_simulation(car_c)

print("Your current list of cars are:")
print(simulation.car_list_as_string())
print("After simulation, the result is:")
simulation_result = simulation.run()
print(simulation_result)
