autopep8 -a -a -a -a -a -i -p 10 -r .
ruff .
mypy .