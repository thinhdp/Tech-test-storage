from gic_assignment.app.app import (
    App,
    AppState,
)
import pytest
from unittest.mock import (
    Mock,
    patch,
)
from io import StringIO
from typing import TYPE_CHECKING
from pytest import (
    CaptureFixture,
)

if TYPE_CHECKING:
    from typing import (
        Generator,
        Any,
        Iterable,
        Union,
        Optional,
    )

from unittest.mock import call


class MockInputFunction:
    def __init__(
            self,
            return_value: "Optional[Any]" = None,
            side_effect: "Optional[Union[Any, Iterable[Any]]]" = None):
        self.return_value = return_value
        self.side_effect = side_effect
        self.mock_calls = []
        self._orig_input_fn = __builtins__['input']

    def _mock_input_fn(self, prompt: "str" = None):
        return_value = self.return_value if self.side_effect is None else self.side_effect[len(
            self.mock_calls)]
        self.mock_calls.append(call(prompt))
        if prompt:
            print(prompt + str(return_value))
        else:
            print(str(return_value))
        return return_value

    def __enter__(self):
        __builtins__['input'] = self._mock_input_fn

    def __exit__(self, type, value, traceback):
        __builtins__['input'] = self._orig_input_fn


@pytest.fixture
def app_start() -> "App":
    return App()


@pytest.fixture
def app_to_add_car_or_run(app_start: "App") -> "App":

    with patch('builtins.input', return_value="10 10"):
        app_start.prompt_width_height_of_the_field()

    return app_start


@pytest.fixture
def app_ready_to_run_simulation(app_to_add_car_or_run: "App"):
    
    fake_adding_car_a = pseudo_add_car_a()
    fake_adding_car_b = pseudo_add_car_b()
    
    with MockInputFunction(side_effect=list(fake_adding_car_a)):
        rv = app_to_add_car_or_run.add_car_or_run_simulation()
        assert rv is AppState.REPLAY
        
    with MockInputFunction(side_effect=list(fake_adding_car_b)):
        rv = app_to_add_car_or_run.add_car_or_run_simulation()
        assert rv is AppState.REPLAY
        
    return app_to_add_car_or_run


def test_simulation_is_working_and_quit(app_ready_to_run_simulation: "App", capfd: "CaptureFixture"):
    
    with MockInputFunction(side_effect="2"):
        rv = app_ready_to_run_simulation.run_simulation()
        assert rv is AppState.QUIT
    
    out, _ = capfd.readouterr()
    
    assert out == 'Your current list of cars are:\n- A, (1,2) N, FFRFFFFRRL\n- B, (7,8) W, FFLFFFFFFF\n\nAfter simulation, the result is:\n- A, collides with B at (5,4) at step 7\n- B, collides with A at (5,4) at step 7\n\nPlease choose from the following options:\n[1] Start Over\n[2] Exit\n2\nThank you for running the simulation. Goodbye!\n'


def test_simulation_is_working_and_start_over(app_ready_to_run_simulation: "App", capfd: "CaptureFixture"):
    
    with MockInputFunction(side_effect="1"):
        rv = app_ready_to_run_simulation.run_simulation()
        assert rv is AppState.START_OVER
    
    out, _ = capfd.readouterr()
    
    assert out == 'Your current list of cars are:\n- A, (1,2) N, FFRFFFFRRL\n- B, (7,8) W, FFLFFFFFFF\n\nAfter simulation, the result is:\n- A, collides with B at (5,4) at step 7\n- B, collides with A at (5,4) at step 7\n\nPlease choose from the following options:\n[1] Start Over\n[2] Exit\n1\n'
    

def pseudo_add_car_a() -> "Generator[None, None, str]":
    yield "1"
    yield "A"
    yield "1 2 N"
    yield "FFRFFFFRRL"
    
def pseudo_add_car_a_wrongly() -> "Generator[None, None, str]":
    yield "1"
    yield "A"
    yield "-1 2 N"
    
    yield "A"
    yield "1 20 N"
    
    yield "A"
    yield "1 2 F"
    
    yield "A"
    yield "1 20 G"
    
    yield "A"
    yield "1 2 N"
    yield "FFkFFFFRRL"
    
    yield "A"
    yield "1 2 N"
    yield "FFRFuFFRRL"
    
    yield "A"
    yield "1 2 N"
    yield "FFRFFFFRRL"


def pseudo_add_car_b() -> "Generator[None, None, str]":
    yield "1"
    yield "B"
    yield "7 8 W"
    yield "FFLFFFFFFF"
    
    
def test_add_car_a_wrongly(app_to_add_car_or_run: "App", capfd: "CaptureFixture"):

    fake_adding_car_a_wrongly = pseudo_add_car_a_wrongly()

    with MockInputFunction(side_effect=list(fake_adding_car_a_wrongly)):
        rv = app_to_add_car_or_run.add_car_or_run_simulation()
        assert rv is AppState.REPLAY

    out, _ = capfd.readouterr()
    
    expected = "Please choose from the following options:\n[1] Add a car to field\n[2] Run simulation\n1\nPlease enter the name of the car:\nA\nPlease enter initial position of car \
A in x y Direction format:\n-1 2 N\n[ERROR]: `x` is not a number. You have entered: -1 2 N.\nPlease enter the name of the car:\nA\nPlease enter initial position of car A in x y Direction format:\n1 20 N\n[ERROR]: `y` must be between [0, 10]. You have entered: 1 20 N.\nPlease enter the name of the car:\nA\nPlease enter initial position of car A in x y Direction format:\n1 2 F\n\n\n[ERROR]: List of Errors encountered =>\nException: TypeError; Message: [ERROR]: Expected input to `Direction.from_char` to be char in this set ['N', 'S', 'E', 'W']; got instead : `F`\n\nPlease enter the name of the car:\nA\nPlease enter initial position of car A in x y Direction format:\n1 20 G\n[ERROR]: `y` must be between [0, 10]. You have entered: 1 20 G.\nPlease enter the name of the car:\nA\nPlease enter initial position of car A in x y Direction format:\n1 2 N\nPlease enter the commands for car A:\nFFkFFFFRRL\n[ERROR]: You have entered an invalid list of commands.\n\n\n[ERROR]: List of Errors encountered =>\nException: ValueError; Message: [ERROR]: Expected a char in position 2 that is in the set {'F', 'R', 'L'} got `k` instead.\n\nPlease enter the name of the car:\nA\nPlease enter initial position of car A in x y Direction format:\n1 2 N\nPlease enter the commands \
for car A:\nFFRFuFFRRL\n[ERROR]: You have entered an invalid list of commands.\n\n\n[ERROR]: List of Errors encountered =>\nException: ValueError; Message: [ERROR]: Expected a char \
in position 4 that is in the set {'F', 'R', 'L'} got `u` instead.\n\nPlease enter the name of the car:\nA\nPlease enter initial position of car A in x y Direction format:\n1 2 N\nPlease enter the commands for car A:\nFFRFFFFRRL\nYour current list of cars are:\n- A, (1,2) N, FFRFFFFRRL\n\n"\

    assert out == expected


def test_start_app(app_start: "App"):

    with patch('builtins.input', return_value="10 10"), patch('sys.stdout', new=StringIO()) as fake_out_io:
        rv = app_start.prompt_width_height_of_the_field()
        assert "".join(fake_out_io.getvalue()
                       ) == """You have created a field of 10 x 10.\n\n"""
        assert rv == AppState.NEXT


def test_start_app_wrongly(app_start: 'App'):

    err_msg = "[ERROR]: You have entered `x x`. The first element is not a digit or is not positive or the separator is not a whitespace.\n[ERROR]: You have entered `x x`. The second element is not a digit or is not positive or the separator is not a whitespace.\n"

    with patch('builtins.input', return_value="x x"), patch('sys.stdout', new=StringIO()) as fake_out_io:
        rv = app_start.prompt_width_height_of_the_field()
        assert "".join(fake_out_io.getvalue()) == err_msg
        assert rv == AppState.REPLAY


def test_add_car_a_ok(app_to_add_car_or_run: "App", capfd: "CaptureFixture"):

    fake_adding_car_a = pseudo_add_car_a()

    with MockInputFunction(side_effect=list(fake_adding_car_a)):
        rv = app_to_add_car_or_run.add_car_or_run_simulation()
        assert rv is AppState.REPLAY

    out, _ = capfd.readouterr()

    assert out == 'Please choose from the following options:\n[1] Add a car to field\n[2] Run simulation\n1\nPlease enter the name of the car:\nA\nPlease enter initial position of car A in x y Direction format:\n1 2 N\nPlease enter the commands for car A:\nFFRFFFFRRL\nYour current list of cars are:\n- A, (1,2) N, FFRFFFFRRL\n\n'


def test_add_car_b_ok(app_to_add_car_or_run: "App", capfd: "CaptureFixture"):

    fake_adding_car_b = pseudo_add_car_b()

    with MockInputFunction(side_effect=list(fake_adding_car_b)):
        rv = app_to_add_car_or_run.add_car_or_run_simulation()
        assert rv is AppState.REPLAY

    out, _ = capfd.readouterr()

    assert out == 'Please choose from the following options:\n[1] Add a car to field\n[2] Run simulation\n1\nPlease enter the name of the car:\nB\nPlease enter initial position of car B in x y Direction format:\n7 8 W\nPlease enter the commands for car B:\nFFLFFFFFFF\nYour current list of cars are:\n- B, (7,8) W, FFLFFFFFFF\n\n'


def test_add_both_cars_a_and_b(app_to_add_car_or_run: "App", capfd: "CaptureFixture"):
    
    fake_adding_car_a = pseudo_add_car_a()
    fake_adding_car_b = pseudo_add_car_b()
    
    with MockInputFunction(side_effect=list(fake_adding_car_a)):
        rv = app_to_add_car_or_run.add_car_or_run_simulation()
        assert rv is AppState.REPLAY
        
    with MockInputFunction(side_effect=list(fake_adding_car_b)):
        rv = app_to_add_car_or_run.add_car_or_run_simulation()
        assert rv is AppState.REPLAY
        
    out, _ = capfd.readouterr()
    
    assert out == 'Please choose from the following options:\n[1] Add a car to field\n[2] Run simulation\n1\nPlease enter the name of the car:\nA\nPlease enter initial position of car A in x y Direction format:\n1 2 N\nPlease enter the commands for car A:\nFFRFFFFRRL\nYour current list of cars are:\n- A, (1,2) N, FFRFFFFRRL\n\nPlease choose from the following options:\n[1] Add a car to field\n[2] Run simulation\n1\nPlease enter the name of the car:\nB\nPlease enter initial position of car B in x y Direction format:\n7 8 W\nPlease enter the commands for car B:\nFFLFFFFFFF\nYour current list of cars are:\n- A, (1,2) N, FFRFFFFRRL\n- B, (7,8) W, FFLFFFFFFF\n\n'