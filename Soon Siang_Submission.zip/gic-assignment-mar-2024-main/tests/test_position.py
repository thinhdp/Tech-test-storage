from gic_assignment.core.position import (
    BoundedPosition,
)
from gic_assignment.core.direction import (
    Direction,
    Command,
)
import pytest


def test_general_position():

    direction = Direction.from_char('N')
    bounded_position = BoundedPosition(5, 3, 10, 15)
    command = Command.from_char('F')

    new_position = bounded_position.move_to_new_position(command, direction)
    assert str(new_position) == "(5,4)"
    assert new_position == BoundedPosition(5, 4, 10, 15)

    direction = Direction.from_char('S')
    bounded_position = BoundedPosition(5, 3, 10, 15)
    command = Command.from_char('F')

    new_position = bounded_position.move_to_new_position(command, direction)
    assert str(new_position) == "(5,2)"
    assert new_position == BoundedPosition(5, 2, 10, 15)

    direction = Direction.from_char('E')
    bounded_position = BoundedPosition(5, 3, 10, 15)
    command = Command.from_char('R')

    new_position = bounded_position.move_to_new_position(command, direction)
    assert str(new_position) == "(5,3)"
    assert new_position == BoundedPosition(5, 3, 10, 15)


def test_position_exceptions():
    from gic_assignment.core.error import (
        GroupedExceptions,
    )

    with pytest.raises(GroupedExceptions):
        bounded_position = BoundedPosition(5, 3, 10, -15)

    bounded_position = BoundedPosition(-5, 3, 10, 15)
    assert bounded_position == BoundedPosition(0, 3, 10, 15)

    bounded_position = BoundedPosition(5, -3, 10, 15)
    assert bounded_position == BoundedPosition(5, 0, 10, 15)

    with pytest.raises(GroupedExceptions):
        bounded_position = BoundedPosition(5, 3, -10, 15)


def test_deserialize():

    bounded_position = BoundedPosition.deserialize(
        "5 6",
        "10",
        "15"
    )
    print(bounded_position)
    assert bounded_position == BoundedPosition(5, 6, 10, 15)
