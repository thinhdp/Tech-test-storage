from gic_assignment.core.direction import (
    Direction,
)
from gic_assignment.core.error import (
    GroupedExceptions
)
import pytest


def test_direction_general():
    south = Direction.from_char("S")

    assert south is Direction.SOUTH
    assert south is not Direction.NORTH
    assert south is not Direction.EAST
    assert south is not Direction.WEST
    assert str(south) == 'S'

    east = Direction.from_char("E")

    assert east is not Direction.SOUTH
    assert east is not Direction.NORTH
    assert east is Direction.EAST
    assert east is not Direction.WEST
    assert str(east) == 'E'

    west = Direction.from_char("W")

    assert west is not Direction.SOUTH
    assert west is not Direction.NORTH
    assert west is not Direction.EAST
    assert west is Direction.WEST
    assert str(west) == 'W'

    north = Direction.from_char("N")

    assert north is not Direction.SOUTH
    assert north is Direction.NORTH
    assert north is not Direction.EAST
    assert north is not Direction.WEST
    assert str(north) == 'N'


def test_direction_exception():

    with pytest.raises(GroupedExceptions):
        _direction = Direction.from_char('HEY')

    with pytest.raises(GroupedExceptions):
        _direction = Direction.from_char(5)
