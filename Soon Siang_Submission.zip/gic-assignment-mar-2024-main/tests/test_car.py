from gic_assignment.core.simulation import (
    Car,
)
from gic_assignment.core.direction import (
    Direction,
)
from gic_assignment.core.position import (
    BoundedPosition,
)
from gic_assignment.core.command import (
    Command,
)


def test_car_general():
    direction = Direction.from_char('N')
    bounded_position = BoundedPosition(1, 2, 10, 10)

    commands_as_string = 'FFRFFFFRRL'

    car_a_commands = Car.parse_string_into_list_of_commands(commands_as_string)

    for command_as_string, car_a_command in zip(
            commands_as_string, car_a_commands):
        assert Command.from_char(command_as_string) is car_a_command

    car_a = Car(
        'A',
        bounded_position=bounded_position,
        direction=direction,
        commands=car_a_commands)

    assert str(car_a) == f'A, (1,2) N, {commands_as_string}\n'
