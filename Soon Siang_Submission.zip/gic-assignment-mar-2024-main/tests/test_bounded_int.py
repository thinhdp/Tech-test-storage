from gic_assignment.core.bounded_int import (
    BoundedInt,
)
from gic_assignment.core.error import (
    GroupedExceptions,
)
import pytest


def test_bounded_int_general():

    clipped = BoundedInt(15, 10)
    assert clipped == BoundedInt(10, 10)

    ok = BoundedInt(-15, 10)
    assert ok == BoundedInt(0, 10)

    with pytest.raises(GroupedExceptions):
        _wrong = BoundedInt(-15, -10)


def test_addition_subtraction():
    zero = BoundedInt(0, 10)
    one = BoundedInt(1, 10)
    two = BoundedInt(2, 10)
    three = BoundedInt(3, 10)
    ten = BoundedInt(10, 10)

    assert zero + ten == ten
    assert one + one == two
    assert 1 + one == two
    assert one + 1 == two
    assert one + one + one != two
    assert one + one + 1 != two
    assert one + 1 + one != two
    assert one + 1 + 1 != two
    assert one + one + one == three
    assert one + two == three
    assert one + 2 == three
    assert 1 + 2 == three
    assert 1 + two == three

    assert three - one == two
    assert three - two == one


def test_bounded_int_bounded():
    zero = BoundedInt(0, 10)
    three = BoundedInt(3, 10)
    ten = BoundedInt(10, 10)
    assert three + three + three + 1 == ten
    assert ten - ten == zero
    assert ten - ten - ten == zero
    assert ten + ten + ten == ten
