from gic_assignment.core.command import (
    Command,
)
from gic_assignment.core.direction import (
    Direction,
)


def test_command_general():
    rotation = Command.from_char('L')

    assert rotation is not Command.ROTATE_RIGHT
    assert rotation is Command.ROTATE_LEFT
    assert rotation is not Command.MOVE_FORWARD
    assert rotation is not Command.STAY_PUT
    assert str(rotation) == 'L'

    rotation = Command.from_char('R')

    assert rotation is Command.ROTATE_RIGHT
    assert rotation is not Command.ROTATE_LEFT
    assert rotation is not Command.MOVE_FORWARD
    assert rotation is not Command.STAY_PUT
    assert str(rotation) == 'R'

    rotation = Command.from_char('F')

    assert rotation is not Command.ROTATE_RIGHT
    assert rotation is not Command.ROTATE_LEFT
    assert rotation is Command.MOVE_FORWARD
    assert rotation is not Command.STAY_PUT
    assert str(rotation) == 'F'

    rotation = Command.from_char(' ')

    assert rotation is not Command.ROTATE_RIGHT
    assert rotation is not Command.ROTATE_LEFT
    assert rotation is not Command.MOVE_FORWARD
    assert rotation is Command.STAY_PUT
    assert str(rotation) == ''


def test_direction_rotation_with_command():

    direction = Direction.from_char('W')
    old_direction = direction

    assert direction.rotate(
        Command.from_char('R')).rotate(
        Command.from_char('L')) is old_direction

    direction = Direction.from_char('W')

    assert direction.rotate(
        Command.from_char('R')) is not old_direction

    direction = Direction.from_char('W')

    assert direction.rotate(
        Command.from_char('R')) is Direction.from_char('N')

    direction = Direction.from_char('W')

    for _ in range(4):
        direction = direction.rotate(
            Command.from_char('R'))

    assert direction is Direction.from_char('W')

    direction = Direction.from_char('W')

    for _ in range(4):
        direction = direction.rotate(
            Command.from_char('L'))

    assert direction is Direction.from_char('W')

    direction = Direction.from_char('N')

    for _ in range(4):
        direction = direction.rotate(
            Command.from_char('L'))

    assert direction is Direction.from_char('N')
