from gic_assignment.app.app import (
    App,
    AppState,
)

app = App()
state = None

try:
    while state is not AppState.QUIT:
        state = app.run()
except Exception as err:
    print("[ERROR]: Unrecoverable error, please file a ticket with the administrator of this App.")
    print(f"[ERROR-MESSAGE]: {err}")
    import sys
    sys.exit(1)
