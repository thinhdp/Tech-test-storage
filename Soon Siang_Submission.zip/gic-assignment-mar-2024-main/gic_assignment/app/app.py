from gic_assignment.core.simulation import (
    Simulation,
    Car,
)
from gic_assignment.core.position import (
    BoundedPosition,
)
from gic_assignment.core.common import (
    WHITESPACE,
    print_if_debug,
)
from gic_assignment.core.error import (
    GroupedExceptions,
)
from gic_assignment.core.options import (
    StartOverOrExit,
    AddCarOrRun,
)
from gic_assignment.core.direction import (
    Direction,
)
from enum import auto
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from typing import (
        List,
        Optional,
        Union,
        Literal,
    )

TEXT_AT_START_OF_SIMULATION = "Your current list of cars are:"


class AppState:
    """
    Enumeration representing different states of the application.
    """

    NEXT = auto()
    QUIT = auto()
    REPLAY = auto()
    START_OVER = auto()


class App:
    """
    Class representing the simulation application.
    """

    simulation: "Optional[Simulation]"

    def __init__(self):
        """
        Initializes the App object.
        """
        self.simulation = None

    def run(self) -> "AppState":
        """
        Main method to run the simulation application.

        Returns:
            AppState: The state of the application after running.
        """

        print("Welcome to Auto Driving Car Simulation!\n")

        state = AppState.REPLAY
        while state is AppState.REPLAY:
            state = self.prompt_width_height_of_the_field()

        state = AppState.REPLAY
        while state is AppState.REPLAY:
            state = self.add_car_or_run_simulation()

        if state is AppState.START_OVER:
            return AppState.REPLAY

        return AppState.QUIT

    def add_car_or_run_simulation(self) -> "AppState":
        """
        Prompts the user to add a car to the simulation or run the simulation.

        Returns:
            AppState: The state of the application after adding a car or running the simulation.
        """

        prompt_message = "Please choose from the following options:\n[1] Add a car to field\n[2] Run simulation\n"

        choice = input(prompt_message)
        print_if_debug(choice)
        if choice not in ["1", "2"]:
            print(
                f"[ERROR]: You have entered {choice}. Please enter only '1' or '2'.")
            return AppState.REPLAY

        choice = AddCarOrRun(int(choice))
        print_if_debug(choice)
        if choice is AddCarOrRun.AddCar:
            add_car_state = AppState.REPLAY
            while add_car_state is AppState.REPLAY:
                add_car_state = self.add_car_to_simulation()
            return AppState.REPLAY

        return self.run_simulation()

    def run_simulation(self):
        """
        Runs the simulation.
        """

        if self.simulation.cars_list == []:
            print("[ERROR]: You cannot run a simulation without adding any cars.")
            return AppState.REPLAY
        text_at_start_of_simulation = TEXT_AT_START_OF_SIMULATION
        print(text_at_start_of_simulation)
        print(self.simulation.car_list_as_string())
        simulation_result = self.simulation.run()
        print("After simulation, the result is:")
        print(simulation_result)

        state_or_choice = AppState.REPLAY
        while state_or_choice is AppState.REPLAY:
            state_or_choice = self._prompt_start_over_or_exit_else_reply()

        choice: "str" = state_or_choice

        start_over_or_exit = StartOverOrExit(int(choice))

        if start_over_or_exit is StartOverOrExit.StartOver:
            return AppState.START_OVER
        else:
            print("Thank you for running the simulation. Goodbye!")
            return AppState.QUIT

    def _prompt_start_over_or_exit_else_reply(
            self) -> "Union[AppState, Union[Literal['1'], Literal['2']]]":
        prompt_message = "Please choose from the following options:\n[1] Start Over\n[2] Exit\n"

        choice = input(prompt_message)
        print_if_debug(choice)
        if choice not in ["1", "2"]:
            print(
                f"[ERROR]: You have entered {choice}. Please enter only '1' or '2'.")
            return AppState.REPLAY
        return choice

    def add_car_to_simulation(self):
        """
        Prompts the user to add a car to the simulation.
        """

        enter_name_prompt_message = "Please enter the name of the car:\n"
        car_name = input(enter_name_prompt_message)

        initial_pos_of_car_prompt_message = f"Please enter initial position of car {car_name} in x y Direction format:\n"

        whitespace = WHITESPACE

        x_y_dir = input(initial_pos_of_car_prompt_message)
        if whitespace not in x_y_dir:
            print(
                f"[ERROR]: Please separate the x y Direction with whitespace. You have entered: {x_y_dir}.")
            return AppState.REPLAY

        if len(x_y_dir.split(whitespace)) != 3:
            print(
                f"[ERROR]: Please input the 3 parameters in x y Direction format. You have entered: {x_y_dir}.")
            return AppState.REPLAY

        x, y, direction = x_y_dir.split(whitespace)
        if not x.isdigit():
            print(
                f"[ERROR]: `x` is not a number. You have entered: {x_y_dir}.")
            return AppState.REPLAY

        if not y.isdigit():
            print(
                f"[ERROR]: `y` is not a number. You have entered: {x_y_dir}.")
            return AppState.REPLAY

        x = int(x)
        y = int(y)

        if not (0 <= x <= self.simulation.x_upper_bound):
            print(
                f"[ERROR]: `x` must be between [0, {self.simulation.x_upper_bound}]. You have entered: {x_y_dir}.")
            return AppState.REPLAY

        if not (0 <= y <= self.simulation.y_upper_bound):
            print(
                f"[ERROR]: `y` must be between [0, {self.simulation.y_upper_bound}]. You have entered: {x_y_dir}.")
            return AppState.REPLAY

        try:
            x_upper_bound = self.simulation.x_upper_bound
            y_upper_bound = self.simulation.y_upper_bound

            bounded_position = BoundedPosition(
                x=x, y=y, x_upper_bound=x_upper_bound, y_upper_bound=y_upper_bound)
            direction = Direction.from_char(direction)
            print_if_debug(f"`bounded_position` = {bounded_position}")
            print_if_debug(f"`direction` = {direction}")
        except GroupedExceptions as gerr:
            print(gerr)
            return AppState.REPLAY

        ask_for_commands_prompt_message = f"Please enter the commands for car {car_name}:\n"
        commands_string = input(ask_for_commands_prompt_message)

        try:
            commands = Car.parse_string_into_list_of_commands(commands_string)
        except GroupedExceptions as gerr:
            print(f"[ERROR]: You have entered an invalid list of commands.")
            print(gerr)
            return AppState.REPLAY

        car = Car(
            name=car_name,
            bounded_position=bounded_position,
            direction=direction,
            commands=commands,
        )

        self.simulation.add_car_to_simulation(car)

        text_at_start_of_simulation = TEXT_AT_START_OF_SIMULATION
        print(text_at_start_of_simulation)
        print(self.simulation.car_list_as_string())
        return AppState.NEXT

    def prompt_width_height_of_the_field(self):
        """
        Prompts the user to enter the width and height of the simulation field.
        """

        whitespace = WHITESPACE
        width_height: "str" = input(
            "Please enter the width and height of the simulation field in x y format:\n")

        # must do error handling here because `BoundedInt` will allow negative
        # integers

        if whitespace not in width_height:
            print(
                f"[ERROR]: You have entered `{width_height}` without a whitespace.")
            return AppState.REPLAY

        if len(width_height.split(whitespace)) != 2:
            print(
                f"[ERROR]: You have entered `{width_height}` without two elements separated by a whitespace.")
            return AppState.REPLAY

        x_upper_bound, y_upper_bound = width_height.split(whitespace)

        error_messages: "List[str]" = []

        if not x_upper_bound.isdigit():
            error_messages.append(
                f"[ERROR]: You have entered `{width_height}`. The first element is not a digit or is not positive or the separator is not a whitespace.")

        if not y_upper_bound.isdigit():
            error_messages.append(
                f"[ERROR]: You have entered `{width_height}`. The second element is not a digit or is not positive or the separator is not a whitespace.")

        if error_messages:
            print("\n".join(error_messages))
            return AppState.REPLAY

        x_upper_bound = int(x_upper_bound)
        y_upper_bound = int(y_upper_bound)

        error_messages: "List[str]" = []

        if x_upper_bound < 0:
            error_messages.append(
                f"[ERROR]: You have entered `{width_height}`. The first element cannot be smaller than zero.")

        if y_upper_bound < 0:
            error_messages.append(
                f"[ERROR]: You have entered `{width_height}`. The second element cannot be smaller than zero.")

        if error_messages:
            print("\n".join(error_messages))
            return AppState.REPLAY

        self.simulation = Simulation(
            x_upper_bound=x_upper_bound,
            y_upper_bound=y_upper_bound)

        print(
            f"You have created a field of {x_upper_bound} x {y_upper_bound}.\n")

        return AppState.NEXT
