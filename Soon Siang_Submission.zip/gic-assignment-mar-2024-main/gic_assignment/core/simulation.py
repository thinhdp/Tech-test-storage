from typing import (
    TYPE_CHECKING,
    cast,
)
from gic_assignment.core.position import (
    BoundedPosition,
)
from gic_assignment.core.direction import (
    Direction,
    DirectionVariantMeta
)
from gic_assignment.core.command import (
    Command,
)
from gic_assignment.core.error import (
    ErrorsHandler,
)
from gic_assignment.core.common import (
    print_if_debug,
    compare_string_lists,
)

if TYPE_CHECKING:
    from typing import (
        List,
        Optional,
        Dict,
        NewType,
    )

    SimulationResult = NewType('SimulationResult', str)


class CollisionInfo:
    """
    A class representing collision information.
    """

    with_which_cars: "List[str]"
    at_which_location: "str"
    at_which_step: "int"

    def __init__(self, at_which_location: "str", at_which_step: "int"):
        """
        Initialize a CollisionInfo object with the specified location and step of the collision.

        Args:
            at_which_location (str): The location where the collision occurred.
            at_which_step (int): The step at which the collision occurred.
        """
        self.at_which_location = at_which_location
        self.at_which_step = at_which_step
        self.with_which_cars = []

    def add_collided_car_name(self, car: "Car"):
        """
        Add the name of a collided car to the collision information.

        Args:
            car (Car): The car object representing the collided car.
        """
        self.with_which_cars.append(car.name)

    # def _get_names_of_collided_cars_as_iterable(self) -> "Iterable[str]":
    #     return (c.name for c in self.with_which_cars)

    def __str__(self):
        return f"collides with {', '.join(self.with_which_cars)} at {self.at_which_location} at step {self.at_which_step}"

    def __eq__(self, __other: "CollisionInfo") -> "bool":
        return compare_string_lists(
            self.with_which_cars,
            __other.with_which_cars) and self.at_which_location == __other.at_which_location


class Car:
    """
    A class representing a car in a simulation.
    """

    name: "str"
    bounded_position: "BoundedPosition"
    direction: "Direction"
    commands: "List[Command]"

    _executed_commands: "List[Command]"
    _collided: "bool"
    _collision_infos: "Optional[CollisionInfo]"

    def __init__(self,
                 name: "str",
                 bounded_position: "BoundedPosition",
                 direction: "Direction",
                 commands: "List[Command]"):
        """
        Initialize a Car object with the specified name, bounded position, direction, and commands.

        Args:
            name (str): The name of the car.
            bounded_position (BoundedPosition): The bounded position of the car within the simulation area.
            direction (Direction): The direction the car is facing.
            commands (List[Command]): The list of commands for the car to execute.
        """
        self.name = name
        self.bounded_position = bounded_position
        self.direction = direction
        self.commands = commands

        self._collided = False
        self._executed_commands: "List[Command]" = []
        self._collision_infos: "List[CollisionInfo]" = []

    def collision_infos_as_string(self) -> "str":
        """
        Convert collision information associated with the car into a formatted string representation.

        Returns:
            str: A string representation of the collision information.
        """
        as_string = ""
        for i, collision_info in enumerate(self._collision_infos):
            collision_info_as_string = self.name + \
                ", " + str(collision_info) + "\n"
            if i >= 1:
                as_string += "- "
            as_string += collision_info_as_string
        return as_string

    @staticmethod
    def parse_string_into_list_of_commands(
            string: "str") -> "List[Command]":
        """
        Parse a string into a list of Command objects.

        Args:
            string (str): The string to be parsed into commands.

        Returns:
            List[Command]: A list of Command objects parsed from the input string.

        Raises:
            ValueError: If any character in the input string is not one of 'F', 'R', or 'L'.
        """
        with ErrorsHandler() as errors_handler:
            for i, char in enumerate(string):
                if char not in Command.valid_chars():
                    errors_handler.collate(ValueError(
                        f"[ERROR]: Expected a char in position {i} that is in the set {{'F', 'R', 'L'}} got `{string[i]}` instead."
                    ))
        list_command = []
        for char in string:
            list_command.append(Command.from_char(char))

        return list_command

    def _list_of_current_commands_as_string(self) -> "str":
        return "".join(str(c) for c in self.commands)

    def _list_of_executed_commands_as_string(self) -> "str":
        return "".join(str(c) for c in self._executed_commands)

    def _bounded_position_and_direction_as_string(self) -> "str":
        return f"{self.bounded_position} {self.direction}"

    def serialize(self) -> "str":
        """
        Serialize the car object into a string representation.

        Returns:
            str: A string representation of the car object.
        """
        return ", ".join(
            (self.name,
             self._bounded_position_and_direction_as_string(),
             self._list_of_current_commands_as_string()) if self.commands != [] else (
                self.name,
                self._bounded_position_and_direction_as_string()))

    def __repr__(self):
        return "<Car: " + self.serialize() + ">"

    def __str__(self) -> "str":
        if not self.collided:
            return self.serialize() + '\n'
        return self.collision_infos_as_string()

    def add_collision_info(self, collision_info: "CollisionInfo"):
        """Add an instance of `CollisionInfo` into the list of `CollisionInfo`
        that the instance of the `Car` keeps.

        Args:
            collision_info (CollisionInfo): The instance of `CollisionInfo` to be added.
        """
        with ErrorsHandler() as errors_handler:
            if not self.collided:
                errors_handler.collate(
                    TypeError(
                        f"[ERROR]: `CollisionInfo` cannot be added to Car = {self} because it has not collided."
                    )
                )
        should_add = True
        for old_collision_info in self._collision_infos:
            if collision_info == old_collision_info:
                should_add = False
        if should_add:
            print_if_debug("CollisionInfo added: ", collision_info)
            self._collision_infos.append(collision_info)

    @property
    def collided(self):
        """Is this instance of `Car` collided with other cars or not.
        `True` if it has collided with at least one other car, `False` otherwise.

        Returns:
            bool: `True` if it has collided with at least one other car, `False` otherwise.
        """
        return self._collided

    @collided.setter
    def collided(self, new_collided: "bool"):
        with ErrorsHandler() as errors_handler:
            if not isinstance(new_collided, bool):
                errors_handler.collate(TypeError(
                    f"[ERROR]: Expected `Car.collided` input to setter \
                        to be of type `bool`; instead got {type(new_collided)}"
                ))
        self._collided = new_collided

    def execute_one_self_command(self):
        """Execute the next command in `self.commands`.
        """
        if len(self.commands) > 0:
            command = self.commands.pop(0)
            self._execute_command_impl(command=command)

    def _execute_command_impl(self, command: "Command"):
        self._executed_commands.append(command)
        if not self.collided:
            self.bounded_position.move_to_new_position(
                command=command, direction=self.direction)
            self.direction = cast(DirectionVariantMeta, self.direction)
            self.direction = self.direction.rotate(command)


class Simulation:
    """
    A class representing a simulation of cars moving within a bounded area.

    Attributes:
        cars_list (List[Car]): A list of cars participating in the simulation.
        x_upper_bound (int): The upper bound for the x-coordinate in the simulation area.
        y_upper_bound (int): The upper bound for the y-coordinate in the simulation area.

    Methods:
        __init__(x_upper_bound: int, y_upper_bound: int, cars_list: Optional[List[Car]] = None) -> None:
            Initializes a Simulation object with the specified upper bounds for the simulation area and
            an optional list of cars.
    """

    cars_list: "List[Car]"
    x_upper_bound: "int"
    y_upper_bound: "int"

    def __init__(
            self,
            x_upper_bound: "int",
            y_upper_bound: "int",
            cars_list: "List[Car]" = None):
        """
        Initialize a Simulation object with the specified upper bounds for the simulation area and
        an optional list of cars.

        Args:
            x_upper_bound (int): The upper bound for the x-coordinate in the simulation area.
            y_upper_bound (int): The upper bound for the y-coordinate in the simulation area.
            cars_list (Optional[List[Car]]): A list of cars participating in the simulation.
                Defaults to None if no cars are provided initially.
        """
        if cars_list is None:
            self.cars_list = []
        else:
            self.cars_list = cars_list
        self.x_upper_bound = x_upper_bound
        self.y_upper_bound = y_upper_bound

    def add_car_to_simulation(self, car: "Car"):
        """Add an instance of `Car` to the current instance of `Simulation."""
        self.cars_list.append(car)

    def _check_colliding_cars(self, step: "int"):
        print_if_debug(f"=========== STEP {step} ===========")
        _collision_hm: "Dict[str, List[Car]]" = {}

        for car in self.cars_list:
            print_if_debug("car in self.cars_list: car = ", car)
            key = str(car.bounded_position)
            if key in _collision_hm:  # and (not car.collided):
                _collision_hm[key].append(car)
            else:
                _collision_hm[key] = [car]

        print_if_debug(_collision_hm)

        _collision_hm = {k: v for k, v in _collision_hm.items() if len(v) > 1}
        print_if_debug(_collision_hm)

        for collided_position, collided_cars in _collision_hm.items():
            for car in collided_cars:
                collision_info = CollisionInfo(
                    at_which_location=collided_position,
                    at_which_step=step,
                )
                for other in collided_cars:
                    if car is not other:
                        should_add = True
                        for this_car_collision_info in car._collision_infos:
                            if other.name in this_car_collision_info.with_which_cars:
                                should_add = False
                        if should_add:
                            collision_info.add_collided_car_name(other)
                            car.collided = True
                            car.add_collision_info(
                                collision_info=collision_info)

    def _find_longest_commands_list(self) -> "int":
        if self.cars_list == []:
            return 0
        if len(self.cars_list) == 1:
            return self.cars_list[0].commands.__len__()
        car_with_longest_commands = max(
            *self.cars_list,
            key=lambda car: len(
                car.commands))
        return car_with_longest_commands.commands.__len__()

    def run(self) -> "SimulationResult":
        """
        Run the simulation for the number of steps required to execute the longest set of commands among all cars.

        Returns:
            SimulationResult: A string representing the result of the simulation after all steps have been executed.
        """
        return self.run_n_steps(self._find_longest_commands_list())

    def run_n_steps(self, n: "int") -> "SimulationResult":
        """
        Run the simulation for the specified number of steps.

        Args:
            n (int): The number of steps to run the simulation for.

        Returns:
            SimulationResult: A string representing the result of the simulation after the specified number of steps have been executed.
        """
        for i in range(1, n + 1):
            self.run_one_step(i)
        return self.car_list_as_string()

    def run_one_step(self, step: "int"):
        """
        Run one step of the simulation for all cars.

        Args:
            step (int): The current step number of the simulation.
        """
        for car in self.cars_list:
            car.execute_one_self_command()
        self._check_colliding_cars(step=step)

    def car_list_as_string(self) -> "str":
        """
        Convert the list of cars into a formatted string representation.

        Returns:
            str: A string representation of the list of cars, where each car is represented by its string representation,
                separated by dashes ('-').
        """
        return "- " + "- ".join((str(c) for c in self.cars_list))
