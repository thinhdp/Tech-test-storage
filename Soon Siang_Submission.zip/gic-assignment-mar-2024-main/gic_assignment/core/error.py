from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from typing import (
        Any,
        List,
        NoReturn,
    )
    from gic_assignment.core.bounded_int import (
        BoundedInt,
    )


class GroupedExceptions(Exception):
    ...


class UpperBoundMustBeGreaterThanLowerBound(Exception):

    def __init__(self, lower_bound: "int", upper_bound: "int"):
        self.lower_bound = lower_bound
        self.upper_bound = upper_bound

    def __str__(self):
        return f"[ERROR]: `upper_bound` = `{self.upper_bound}` must be strictly greater than `lower_bound` = `{self.lower_bound}`."


class BoundedIntIsNotNumeric(Exception):
    err_obj: "Any"
    var_name: "str"

    def __init__(self, var_name: "str", err_obj: "Any"):
        self.var_name = var_name
        self.err_obj = err_obj

    def __str__(self):
        return f"[ERROR]: Expecting an object `{self.var_name}` that is representable as an integer, got `{self.err_obj}` instead."


class BoundedIntExceededBounds(Exception):
    lower_bound: "int"
    upper_bound: "int"
    bounded_int: "BoundedInt"

    def __init__(
            self,
            bounded_int: "BoundedInt",
            lower_bound: "int",
            upper_bound: "int") -> None:
        self.bounded_int = bounded_int
        self.lower_bound = lower_bound
        self.upper_bound = upper_bound

    def __str__(self) -> str:
        return f"[ERROR]: `BoundedInt` has value {self.bounded_int} which exceeded its bounds of `[{self.lower_bound}, {self.upper_bound}]`"


class ErrorsHandler:
    """
    A class for handling errors encountered during execution.
    """

    _errors: "List[Exception]"

    def collate(self, error: "Exception"):
        """
        Add an error to the list of encountered errors.

        Args:
            error (Exception): The error to be added to the list of encountered errors.
        """
        self._errors.append(error)

    def _has_errors(self) -> "bool":
        return len(self._errors) > 0

    def _report_errors(self) -> "NoReturn":
        error_message: "str" = "\n\n[ERROR]: List of Errors encountered =>\n"
        for error in self._errors:
            error_message += "Exception: " + \
                str(error.__class__.__name__) + "; Message: " + str(error) + "\n"
        raise GroupedExceptions(error_message)

    def __enter__(self):
        self._errors = []
        return self

    def __exit__(self, exc_type, exc_value, tb):
        if exc_type is not None:
            raise exc_value
        if self._has_errors():
            return self._report_errors()
        self._errors = []
