from enum import Enum


class AddCarOrRun(int, Enum):
    AddCar = 1
    RunSimulation = 2


class StartOverOrExit(int, Enum):
    StartOver = 1
    Exit = 2
