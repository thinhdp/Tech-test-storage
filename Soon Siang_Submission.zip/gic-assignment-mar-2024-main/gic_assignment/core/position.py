from typing import TYPE_CHECKING
from gic_assignment.core.bounded_int import (
    BoundedInt,
)
from gic_assignment.core.error import (
    ErrorsHandler,
)
from gic_assignment.core.direction import (
    Command,
    Direction,
)
from gic_assignment.core.common import (
    print_if_debug,
)

if TYPE_CHECKING:
    from gic_assignment.core.typing import (
        BoundedIntOrInt,
        StrOrInt,
    )

WHITESPACE = " "


class BoundedPosition:

    x: "BoundedInt"
    y: "BoundedInt"

    def __init__(
            self,
            x: "BoundedIntOrInt",
            y: "BoundedIntOrInt",
            x_upper_bound: "StrOrInt",
            y_upper_bound: "StrOrInt"):

        with ErrorsHandler() as error_handler:
            if isinstance(x_upper_bound, str):
                if not x_upper_bound.isdigit():
                    error_handler.collate(TypeError(
                        f"[Error]: Expect `x_upper_bound` to be representable as an \
                            integer, but instead got: {x_upper_bound}."))
            if isinstance(y_upper_bound, str):
                if not y_upper_bound.isdigit():
                    error_handler.collate(TypeError(
                        f"[Error]: Expect `y_upper_bound` to be representable as an \
                            integer, but instead got: {y_upper_bound}."))

        y_upper_bound = int(y_upper_bound)
        if isinstance(y, int):
            self.y = BoundedInt(y, upper_bound=y_upper_bound)
        else:
            self.y = y

        x_upper_bound = int(x_upper_bound)
        if isinstance(x, int):
            self.x = BoundedInt(x, upper_bound=x_upper_bound)
        else:
            self.x = x

    @classmethod
    def deserialize(cls, string: "str", x_upper_bound: "StrOrInt",
                    y_upper_bound: "StrOrInt") -> "BoundedPosition":
        """
        Deserialize a string representation into a BoundedPosition object.

        Args:
            string (str): The string representation to deserialize.
            x_upper_bound (StrOrInt): The upper bound for the x-coordinate.
            y_upper_bound (StrOrInt): The upper bound for the y-coordinate.

        Returns:
            BoundedPosition: A BoundedPosition object initialized from the deserialized string representation.
        """
        with ErrorsHandler() as errors_handler:
            if not isinstance(string, str):
                errors_handler.collate(
                    TypeError(
                        f"[ERROR]: Expected instance of type `string` \
                            as input to `BoundedPosition.deserialize`; \
                            got {type(string)} instead."
                    )
                )
            whitespace = WHITESPACE
            if len(string.split(whitespace)) != 2:
                errors_handler.collate(ValueError(
                    f"[ERROR]: Expected input to be two digits separated by \
                            white space, got {string} instead."))
        splitted = string.split(whitespace)
        return BoundedPosition(
            x=splitted[0],
            y=splitted[1],
            x_upper_bound=x_upper_bound,
            y_upper_bound=y_upper_bound)

    def __eq__(self, other: "BoundedPosition"):
        return self.x == other.x and self.y == other.y

    def __str__(self) -> "str":
        return f"({self.x},{self.y})"

    def move_to_new_position(
            self,
            command: "Command",
            direction: "Direction") -> "BoundedPosition":
        """
        Move the bounded position to a new position based on the given command and direction.

        Args:
            command (Command): The command specifying the movement direction.
            direction (Direction): The direction of movement.

        Returns:
            BoundedPosition: The updated BoundedPosition object after moving to the new position.
        """

        if command is Command.MOVE_FORWARD:
            print_if_debug("self.x: ", self.x, type(self.x))
            print_if_debug("self.y: ", self.y, type(self.y))
            self.x = self.x + direction.x
            self.y = self.y + direction.y
            return self
        return self
