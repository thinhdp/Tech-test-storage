from gic_assignment.core.command import (
    Command,
)
from gic_assignment.core.error import (
    ErrorsHandler,
)
from typing import (
    TYPE_CHECKING,
)
from gic_assignment.core.common import (
    delete_impl,
)

if TYPE_CHECKING:
    from typing import (
        Union,
        Dict,
        Literal,
    )


class DirectionVariantMeta(type):

    def __str__(cls) -> "str":
        return cls.__name__[0]

    def rotate(
            cls,
            rotation: "Command") -> "Union[DirectionVariant, DirectionVariantMeta]":

        if rotation is Command.ROTATE_LEFT:
            if cls is NORTH:
                return WEST
            if cls is SOUTH:
                return EAST
            if cls is WEST:
                return SOUTH
            if cls is EAST:
                return NORTH
        if rotation is Command.ROTATE_RIGHT:
            if cls is NORTH:
                return EAST
            if cls is SOUTH:
                return WEST
            if cls is WEST:
                return NORTH
            if cls is EAST:
                return SOUTH
        return cls


class DirectionVariant:
    x: "int"
    y: "int"


class NORTH(DirectionVariant, metaclass=DirectionVariantMeta):
    x = 0
    y = 1


class SOUTH(DirectionVariant, metaclass=DirectionVariantMeta):
    x = 0
    y = -1


class EAST(DirectionVariant, metaclass=DirectionVariantMeta):
    x = 1
    y = 0


class WEST(DirectionVariant, metaclass=DirectionVariantMeta):
    x = -1
    y = 0


class Direction(DirectionVariant):
    """Direction"""

    NORTH = NORTH
    SOUTH = SOUTH
    EAST = EAST
    WEST = WEST

    __init__ = delete_impl()

    @classmethod
    def from_char(
            cls,
            string: "Union[Literal['N'], Literal['S'], Literal['E'], Literal['W']]"
    ) -> "Union[DirectionVariant, DirectionVariantMeta]":
        """
        Get the direction corresponding to the specified character.

        Args:
            string (Union[Literal['N'], Literal['S'], Literal['E'], Literal['W']]): The character representing the direction.

        Returns:
            Union[DirectionVariant, DirectionVariantMeta]: The DirectionVariant object corresponding to the input character.

        Raises:
            TypeError: If the input is not a string or if it's not one of the valid characters ('N', 'S', 'E', 'W').
        """
        _valid_strings_direction_mapping: "Dict[str, DirectionVariant]" = {
            'N': cls.NORTH,
            'S': cls.SOUTH,
            'E': cls.EAST,
            'W': cls.WEST,
        }

        with ErrorsHandler() as errors_hander:

            if not isinstance(string, str):
                errors_hander.collate(TypeError(
                    f"[ERROR]: Expected input to `Direction.from_char` to be a `str`, got instead : `{string}`"))

            if string not in _valid_strings_direction_mapping.keys():
                errors_hander.collate(TypeError(
                    f"[ERROR]: Expected input to `Direction.from_char` to be char in this set ['N', 'S', 'E', 'W']; got instead : `{string}`"))

        return _valid_strings_direction_mapping[string]
