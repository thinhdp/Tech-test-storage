from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from typing import (
        List,
        Union,
        Literal,
    )


WHITESPACE = " "


class CommandVariantMeta(type):
    as_char: "str"

    def __str__(cls):
        return cls.as_char


class CommandVariant:
    _command_subclasses: "List[Union[CommandVariant, CommandVariantMeta]]" = []

    def __init_subclass__(cls):
        if cls.__name__ == "Command":
            for kls in cls._command_subclasses:
                setattr(cls, kls.__name__, kls)
        cls._command_subclasses.append(
            cls) if cls.__name__ != "Command" else None
        return cls


class STAY_PUT(CommandVariant, metaclass=CommandVariantMeta):
    as_char = ""


class ROTATE_LEFT(CommandVariant, metaclass=CommandVariantMeta):
    as_char = "L"


class ROTATE_RIGHT(CommandVariant, metaclass=CommandVariantMeta):
    as_char = "R"


class MOVE_FORWARD(CommandVariant, metaclass=CommandVariantMeta):
    as_char = "F"


class Command(CommandVariant):
    """
    A class representing commands that can be executed by a car in a simulation.
    """

    STAY_PUT: STAY_PUT
    ROTATE_LEFT: ROTATE_LEFT
    ROTATE_RIGHT: ROTATE_RIGHT
    MOVE_FORWARD: MOVE_FORWARD

    @classmethod
    def from_char(
            cls,
            ch: "Union[Literal[' '], Literal['L'], Literal['R'], Literal['F']]"
    ) -> "Union[STAY_PUT, ROTATE_LEFT, ROTATE_RIGHT, MOVE_FORWARD]":
        """
        Convert a character into a corresponding Command object.

        Args:
            ch (Union[Literal[' '], Literal['L'], Literal['R'], Literal['F']]): The character to convert.

        Returns:
            Union[STAY_PUT, ROTATE_LEFT, ROTATE_RIGHT, MOVE_FORWARD]: The corresponding Command object.

        Raises:
            TypeError: If the input character is not one of ' ', 'L', 'R', or 'F'.
        """

        whitespace = WHITESPACE
        for command in CommandVariant._command_subclasses:
            if command.as_char == ch:
                return command
            if ch == whitespace:
                return STAY_PUT

        raise TypeError(
            f"[Error]: `Command.from_char` expects an input of type `str`,\
            instead got: {type(ch)}.")

    @classmethod
    def valid_chars(_cls) -> "Literal['FRL']":
        """
        Get the valid characters that represent commands.

        Returns:
            str: A string containing the valid characters for commands ('F', 'R', 'L').
        """
        return 'FRL'
