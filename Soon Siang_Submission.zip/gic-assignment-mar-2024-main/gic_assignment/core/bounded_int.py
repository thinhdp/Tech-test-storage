from typing import TYPE_CHECKING
from gic_assignment.core.error import (
    BoundedIntIsNotNumeric,
    ErrorsHandler,
    UpperBoundMustBeGreaterThanLowerBound,
)
from gic_assignment.core.common import (
    delete_impl,
)

if TYPE_CHECKING:
    from typing import (
        List,
        Union,
    )
    from gic_assignment.core.typing import (
        StrOrInt,
        BoundedIntOrInt,
    )


class BoundedInt(int):

    upper_bound: "int"
    lower_bound: "int" = 0
    _allowed_impls: "List[str]" = ["__new__",
                                   "__init__",
                                   "__add__",
                                   "__sub__",
                                   "__rsub__",
                                   "__repr__",
                                   "__str__",
                                   "__ge__",
                                   "__ne__",
                                   "__eq__",
                                   "__int__",
                                   "__format__",
                                   "__radd__",
                                   "__getattribute__",
                                   "__neg__"]

    def __eq__(self, other: "BoundedIntOrInt"):
        return int.__eq__(int(self), int(other))

    def __new__(
            cls,
            value: "StrOrInt",
            upper_bound: "StrOrInt",
            lower_bound: "StrOrInt" = lower_bound):

        with ErrorsHandler() as error_handler:

            if isinstance(upper_bound, str):
                if not upper_bound.isdigit():
                    error_handler.collate(
                        BoundedIntIsNotNumeric(
                            'upper_bound', upper_bound))
                else:
                    upper_bound = int(upper_bound)

            if isinstance(lower_bound, str):
                if not lower_bound.isdigit():
                    error_handler.collate(
                        BoundedIntIsNotNumeric(
                            'lower_bound', lower_bound))
                else:
                    lower_bound = int(lower_bound)

            if isinstance(value, str):
                if not value.isdigit():
                    error_handler.collate(
                        BoundedIntIsNotNumeric(
                            'value', value))
                else:
                    value = int(value)

        with ErrorsHandler() as error_handler:

            if not isinstance(upper_bound, int):
                error_handler.collate(
                    BoundedIntIsNotNumeric(
                        'upper_bound', upper_bound))

            if not isinstance(lower_bound, int):
                error_handler.collate(
                    BoundedIntIsNotNumeric(
                        'lower_bound', lower_bound))

            if not isinstance(value, int):
                error_handler.collate(
                    BoundedIntIsNotNumeric(
                        'value', value))

        with ErrorsHandler() as error_handler:

            if upper_bound <= lower_bound:
                error_handler.collate(
                    UpperBoundMustBeGreaterThanLowerBound(
                        lower_bound=lower_bound,
                        upper_bound=upper_bound))

            if upper_bound <= 0:
                error_handler.collate(ValueError(
                    f"[Error]: `BoundedInt` `upper_bound` must be strictly larger than zero; instead it is {upper_bound}"))

            if lower_bound < 0:
                error_handler.collate(ValueError(
                    f"[Error]: `BoundedInt` `lower_bound` must be larger than or equal to zero; instead it is {lower_bound}"))

            if value <= lower_bound:
                value = lower_bound
            if value >= upper_bound:
                value = upper_bound

        for meth_name, _ in int.__dict__.items():
            if meth_name not in cls._allowed_impls:
                setattr(cls, meth_name, delete_impl(
                    f"`BoundedInt` {meth_name}."))

        inst = int.__new__(BoundedInt, value)
        return inst

    def __init__(
            self,
            value: "int",
            upper_bound: "int",
            lower_bound: "int" = lower_bound):
        """
        Initialize a BoundedInt object with the specified value and bounds.

        Args:
            value (int): The initial value for the bounded integer.
            upper_bound (int): The upper bound for the bounded integer.
            lower_bound (int, optional): The lower bound for the bounded integer. Defaults to 0.
        """
        # with ErrorsHandler() as error_handler:
        #     if not (lower_bound <= int(self) <= upper_bound):
        #         error_handler.collate(
        #             BoundedIntExceededBounds(
        #                 self,
        #                 lower_bound=lower_bound,
        #                 upper_bound=upper_bound))
        self.upper_bound = upper_bound
        self.lower_bound = lower_bound

    def __add__(self, __value: "Union[BoundedInt, int]") -> int:
        with ErrorsHandler() as error_handler:
            if not isinstance(__value, (BoundedInt, int)):
                error_handler.collate(TypeError(
                    f"`BoundedInt` can only be added to\
                    instances of `int` or `BoundedInt`.\
                The type of value that is being added to\
                    `BoundedInt`: {type(__value)}"))
        if isinstance(__value, BoundedInt):
            with ErrorsHandler() as error_handler:
                if __value.upper_bound != self.upper_bound:
                    error_handler.collate(ValueError(
                        f"""Only two `BoundedInt`s with the same `upper_bound` can be added:
                    Addition of first `BoundedInt` with `value` = {__value} and `upper_bound` = {__value.upper_bound}
                    to second `BoundedInt` with `value` = {self} and `upper_bound` = {self.upper_bound}"""))
            return BoundedInt(
                int(__value) + int(self),
                upper_bound=self.upper_bound)
        return BoundedInt((int(self) + __value), upper_bound=self.upper_bound)

    def __radd__(self, __value: "int") -> int:
        return self.__add__(__value)

    def _check_value_for_sub(
            self, __value: "Union[BoundedInt, int]") -> "None":
        with ErrorsHandler() as error_handler:
            if not isinstance(__value, (BoundedInt, int)):
                error_handler.collate(TypeError(
                    f"""`BoundedInt` can only be subtracted to instances of `int` or `BoundedInt`.
                The type of value that is being subtracted to `BoundedInt`: {type(__value)}"""))
        if isinstance(__value, BoundedInt):
            with ErrorsHandler() as error_handler:
                if __value.upper_bound != self.upper_bound:
                    error_handler.collate(ValueError(
                        f"""Only two `BoundedInt`s with the same `upper_bound` can be subtracted:
                    Subtraction of first `BoundedInt` with `value` = {__value} and `upper_bound` = {__value.upper_bound}
                    to second `BoundedInt` with `value` = {self} and `upper_bound` = {self.upper_bound}"""))

    def __sub__(self, __value: "Union[BoundedInt, int]") -> int:
        self._check_value_for_sub(__value)
        return BoundedInt(
            (int(self) - int(__value)),
            upper_bound=self.upper_bound)

    def __rsub__(self, __value: "int") -> int:
        self._check_value_for_sub(__value)
        return BoundedInt(
            (int(__value) - int(self)),
            upper_bound=self.upper_bound)

    def __neg__(self):
        return BoundedInt(-int(self), self.upper_bound)
