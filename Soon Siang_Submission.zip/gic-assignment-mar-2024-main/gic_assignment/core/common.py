from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from typing import (
        Callable,
        ParamSpecArgs,
        ParamSpecKwargs,
        NoReturn,
        List,
    )

PRINT_IF_DEBUG_KEY = "DEBUG_PRINT"
WHITESPACE = " "


def delete_impl(msg: "str" = "") -> "Callable":
    """
    Return a function that raises a NotImplementedError.

    Args:
        msg (str, optional): Additional message to include in the NotImplementedError message. Defaults to "".

    Returns:
        Callable: A function that raises a NotImplementedError with the specified message.
    """
    def delete_impl_inner(
        *_: "ParamSpecArgs",
            **__: "ParamSpecKwargs") -> "NoReturn":
        raise NotImplementedError(
            f"This implementation is deleted{', ' + msg if msg else ''}")
    return delete_impl_inner


def print_if_debug(*msg: "str"):
    """
    Print messages if debug mode is enabled.

    Args:
        *msg (str): Messages to print.
    """

    import os

    debug_print = os.getenv(PRINT_IF_DEBUG_KEY, False)

    if debug_print == "1":
        print(*msg)


def compare_string_lists(list1: "List[str]", list2: "List[str]") -> "bool":
    """
    Compare two lists of strings.

    Args:
        list1 (List[str]): The first list of strings.
        list2 (List[str]): The second list of strings.

    Returns:
        bool: True if the lists contain the same strings (ignoring order), False otherwise.
    """
    if len(list1) != len(list2):
        return False
    sorted_list1 = sorted(list1)
    sorted_list2 = sorted(list2)

    for i in range(len(sorted_list1)):
        if sorted_list1[i] != sorted_list2[i]:
            return False

    return True
