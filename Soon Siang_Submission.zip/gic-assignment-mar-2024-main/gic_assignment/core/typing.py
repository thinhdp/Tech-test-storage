from typing import (
    TYPE_CHECKING,
)

if TYPE_CHECKING:
    from typing import (
        Union,
    )
    from gic_assignment.core.bounded_int import (
        BoundedInt,
    )
    StrOrInt = Union[str, int]
    BoundedIntOrInt = Union[BoundedInt, int]
