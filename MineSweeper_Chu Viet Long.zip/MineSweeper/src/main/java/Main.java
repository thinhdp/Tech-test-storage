public class Main {
    public static void main(String[] args) {
        System.out.println("Welcome to Minesweeper!\n");
        Game game = new Game();
        game.start();
    }
}