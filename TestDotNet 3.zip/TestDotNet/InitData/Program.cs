﻿using System.Data.Entity.ModelConfiguration.Conventions;
using System.Data.SQLite;
using System.Text;
using ExcelDataReader;
using System.IO;


public class Program
{
    private static void Main()
    {
        // Load the Excel file

        string filePath = "data.xlsx";
        var stream = File.Open(filePath, FileMode.Open, FileAccess.Read);
        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
        var reader = ExcelReaderFactory.CreateReader(stream);

        // Connect to the SQLite database
        string connectionString = "Data Source=database.db";

        using (var connection = new SQLiteConnection(connectionString))
        {
            connection.Open();
            using (var transaction = connection.BeginTransaction())
            {
                try
                {
                    // Create the Estimates table
                    string createEstimatesTableSql = "DROP TABLE IF EXISTS Estimates; CREATE TABLE Estimates (State INTEGER, Districts DOUBLE, EstimatesPopulation DOUBLE, EstimatesHouseholds DOUBLE)";
                    using (var command = new SQLiteCommand(createEstimatesTableSql, connection))
                    {
                        command.ExecuteNonQuery();
                    }

                    // Create the Actuals table
                    string createActualsTableSql = "DROP TABLE IF EXISTS Actuals; CREATE TABLE Actuals (State INTEGER, ActualPopulation DOUBLE, ActualHouseholds DOUBLE)";
                    using (var command = new SQLiteCommand(createActualsTableSql, connection))
                    {
                        command.ExecuteNonQuery();
                    }

                    // Insert data into the Estimates table
                    var estimatesDataTable = reader.AsDataSet().Tables["Estimates"];
                    if (estimatesDataTable != null)
                    {
                        foreach (var row in estimatesDataTable.Rows.Cast<System.Data.DataRow>().Skip(1))
                        {
                            int state = Convert.ToInt32(row[0]);
                            double districts = Convert.ToDouble(row[1]);
                            double estimatesPopulation = Convert.ToDouble(row[2]);
                            double estimatesHouseholds = Convert.ToDouble(row[3]);
                            string insertEstimatesSql = $"INSERT INTO Estimates (State, Districts, EstimatesPopulation, EstimatesHouseholds) VALUES ({state}, {districts}, {estimatesPopulation}, {estimatesHouseholds})";
                            using (var command = new SQLiteCommand(insertEstimatesSql, connection))
                            {
                                command.ExecuteNonQuery();
                            }
                        }
                    }


                    // Insert data into the Actuals table
                    var actualsDataTable = reader.AsDataSet().Tables["Actuals"];
                    if (actualsDataTable != null)
                    {
                        foreach (var row in actualsDataTable.Rows.Cast<System.Data.DataRow>().Skip(1))
                        {
                            int state = Convert.ToInt32(row[0]);
                            double actualPopulation = Convert.ToDouble(row[1]);
                            double actualHouseholds = Convert.ToDouble(row[2]);
                            string insertActualsSql = $"INSERT INTO Actuals (State, ActualPopulation, ActualHouseholds) VALUES ({state}, {actualPopulation}, {actualHouseholds})";
                            using (var command = new SQLiteCommand(insertActualsSql, connection))
                            {
                                command.ExecuteNonQuery();
                            }
                        }
                    }
                    string select = $"SELECT * FROM Actuals";
                    using (var command = new SQLiteCommand(select, connection))
                    {
                        command.ExecuteNonQuery();
                    }
                    transaction.Commit();
                    Console.WriteLine("Data loaded into SQLite database");
                }
                catch (Exception ex)
                {

                    // Roll back the transaction and log the error
                    transaction.Rollback();

                    Console.WriteLine(ex.Message);
                }

            }
            connection.Close();
        }

        //Move the database file from InitData project to WebApp project
        string sourceFile = @"database.db";
        string destinationFolder = @"..\\..\\..\\..\\WebApp";

        string destinationFile = Path.Combine(destinationFolder, Path.GetFileName(sourceFile));
        File.Move(sourceFile, destinationFile);
    }
}