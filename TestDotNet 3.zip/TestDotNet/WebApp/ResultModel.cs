namespace WebApp
{
    public class ResultModel
    {
        public int State { get; set; }

        public double Population { get; set; }
    }
}