﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System.Data.SQLite;
using System.Diagnostics;
using System;
using System.IO;

namespace WebApp.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PopulationController : ControllerBase
    {
        private readonly ILogger<PopulationController> _logger;

        public PopulationController(ILogger<PopulationController> logger)
        {
            _logger = logger;
        }

        [EnableCors]
        [HttpGet(Name = "GetPopulation")]
        public IActionResult Population(string states)
        {
            string connectionString = "Data Source=database.db";

            List<ResultModel> results = ReadData(connectionString, states);
            string currentTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
            _logger.LogInformation($"{currentTime} - API endpoint called - /population?state={states}");

            return new JsonResult(results);
        }

        private List<ResultModel> ReadData(string connectionString, string states)
        {
            var results = new List<ResultModel>();
            results = ReadPopulationData(connectionString, states);

            if (results.Count == 0)
            {
                return ReadEstimateData(connectionString, states);
            }

            return results;
        }

        private List<ResultModel> ReadPopulationData(string connectionString, string states)
        {
            var resultModels = new List<ResultModel>();
            // SQL query to retrieve the state column from the Actuals table
            string query = $"SELECT State, ActualPopulation FROM Actuals WHERE State IN (@states)";

            // Create the SQLite connection and command objects
            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            using (SQLiteCommand command = new SQLiteCommand(query, connection))
            {
                // Add the state parameter to the command
                command.Parameters.AddWithValue("@states", states);

                // Open the database connection
                connection.Open();

                // Execute the query and retrieve the result
                using (SQLiteDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        Debug.WriteLine(reader.FieldCount);
                        // State found in the Actuals table
                        int state = reader.GetInt32(0);
                        Console.WriteLine($"State {state} exists in the Actuals table.");
                        ResultModel result = new ResultModel()
                        {
                            State = state,
                            Population = reader.GetDouble(1),
                        };
                        resultModels.Add(result);
                    }
                }

                connection.Close();
            }

            return resultModels;
        }
        
        private List<ResultModel> ReadEstimateData(string connectionString, string states)
        {
            var resultModels = new List<ResultModel>();

            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();

                // Prepare the SQL query
                string query = "SELECT State, SUM(EstimatesPopulation) AS EstimatesPopulation FROM Estimates WHERE State IN (@states) GROUP BY State";

                using (SQLiteCommand command = new SQLiteCommand(query, connection))
                {
                    // Bind the state parameter
                    command.Parameters.AddWithValue("@states", states);

                    using (SQLiteDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            ResultModel resultModel = new ResultModel()
                            {
                                State = reader.GetInt32(0),
                                Population = reader.GetDouble(1),
                            };
                            resultModels.Add(resultModel);
                        }
                    }
                    
                }

                connection.Close();
            }

            return resultModels;
        }
    }
}
