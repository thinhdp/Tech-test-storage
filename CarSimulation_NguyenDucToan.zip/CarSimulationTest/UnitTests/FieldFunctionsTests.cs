﻿using GICTest.Implementations;
using Xunit;

namespace CarSimulationTest.UnitTests
{
    public class FieldFunctionsTests
    {
        private readonly FieldFunctions _fieldFunctions;
        public FieldFunctionsTests()
        {
            _fieldFunctions = new FieldFunctions();
        }

        [Theory]
        [InlineData("10 10")]
        [InlineData("9 9")]
        [InlineData("")]
        [InlineData("XXXXXXXXXX")]
        public void InitNewCarTest(string carName)
        {
            try
            {
                var result = _fieldFunctions.InitFieldSize(carName);
                Assert.True(result.CoordY > 0 && result.CoordX > 0);
            }
            catch (Exception ex)
            {
                Assert.True(ex is InvalidDataException || ex is ArgumentNullException);
            }
        }
    }
}
