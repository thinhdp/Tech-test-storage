﻿using GICTest.Implementations;
using GICTest.Models;
using GICTest.Models.Enum;
using Xunit;
using Xunit.Abstractions;

namespace CarSimulationTest.UnitTests
{
    public class CarFunctionsTests
    {
        private readonly CarFunctions _carFunctions;
        private readonly ITestOutputHelper _testOutputHelper;
        private readonly string[,] fieldSize = new string[10, 10];
        public CarFunctionsTests(ITestOutputHelper testOutputHelper)
        {
            _carFunctions = new CarFunctions(fieldSize);
            _testOutputHelper = testOutputHelper;
        }

        [Theory]
        [InlineData("testNotNull")]
        [InlineData("")]
        public void InitNewCarTest(string carName)
        {
            try
            {
                var result = _carFunctions.InitNewCar(carName);
                Assert.True(result.CarName == carName);
            }
            catch (Exception ex)
            {
                Assert.True(ex is ArgumentNullException);
            }
        }

        [Theory]
        [InlineData("1 2 N", "carNameTest1")]
        [InlineData("7 8 W", "carNameTest2")]
        [InlineData("7 8 W NE", "carNameTest3")]
        [InlineData("N 8 W NE", "carNameTest4")]
        public void InitCarPositionTest(string carPositionInput, string carName)
        {
            try
            {
                var car = new Cars()
                {
                    CarName = carName,
                };
                _carFunctions.InitCarPosition(carPositionInput, ref car);
                var carPosArray = carPositionInput?.Split(" ").ToArray();
                if (fieldSize[int.Parse(carPosArray[0]), int.Parse(carPosArray[1])] == car.CarName)
                {
                    Assert.True(true);
                }
            }
            catch (Exception ex)
            {
                Assert.True(ex is InvalidDataException || ex is FormatException);
            }
        }

        [Theory]
        [InlineData(1, 2, Direction.North, "carNameTest1", "FFRFFFFRRL")]
        [InlineData(7, 8, Direction.West, "carNameTest2", "FFLFFFFFFF")]
        [InlineData(7, 8, Direction.West, "carNameTest3", "")]
        public void CarMovingTest(int posX, int posY, Direction direction, string carName, string command)
        {
            try
            {
                var cars = new List<Cars>()
                {
                    new Cars()
                    {
                        CarName = carName,
                        CoordinateX = posX,
                        CoordinateY = posY,
                        Direction = direction,
                        InputCommands = command
                    }
                };
                var result = _carFunctions.Move(cars);

                Assert.True((result.Find(x => x.CarName == "carNameTest1")?.CoordinateX == 5
                    && result.Find(x => x.CarName == "carNameTest1")?.CoordinateY == 4
                    && result.Find(x => x.CarName == "carNameTest1")?.Direction == Direction.South)

                   || (result.Find(x => x.CarName == "carNameTest2")?.CoordinateX == 5
                    && result.Find(x => x.CarName == "carNameTest2")?.CoordinateY == 1
                    && result.Find(x => x.CarName == "carNameTest2")?.Direction == Direction.South));
            }
            catch (Exception ex)
            {
                Assert.True(ex is ArgumentNullException);
            }
        }

        [Theory]
        [InlineData(1, 2, Direction.North, "carNameTest1", "FFRFFFFRRL", 7, 8, Direction.West, "carNameTest2", "FFLFFFFFFF")]
        //[InlineData(1, 2, Direction.North, "carNameTest1", "", 7, 8, Direction.West, "carNameTest2", "FFLFFFFFFF")]
        public void CarMovingCollideTest(int car1posX, int car1posY, Direction car1Direction, string car1Name, string car1command,
                                        int car2posX, int car2posY, Direction car2Direction, string car2Name, string car2command)
        {
            try
            {
                var cars = new List<Cars>()
                {
                    new Cars()
                    {
                        CarName = car1Name,
                        CoordinateX = car1posX,
                        CoordinateY = car1posY,
                        Direction = car1Direction,
                        InputCommands = car1command
                    },
                    new Cars()
                    {
                        CarName = car2Name,
                        CoordinateX = car2posX,
                        CoordinateY = car2posY,
                        Direction = car2Direction,
                        InputCommands = car2command
                    }
                };
                var result = _carFunctions.Move(cars);

                Assert.True((result.Find(x => x.CarName == "carNameTest1")?.CoordinateX == 5
                    && result.Find(x => x.CarName == "carNameTest1")?.CoordinateY == 4)

                   && (result.Find(x => x.CarName == "carNameTest2")?.CoordinateX == 5
                    && result.Find(x => x.CarName == "carNameTest2")?.CoordinateY == 4));
            }
            catch (Exception ex)
            {
                Assert.True(ex is ArgumentNullException);
            }
        }
    }
}
