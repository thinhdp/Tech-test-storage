﻿using GICTest.Extentions;
using GICTest.Interfaces;
using GICTest.Models;
using GICTest.Models.Enum;

namespace GICTest.Implementations
{
    public class CarFunctions(string[,] fieldSize) : ICarFunctions
    {
        private readonly string[,] fieldSize = fieldSize;
        private readonly List<Cars> carsCollide = new List<Cars>();
        private int collideCoordX = 0;
        private int collideCoordY = 0;

        public void InitCarPosition(string carPositionInput, ref Cars car)
        {
            try
            {
                var carPosArray = carPositionInput?.Split(" ").ToArray();

                if (carPosArray?.Length == 0 || carPosArray?.Length > 3)
                {
                    throw new InvalidDataException();
                }

                int rowInput = Convert.ToInt32(carPosArray[0]);
                int columnInput = Convert.ToInt32(carPosArray[1]);

                //Default direction input
                char startDirection = char.Parse(carPosArray[2]);

                car.CoordinateX = rowInput;
                car.CoordinateY = columnInput;
                car.Direction = Enum.GetValues(typeof(Direction)).Cast<Direction>().FirstOrDefault(v => char.Parse(v.GetDescription()) == startDirection);

                fieldSize[rowInput, columnInput] = car.CarName;
            }
            catch (FormatException)
            {
                throw new FormatException();
            }
        }

        public Cars InitNewCar(string carName)
        {
            if (string.IsNullOrEmpty(carName))
            {
                throw new ArgumentNullException();
            }
            var car = new Cars()
            {
                CarName = carName
            };
            return car;
        }

        public List<Cars> Move(List<Cars> cars)
        {
            var consoleFunctions = new ConsoleFunctions();
            if (cars.Exists(x => string.IsNullOrEmpty(x.InputCommands)))
            {
                throw new ArgumentNullException();
            }

            try
            {
                var longestCommandArray = cars.OrderByDescending(x => x.InputCommands.Length).Select(x => x.InputCommands).FirstOrDefault()?.ToLower().ToCharArray();
                for (int command = 0; command < longestCommandArray?.Length; command++)
                {
                    for (int carNumber = 0; carNumber < cars.Count; carNumber++)
                    {
                        // Stay for current car if longest command is longer than car command
                        if (command > cars[carNumber].InputCommands.Length) continue;


                        // Compare by each car commands
                        if (cars[carNumber].InputCommands.ToLower()[command] == 'f')
                        {
                            cars[carNumber] = CarForwarding(cars[carNumber]);
                        }
                        else
                        {
                            cars[carNumber].Direction = CarTurning(cars[carNumber].InputCommands.ToLower()[command], cars[carNumber].Direction);
                        }
                    }
                    if (carsCollide.Any())
                    {
                        SwapCarPos(ref cars);
                        carsCollide.AddRange(cars.Where(x => x.CarName == fieldSize[x.CoordinateX, x.CoordinateY]));
                        consoleFunctions.PrintCarsCollide(carsCollide, command + 1);
                        return cars;
                    }
                }
            }
            catch (Exception)
            {

            }
            consoleFunctions.PrintCarPosAfterSimulation(cars);

            return cars;

        }

        private static Direction CarTurning(char turnDirection, Direction carDirection)
        {
            // Get index direction and turning by direction enum index
            int currentCarDirectionIndex = (int)carDirection;

            int maxIndexValue = (int)Enum.GetValues(typeof(Direction)).Cast<Direction>().Last();
            int minIndexValue = (int)Enum.GetValues(typeof(Direction)).Cast<Direction>().First();

            switch (turnDirection)
            {
                case 'r':
                    {
                        currentCarDirectionIndex = (currentCarDirectionIndex + 1 > maxIndexValue) ? minIndexValue : currentCarDirectionIndex + 1;
                        break;
                    }
                case 'l':
                    {
                        currentCarDirectionIndex = (currentCarDirectionIndex - 1 < minIndexValue) ? maxIndexValue : currentCarDirectionIndex - 1;
                        break;
                    }
            }

            return (Direction)(currentCarDirectionIndex);
        }

        private Cars CarForwarding(Cars car)
        {
            try
            {
                int destionationX = car.CoordinateX;
                int destionationY = car.CoordinateY;

                // Mapping destination of next forwarding position
                switch (car.Direction)
                {
                    case Direction.North:
                        destionationY += 1;
                        break;
                    case Direction.South:
                        destionationY -= 1;
                        break;
                    case Direction.East:
                        destionationX += 1;
                        break;
                    case Direction.West:
                        destionationX -= 1;
                        break;
                }

                // Check if car is collide
                if (!string.IsNullOrEmpty(fieldSize[destionationX, destionationY]))
                {
                    collideCoordX = destionationX;
                    collideCoordY = destionationY;
                    carsCollide.Add(car);
                }
                // Init to new value
                else
                {
                    // Mark position value by carName
                    fieldSize[destionationX, destionationY] = car.CarName;

                    car.CoordinateX = destionationX;
                    car.CoordinateY = destionationY;
                }
                return car;
            }
            catch (IndexOutOfRangeException)
            {
                return car;
            }
        }

        private void SwapCarPos(ref List<Cars> cars)
        {
            foreach (Cars car in cars.Intersect(carsCollide))
            {
                car.CoordinateX = collideCoordX;
                car.CoordinateY = collideCoordY;
            }
        }
    }
}
