﻿using GICTest.Interfaces;
using GICTest.Models;

namespace GICTest.Implementations
{
    public class FieldFunctions : IFieldFunctions
    {
        public FieldFunctions()
        {

        }
        public Field InitFieldSize(string valueFieldSizeInput)
        {
            if (string.IsNullOrEmpty(valueFieldSizeInput))
            {
                throw new ArgumentNullException();
            }

            var fieldSizeList = valueFieldSizeInput?.Split(" ").ToArray();

            if (fieldSizeList?.Length != 2)
            {
                throw new InvalidDataException();
            }

            int x = Convert.ToInt32(fieldSizeList[0]);
            int y = Convert.ToInt32(fieldSizeList[1]);

            var field = new Field()
            {
                CoordX = x,
                CoordY = y,
                FieldArray = new string[x, y]
            };

            return field;
        }
    }
}
