﻿using GICTest.Extentions;
using GICTest.Interfaces;
using GICTest.Models;

namespace GICTest.Implementations
{
    public class ConsoleFunctions : IConsoleFunctions
    {
        public string PrintHello()
        {
            Console.WriteLine("Welcome to Auto Driving Car Simulation!");
            Console.WriteLine("Please enter the width and height of the simulation field in x y format:");
            string fieldSizeInputString = Console.ReadLine();

            return fieldSizeInputString;
        }

        public int InputSelectOption(Field fieldSize)
        {

            Console.WriteLine("Please choose from the following options:");
            Console.WriteLine("[1] Add a car to field");
            Console.WriteLine("[2] Run simulation");
            int number = Convert.ToInt32(Console.ReadLine());

            return number;
        }

        public string InputCarName()
        {
            // Enter carName
            Console.WriteLine("Please enter the name of the car:");
            string carName = Console.ReadLine();
            return carName ?? string.Empty;
        }

        public string InputCarPosition()
        {
            // Enter carPos in field array
            Console.WriteLine("Please enter initial position of car A in x y Direction format:");
            string initCarPosString = Console.ReadLine();
            return initCarPosString ?? string.Empty;
        }

        public string InputCarCommands(Cars car)
        {
            // Start commands
            Console.WriteLine("Please enter the commands for car {0}:", car.CarName);
            string directions = Console.ReadLine();

            return directions ?? string.Empty;
        }

        public void PrintCurrentCars(List<Cars> cars)
        {
            Console.WriteLine("Your current list of cars are:");
            foreach (var car in cars)
            {
                Console.WriteLine("{0}, ({1}, {2}) {3}, {4}", car.CarName, car.CoordinateX, car.CoordinateY, car.Direction.GetDescription(), car.InputCommands);
            }
        }

        public void PrintCarPosAfterSimulation(List<Cars> cars)
        {
            // Output results
            Console.WriteLine("After simulation, the result is:");
            foreach (var car in cars)
            {
                Console.WriteLine("{0}, ({1}, {2}) {3}, {4}", car.CarName, car.CoordinateX, car.CoordinateY, car.Direction.GetDescription(), car.InputCommands);
            }
        }

        public void PrintCommandsAfterSimulation()
        {
            Console.WriteLine("Please choose from the following options:");
            Console.WriteLine("[1] Start over");
            Console.WriteLine("[2] Exit");

            if (Console.ReadKey().Key == ConsoleKey.D2)
            {
                Console.WriteLine();
                Console.WriteLine("Thank you for running the simulation. Goodbye!");
                // Close console app immediately
                Environment.Exit(0);
            }
        }

        public void PrintFieldSize(Field fieldSize)
        {
            Console.WriteLine("You have created a field of {0} x {1}.", fieldSize.CoordX, fieldSize.CoordY);
        }

        public void PrintCarsCollide(List<Cars> cars, int position)
        {
            var uniqueCars = cars.GroupBy(p => p.CarName).Select(g => g.First())
                                   .ToList();
            foreach (var car in uniqueCars)
            {
                Console.WriteLine("{0}, collides with {1} at ({2},{3}) at step {4}", car.CarName, string.Join("and ", uniqueCars.Find(x => x.CarName != car.CarName)?.CarName), car.CoordinateX, car.CoordinateY, position);
            }
        }
    }
}
