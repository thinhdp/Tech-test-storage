﻿using GICTest.Models.Enum;

namespace GICTest.Models
{
    public class Cars
    {
        public string CarName { get; set; }
        public int CoordinateX { get; set; }
        public int CoordinateY { get; set; }
        public Direction Direction { get; set; }
        public string InputCommands { get; set; }
    }
}
