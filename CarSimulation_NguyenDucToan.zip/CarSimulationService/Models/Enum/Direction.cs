﻿using System.ComponentModel;

namespace GICTest.Models.Enum
{
    public enum Direction
    {
        [Description("N")]
        North,
        [Description("E")]
        East,
        [Description("S")]
        South,
        [Description("W")]
        West
    }
}
