﻿namespace GICTest.Models
{
    public class Field
    {
        public string[,] FieldArray { get; set; }
        public int CoordX { get; set; }
        public int CoordY { get; set; }
    }
}
