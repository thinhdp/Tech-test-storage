﻿using GICTest.Models;

namespace GICTest.Interfaces
{
    public interface ICarFunctions
    {
        List<Cars> Move(List<Cars> cars);

        void InitCarPosition(string carPositionInput, ref Cars car);

        Cars InitNewCar(string carName);
    }
}
