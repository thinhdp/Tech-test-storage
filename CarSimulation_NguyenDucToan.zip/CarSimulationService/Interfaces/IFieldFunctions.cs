﻿using GICTest.Models;

namespace GICTest.Interfaces
{
    public interface IFieldFunctions
    {
        Field InitFieldSize(string valueFieldSizeInput);
    }
}
