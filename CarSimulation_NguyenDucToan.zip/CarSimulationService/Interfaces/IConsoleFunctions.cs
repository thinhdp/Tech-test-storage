﻿using GICTest.Models;

namespace GICTest.Interfaces
{
    public interface IConsoleFunctions
    {
        string PrintHello();
        int InputSelectOption(Field fieldSize);

        string InputCarName();

        string InputCarPosition();

        string InputCarCommands(Cars car);
        void PrintCurrentCars(List<Cars> car);
        void PrintCarPosAfterSimulation(List<Cars> cars);
        void PrintCommandsAfterSimulation();
        void PrintFieldSize(Field fieldSize);
        void PrintCarsCollide(List<Cars> cars, int position);
    }
}
