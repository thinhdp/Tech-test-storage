﻿// See https://aka.ms/new-console-template for more information
using GICTest.Implementations;
using GICTest.Models;

try
{
    var consoleFunction = new ConsoleFunctions();
    while (true)
    {
        StartOver(consoleFunction);
    }
}
catch (Exception ex)
{
    throw new Exception(ex.Message, ex);
}
finally
{
    Console.ReadLine();
}

static void StartOver(ConsoleFunctions consoleFunction)
{
    var listCar = new List<Cars>();
    string fieldSizeString = consoleFunction.PrintHello();

    // Init field
    var fieldFuntions = new FieldFunctions();
    var fieldSize = fieldFuntions.InitFieldSize(fieldSizeString);
    var carFunction = new CarFunctions(fieldSize.FieldArray);

    consoleFunction.PrintFieldSize(fieldSize);

    while (true)
    {
        // Check option number
        int number = consoleFunction.InputSelectOption(fieldSize);
        // 1 is init new car
        if (number == 1)
        {
            // Init new car
            string carName = consoleFunction.InputCarName();
            var car = carFunction.InitNewCar(carName);

            string initCarPosString = consoleFunction.InputCarPosition();
            carFunction.InitCarPosition(initCarPosString, ref car);

            car.InputCommands = consoleFunction.InputCarCommands(car);

            // Add new car to list
            listCar.Add(car);

            consoleFunction.PrintCurrentCars(listCar);
        }
        // 2 is run simulation
        else if (number == 2)
        {
            // Moving car by commands
            carFunction.Move(listCar);

            consoleFunction.PrintCommandsAfterSimulation();
            break;
        }
    }
}
