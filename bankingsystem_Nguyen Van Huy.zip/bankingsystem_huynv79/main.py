import os

# Set the environment variable for production
os.environ["environment"] = "production"

from banking_system.database.database import setup_database
from banking_system.models.account import BankAccount
from banking_system.utils.validators import is_number, is_positive_number

def get_option():
    valid_choices = ['D', 'W', 'P', 'Q']
    
    while True:
        choice = input("Please select an option: ").upper()
        if choice in valid_choices:
            return choice
        else:
            print("Invalid option.")

def main():
    setup_database()
    while True:
        account_id = input("Enter account ID: ")
        if not is_number(account_id):
            print("The account ID must be a number")
        elif not is_positive_number(account_id):
            print("The account ID must be a positive number")
        else:
            account = BankAccount(account_id)
            break

    while True:
        print("\nWelcome to AwesomeGIC Bank! What would you like to do?")
        print("[D]eposit")
        print("[W]ithdraw")
        print("[P]rint statement")
        print("[Q]uit")

        choice = get_option()
        if choice == "D":
            amount = input("Please enter the amount to deposit: ")
            if not is_number(amount):
                print("The amount must be a number")
            else:
                amount = float(amount)
                account.deposit(amount)
        elif choice == "W":
            amount = input("Please enter the amount to deposit: ")
            if not is_number(amount):
                print("The amount must be a number")
            else:
                amount = float((amount))
                account.withdraw(amount)
        elif choice == "P":
            account.print_statement()
        elif choice == "Q":
            print("Thank you for banking with AwesomeGIC Bank.")
            print("Have a nice day!")
            account.close()
            break

if __name__ == "__main__":
    main()
