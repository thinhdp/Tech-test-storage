import os
import sqlite3

if os.environ["environment"] == "test":
    DB_NAME = "test_banking_system.db"
else:
    DB_NAME = "banking_system.db"

# Connects to the SQLite database using DB_NAME
def get_connection():
    return sqlite3.connect(DB_NAME)

# Returns a connection and a cursor to the SQLite database
def get_cursor():
    conn = get_connection()
    cursor = conn.cursor()
    return conn, cursor

# Closes the connection to the SQLite database
def close_connection(conn):
    if conn:
        conn.close()

# Commits the changes to the SQLite database
def commit_changes(conn):
        conn.commit()

# Creates the accounts tables in the SQLite database
def create_accounts_table(cursor):
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS accounts (
                id INTEGER PRIMARY KEY,
                balance REAL DEFAULT 0
            )
        ''')

# Creates the transactions table in the SQLite database.
def create_transactions_table(cursor):
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            account_id INTEGER,
            type TEXT,
            amount REAL,
            timestamp TEXT,
            balance_after REAL,
            FOREIGN KEY(account_id) REFERENCES accounts(id)
            )
        ''')

# Sets up the database by creating the accounts and transactions tables.
def setup_database():
    conn, cursor = get_cursor()

    create_accounts_table(cursor)
    create_transactions_table(cursor)

    commit_changes(conn)
    close_connection(conn)
