from banking_system.database.database import get_cursor, close_connection
from banking_system.interfaces.i_account_repository import IAccountRepository

class AccountRepository(IAccountRepository):
    def __init__(self):
        self.conn, self.cursor = get_cursor()

    # Creates an account if it does not exist in the SQLite database
    def create_account_if_not_exists(self, account_id):
        self.cursor.execute("SELECT * FROM accounts WHERE id = ?", (account_id,))
        if not self.cursor.fetchone():
            self.cursor.execute("INSERT INTO accounts (id, balance) VALUES (?, ?)", (account_id, 0))
            self.conn.commit()

    # Retrieves the account balance from the SQLite database
    def get_balance(self, account_id):
        self.cursor.execute("SELECT balance FROM accounts WHERE id = ?", (account_id,))
        return self.cursor.fetchone()[0]

    # Updates the account balance in the SQLite database
    def update_balance(self, account_id, balance):
        self.cursor.execute("UPDATE accounts SET balance = ? WHERE id = ?", (balance, account_id))
        self.conn.commit()

    # Closes the SQLite database connection
    def close(self):
        close_connection(self.conn)
