from datetime import datetime
from banking_system.database.database import get_cursor, close_connection
from banking_system.interfaces.i_transaction_repository import ITransactionRepository

class TransactionRepository(ITransactionRepository):
    def __init__(self):
        self.conn, self.cursor = get_cursor()

    # Records a transaction in the SQLite database
    def record(self, account_id, tx_type, amount, balance_after):
        self.cursor.execute("""
            INSERT INTO transactions (account_id, type, amount, timestamp, balance_after)
            VALUES (?, ?, ?, ?, ?)
        """, (account_id, tx_type, amount, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), balance_after))
        self.conn.commit()

    # Retrieves all transactions for a specific account from the SQLite database
    def get_transactions(self, account_id):
        self.cursor.execute("""
            SELECT timestamp, amount, balance_after FROM transactions
            WHERE account_id = ? ORDER BY timestamp
        """, (account_id,))
        return self.cursor.fetchall()

    # Closes the SQLite database connection
    def close(self):
        close_connection(self.conn)
