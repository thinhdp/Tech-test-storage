import platform
from datetime import datetime

def format_statement(transactions):
    # Format the date based on the operating system
    if platform.system() == "Windows":
        date_format = "%#d %b %Y %I:%M:%S%p"
    else:
        date_format = "%-d %b %Y %I:%M:%S%p"
    
    # Print the header
    print(f"{'Date':<25} | {'Amount':>8} | {'Balance':>9}")
    print("-" * 50)

    # Print each transaction
    for ts, amount, bal in transactions:
        dt = datetime.strptime(ts, "%Y-%m-%d %H:%M:%S")
        formatted_date = dt.strftime(date_format)
        
        print(f"{formatted_date:<25} | {amount:>8.2f} | {bal:>8.2f}")
    print()

