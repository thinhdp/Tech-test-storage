import re

def is_positive_number(input_str) -> bool:
        pattern = r"^[+]?\d*\.\d+$|^[+]?\d+$"
        return bool(re.match(pattern, input_str))
        
def is_number(input_str):
        pattern = r"^[+-]?\d+(\.\d+)?$"
        return bool(re.match(pattern, input_str))
