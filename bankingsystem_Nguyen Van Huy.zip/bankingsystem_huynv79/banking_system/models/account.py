from banking_system.repositories.account_repository import AccountRepository
from banking_system.repositories.transaction_repository import TransactionRepository
from banking_system.services.transaction_service import TransactionService
from banking_system.utils.formatter import format_statement

class BankAccount:
    def __init__(self, account_id):
        self.account_id = account_id
        self.account_repo = AccountRepository()
        self.transaction_repo = TransactionRepository()
        self.transaction_service = TransactionService(self.account_repo, self.transaction_repo)

        self.account_repo.create_account_if_not_exists(account_id)

    # Deposits money into the account
    def deposit(self, amount):
        self.transaction_service.deposit(self.account_id, amount)

    # Withdraws money from the account
    def withdraw(self, amount):
        self.transaction_service.withdraw(self.account_id, amount)

    # Prints the account statement
    def print_statement(self):
        transactions = self.transaction_repo.get_transactions(self.account_id)
        format_statement(transactions)

    # Closes the connection to the SQLite database
    def close(self):
        self.account_repo.close()
        self.transaction_repo.close()
