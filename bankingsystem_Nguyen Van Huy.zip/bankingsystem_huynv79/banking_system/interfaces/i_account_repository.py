from abc import ABC, abstractmethod

class IAccountRepository(ABC):
    @abstractmethod
    def create_account_if_not_exists(self, account_id: int):
        pass

    @abstractmethod
    def get_balance(self, account_id: int) -> float:
        pass

    @abstractmethod
    def update_balance(self, account_id: int, balance: float):
        pass

    @abstractmethod
    def close(self):
        pass
