from abc import ABC, abstractmethod
from typing import List, Tuple

class ITransactionRepository(ABC):
    @abstractmethod
    def record(self, account_id: int, tx_type: str, amount: float, balance_after: float):
        pass

    @abstractmethod
    def get_transactions(self, account_id: int) -> List[Tuple[str, float, float]]:
        pass

    @abstractmethod
    def close(self):
        pass
