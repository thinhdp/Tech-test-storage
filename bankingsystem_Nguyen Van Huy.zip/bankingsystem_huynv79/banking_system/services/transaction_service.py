class TransactionService:
    def __init__(self, account_repo, transaction_repo):
        self.account_repo = account_repo
        self.transaction_repo = transaction_repo

    # Deposits money into an account
    def deposit(self, account_id, amount):
        if amount <= 0:
            print("The amount must be greater than 0.")
            return
        balance = self.account_repo.get_balance(account_id) + amount
        self.account_repo.update_balance(account_id, balance)
        self.transaction_repo.record(account_id, 'deposit', amount, balance)

    # Withdraws money from an account
    def withdraw(self, account_id, amount):
        balance = self.account_repo.get_balance(account_id)
        if amount <= 0:
            print("The amount must be greater than 0.")
        elif amount > balance:
            print("Insufficient balance.")
        else:
            balance -= amount
            self.account_repo.update_balance(account_id, balance)
            self.transaction_repo.record(account_id, 'withdraw', -amount, balance)
