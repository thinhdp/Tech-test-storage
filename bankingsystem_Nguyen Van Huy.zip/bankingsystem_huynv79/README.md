# 🏦 Simple Banking System

A simple command-line banking system built with Python.  
It supports:

- Creating accounts
- Depositing money
- Withdrawing money
- Printing account statements with transaction history

---

## 🔧 Designing system

✅ Designed with **OOP** & **SOLID principles**  
✅ Uses **SQLite** as local storage  
✅ Includes **unit tests** and **input validation using regex**

---

## 🚀 Features

- Account creation (balance starts at 0)
- Deposit / Withdraw functionality
- Formatted statement printing
- Input validation (only positive numbers for amount, numeric IDs)
- Cross-platform time formatting (Windows + macOS/Linux)
- Clean Git commit history like production code

---

## 📦 Requirements

- Python 3.7+
- No external packages needed (uses sqlite3, datetime, re, etc.)

---

## 🧑‍💻 How to Run

```bash
python main.py
```

---

## 🧪 Running Tests

```bash
python -m unittest discover tests
```

---

## ⚙️ Git Commit History

```bash
git log --oneline
```

---

## 🙌 Author

Developed by **Huy Nguyen Van**
- ✉️ Email: [huynv79@fpt.com](mailto:huynv79@fpt.com)
- 🗓️ Project Date: April 2025