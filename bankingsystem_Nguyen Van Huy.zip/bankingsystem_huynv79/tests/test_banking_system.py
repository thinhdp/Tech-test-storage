import unittest
import os

# Set the environment variable for testing
os.environ["environment"] = "test"

from banking_system.database.database import setup_database, DB_NAME
from banking_system.models.account import BankAccount

class TestBankingSystem(unittest.TestCase):

    # Set up the test environment
    def setUp(self):
        if os.path.exists(DB_NAME):
            os.remove(DB_NAME)
        setup_database()
        self.account = BankAccount(account_id=1)

    # Clean up the test environment
    def tearDown(self):
        self.account.close()
        if os.path.exists(DB_NAME):
            os.remove(DB_NAME)

    def test_initial_balance_is_zero(self):
        self.assertEqual(self.account.account_repo.get_balance(1), 0)

    def test_deposit_increases_balance(self):
        self.account.deposit(100)
        self.assertEqual(self.account.account_repo.get_balance(1), 100)

    def test_withdraw_decreases_balance(self):
        self.account.deposit(200)
        self.account.withdraw(50)
        self.assertEqual(self.account.account_repo.get_balance(1), 150)

    def test_cannot_withdraw_more_than_balance(self):
        self.account.deposit(100)
        self.account.withdraw(150)
        self.assertEqual(self.account.account_repo.get_balance(1), 100)

    def test_deposit_negative_amount(self):
        self.account.deposit(-100)
        self.assertEqual(self.account.account_repo.get_balance(1), 0)

    def test_withdraw_negative_amount(self):
        self.account.withdraw(-50)
        self.assertEqual(self.account.account_repo.get_balance(1), 0)

    def test_print_statement_output(self):
        self.account.deposit(100)
        self.account.withdraw(40)
        transactions = self.account.transaction_repo.get_transactions(1)
        self.assertEqual(len(transactions), 2)
        self.assertEqual(transactions[0][1], 100)  
        self.assertEqual(transactions[1][1], -40)

    def test_multiple_deposits_and_withdrawals(self):
        self.account.deposit(100)
        self.account.deposit(50)
        self.account.withdraw(30)
        self.assertEqual(self.account.account_repo.get_balance(1), 120)

    def test_zero_deposit(self):
        self.account.deposit(0)
        self.assertEqual(self.account.account_repo.get_balance(1), 0)

if __name__ == '__main__':
    unittest.main()
