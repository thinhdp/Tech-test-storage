const config = {
  basename: "/employee",
};

export default config;
