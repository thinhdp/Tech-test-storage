import React from "react";

// third-party
import {
  Box,
  Button,
  Card,
  CardActions,
  CardContent,
  CardHeader,
  Divider,
  Grid,
  TextField,
} from "@mui/material";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router";
import { v4 as uuidv4 } from "uuid";
import { useForm } from "react-hook-form";

// project imports
import { emailRegExp, optionGender, phoneRegExp } from "../config/constant";
import { addAsync, editAsync } from "../store/employeeReducer";
import useExistingEmployee from "../hooks/useExistingEmployee";
import { toast } from "react-toastify";

function FormEmployee() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const params = useParams();
  const listEmployees = useSelector((store) => store.employee);
  const existingEmployee = useExistingEmployee(listEmployees?.data, params.id);
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    defaultValues:
      existingEmployee?.length > 0
        ? {
            firstName: existingEmployee[0].firstName,
            lastName: existingEmployee[0].lastName,
            email: existingEmployee[0].email,
            phone: existingEmployee[0].phone,
            gender: existingEmployee[0].gender,
          }
        : {
            firstName: "",
            lastName: "",
            email: "",
            phone: "",
            gender: "",
          },
  });

  const onSubmit = (dataForm) => {
    try {
      if (existingEmployee?.length > 0) {
        // edit
        dispatch(
          editAsync({
            id: params.id,
            firstName: dataForm.firstName,
            lastName: dataForm.lastName,
            email: dataForm.email,
            phone: dataForm.phone,
            gender: dataForm.gender,
          })
        );
      } else {
        // add
        dispatch(
          addAsync({
            id: uuidv4(),
            firstName: dataForm.firstName,
            lastName: dataForm.lastName,
            email: dataForm.email,
            phone: dataForm.phone,
            gender: dataForm.gender,
          })
        );
      }

      navigate("/list");
    } catch (err) {
      toast( err, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
        type: "error"
        });
    }
  };

  return (
    <>
      <form autoComplete="false" onSubmit={handleSubmit(onSubmit)}>
        <Button
          onClick={() => navigate("/list")}
          variant="outlined"
          startIcon={<ArrowBackIcon />}
          style={{ marginBottom: "5px" }}
        >
          Back
        </Button>
        <Card>
          <CardHeader
            subheader="The information of employee"
            title="Employee"
          />
          <CardContent>
            <Box
              component="form"
              sx={{ flexGrow: 1 }}
              noValidate
              autoComplete="off"
            >
              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <form onSubmit={handleSubmit(onSubmit)}></form>
                  <TextField
                    error={!!errors?.firstName}
                    helperText={
                      errors?.firstName ? errors?.firstName?.message : null
                    }
                    fullWidth
                    label="First name"
                    name="firstName"
                    {...register("firstName", {
                      required: "firstName is required",
                      minLength: {
                        value: 6,
                        message: "LastName must be at least 6 characters long",
                      },
                      maxLength: {
                        value: 10,
                        message: "LastName can be max 10 characters long",
                      },
                    })}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    error={!!errors?.lastName}
                    helperText={
                      errors?.lastName ? errors?.lastName?.message : null
                    }
                    fullWidth
                    label="Last name"
                    name="lastName"
                    {...register("lastName", {
                      required: "LastName is required",
                      minLength: {
                        value: 6,
                        message: "LastName must be at least 6 characters long",
                      },
                      maxLength: {
                        value: 10,
                        message: "LastName can be max 10 characters long",
                      },
                    })}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    error={!!errors?.gender}
                    helperText={errors?.gender ? errors?.gender?.message : null}
                    fullWidth
                    label="Select Gender"
                    name="gender"
                    select
                    SelectProps={{ native: true }}
                    {...register("gender", {
                      required: "Gender is required",
                    })}
                  >
                    {optionGender.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    error={!!errors?.phone}
                    helperText={errors?.phone ? errors?.phone?.message : null}
                    fullWidth
                    label="Phone Number"
                    name="phone"
                    type="string"
                    {...register("phone", {
                      required: "Phone is required",
                      pattern: {
                        value: phoneRegExp,
                        message: "Invalid phone number",
                      },
                    })}
                  />
                </Grid>
                <Grid item xs={12} md={12}>
                  <TextField
                    error={!!errors?.email}
                    helperText={errors?.email ? errors?.email?.message : null}
                    fullWidth
                    label="Email Address"
                    name="email"
                    type="email"
                    {...register("email", {
                      required: "email is required",
                      pattern: {
                        value: emailRegExp,
                        message: "Please enter a valid email !",
                      },
                    })}
                  />
                </Grid>
              </Grid>
            </Box>
          </CardContent>
          <Divider />
          <CardActions sx={{ justifyContent: "flex-end" }}>
            <Button type="submit" variant="contained">
              Save details
            </Button>
          </CardActions>
        </Card>
      </form>
    </>
  );
}

export default FormEmployee;
