import React from "react";

// project imports
import DataTable from "../components/DataTable";

function ListEmployee() {
  return <DataTable/>;
}

export default ListEmployee;
