import React, { useEffect } from "react";

// third-party
import {
  Box,
  Button,
  Card,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Typography,
} from "@mui/material";
import DriveFileRenameOutlineIcon from "@mui/icons-material/DriveFileRenameOutline";
import DeleteIcon from "@mui/icons-material/Delete";
import { useNavigate } from "react-router";
import { useDispatch, useSelector } from "react-redux";

// project imports
import MainCard from "./MainCard";
import {
  deleteAsync,
  getListAsync,
} from "../store/employeeReducer";
import Loader from "./Loader";

function DataTable() {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const listData = useSelector((state) => state.employee);

  useEffect(() => {
    dispatch(getListAsync());
  }, [dispatch]);

  const handleOnclick = (e, redirectPath, id) => {
    e.preventDefault();
    redirectPath === "add"
      ? navigate("/" + redirectPath)
      : navigate(`/${redirectPath}/${id}`);
  };

  const handleRemove = (e, idEmployee) => {
    e.preventDefault();
    dispatch(deleteAsync({ id: idEmployee }));
  };
  if (listData?.isLoading) {
    return <Loader />;
  } else {
    return (
      <MainCard
        title="Employee"
        secondary={
          <Button variant="contained" onClick={(e) => handleOnclick(e, "add")}>
            Add
          </Button>
        }
      >
        <Card sx={{ overflow: "hidden" }}>
          <Box sx={{ minWidth: 800 }}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>First name</TableCell>
                  <TableCell>Last name</TableCell>
                  <TableCell>Email</TableCell>
                  <TableCell>Phone</TableCell>
                  <TableCell>Gender</TableCell>
                  <TableCell>Action</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {listData?.data &&
                  listData?.data.map((employee) => (
                    <TableRow hover key={employee?.id}>
                      <TableCell>
                        <Stack alignItems="center" direction="row" spacing={2}>
                          <Typography variant="subtitle2">
                            {employee.firstName}
                          </Typography>
                        </Stack>
                      </TableCell>
                      <TableCell>{employee.lastName}</TableCell>
                      <TableCell>{employee.email}</TableCell>
                      <TableCell>{employee.phone}</TableCell>
                      <TableCell>{employee.gender}</TableCell>
                      <TableCell>
                        <Button
                          variant="outlined"
                          onClick={(e) =>
                            handleOnclick(e, "edit", employee?.id)
                          }
                          startIcon={<DriveFileRenameOutlineIcon />}
                        >
                          Edit
                        </Button>{" "}
                        |{" "}
                        <Button
                          onClick={(e) => handleRemove(e, employee?.id)}
                          variant="outlined"
                          startIcon={<DeleteIcon />}
                        >
                          Delete
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </Box>
        </Card>
      </MainCard>
    );
  }
}

export default DataTable;
