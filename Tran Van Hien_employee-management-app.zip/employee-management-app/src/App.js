import { ThemeProvider } from "@mui/material";
import "./App.css";
import { useSelector } from "react-redux";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import Router from "./routers/index";

// themes
import themes from "./themes";

function App() {
  const customization = useSelector((state) => state.customization);

  return (
    <ThemeProvider theme={themes(customization)}>
      <ToastContainer />
      <Router />
    </ThemeProvider>
  );
}

export default App;
