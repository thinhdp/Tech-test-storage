import { lazy } from "react";
import { Navigate } from "react-router-dom";

// project imports
import MainLayout from "../layout/MainLayout";
import Loadable from "../components/Loadable";

// routing
const ListEmployee = Loadable(lazy(() => import("../views/ListEmployee.js")));
const FormEmployee = Loadable(lazy(() => import("../views/FormEmployee.js")));

// ==============================|| ROUTING ||============================== //

const MainRoutes = [
  {
    path: "/",
    element: <MainLayout />,
    children: [
      {
        path: "/list",
        element: <ListEmployee />,
      },
      {
        path: "/add",
        element: <FormEmployee />,
      },
      {
        path: "/edit/:id",
        element: <FormEmployee />,
      },
    ],
  },
  {
    path: "",
    element: <Navigate to="/list" />,
  },
];

export default MainRoutes;
