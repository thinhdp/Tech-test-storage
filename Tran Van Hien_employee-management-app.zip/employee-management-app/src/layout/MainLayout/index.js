import React from "react";
import { Outlet } from "react-router-dom";

// material-ui
import Box from "@mui/material/Box";
import { styled, useTheme } from "@mui/material";

// styles
const Main = styled('main')(({theme}) => ({
  ...theme.typography.mainContent
}))

// ==============================|| MAIN LAYOUT ||============================== //

const MainLayout = () => {
  const theme = useTheme();
  return (
    <Box sx={{ display: "flex" }}>
      {/* main content */}
      <Main theme={theme}>
        <Outlet/>
      </Main>
    </Box>
  );
};

export default MainLayout;
