import { useEffect, useState } from "react";

function useFetch(fetchingFn) {
  const [result, setResult] = useState(null);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const fetchData = async () => {
    setIsLoading(true);

    const data = await fetchingFn();
    if (data) {
      setIsSuccess(true);
      setResult(data);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  return { result, isSuccess, isLoading };
}

export default useFetch;
