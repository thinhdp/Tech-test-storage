// find the exiting item in list
const useExistingEmployee = (listdata, id) => {
  return listdata && listdata.filter((item) => item.id === id);
};

export default useExistingEmployee;
