// third-party
import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";

// ==============================|| REDUCER ||============================== //

// --- Action ---
export const getListAsync = createAsyncThunk("getList", async () => {
  const response = await axios.get(process.env.REACT_APP_API_KEY + "/employee");
  return response.data;
});
export const addAsync = createAsyncThunk("addEmployee", async (payload) => {
  const response = await axios.post(
    process.env.REACT_APP_API_KEY + "/employee",
    payload
  );
  toast('Add success', {
    position: "top-right",
    autoClose: 5000,
    hideProgressBar: false,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
    theme: "light",
    type: "success"
    });
  return response.data;
});
export const editAsync = createAsyncThunk("editEmployee", async (payload) => {
  const { id } = payload;
  const response = await axios.put(
    `${process.env.REACT_APP_API_KEY}/employee/${id}`,
    payload
  );
  toast('Edit success', {
    position: "top-right",
    autoClose: 5000,
    hideProgressBar: false,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
    theme: "light",
    type: "success"
    });
  return response.data;
});
export const deleteAsync = createAsyncThunk(
  "deleteEmployee",
  async (payload) => {
    const { id } = payload;
    const response = await axios.delete(
      `${process.env.REACT_APP_API_KEY}/employee/${id}`,
      payload
    );
    toast('Delete success', {
      position: "top-right",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      theme: "light",
      type: "success"
      });
    return response.data;
  }
);

// --- Slice ---
const employeeSlice = createSlice({
  name: "employee",
  initialState: {
    isLoading: false,
    data: null,
    isError: false,
  },
  reducers: {
    addEmployee: async (state, action) => {
      state.data.push(action.payload);
    },
    editEmployee: async (state, action) => {},
    deleteEmployee: async (state, action) => {
    },
  },
  extraReducers: (builder) => {
    builder.addCase(getListAsync.pending, (state, action) => {
      state.isLoading = false;
      state.data = action.payload;
    });
    builder.addCase(getListAsync.fulfilled, (state, action) => {
      state.isLoading = false;
      state.data = action.payload;
    });
    builder.addCase(getListAsync.rejected, (state, action) => {
      state.isError = true;
    });

    
    builder.addCase(deleteAsync.fulfilled, (state, action) => {
      state.isLoading = false;
      state.data = state.data.filter(item => item.id !== action.payload.id);
    });
    
  },
});

export const { addEmployee, editEmployee, deleteEmployee, getListEmployee } =
  employeeSlice.actions;

export default employeeSlice.reducer;
