import { configureStore } from "@reduxjs/toolkit";

// project imports
import employeeReducer from "./employeeReducer";

// ==============================|| REDUX - MAIN STORE ||============================== //

const store = configureStore({
  reducer: {
    employee: employeeReducer
  }
});

export { store };
