# Getting Started by running `npm install`

to install the dependencies and packages required for your the application

# Note: This application is built for entrance examination, do not upload to github.
