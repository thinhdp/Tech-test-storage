"""
THIS is DIRECTIONS dict description:
+------------------+-------------+--------------++---------+
| Direction | Movement Offset (dx, dy) | Effect on (x, y)  |
|-----------|-------------------------|-------------------|
| 'N' (North) | (0, 1)  | Moves up (increases y)    |
| 'S' (South) | (0, -1) | Moves down (decreases y)  |
| 'E' (East)  | (1, 0)  | Moves right (increases x) |
| 'W' (West)  | (-1, 0) | Moves left (decreases x)  |

This is ROTATIONS dict description:
+------------------+-------------+--------------+
| Current Direction | 'L'(Left) | 'R'(Right) |
+------------------+-------------+--------------+
| 'N'(North) | 'W'(West) | 'E'(East) |
| 'S'(South) | 'E'(East) | 'W'(West) |
| 'E'(East) | 'N'(North) | 'S'(South) |
| 'W'(West) | 'S'(South) | 'N'(North) |
+------------------+-------------+--------------+
"""
class Car:
    DIRECTIONS = {'N': (0, 1), 'S': (0, -1), 'E': (1, 0), 'W': (-1, 0)}
    ROTATIONS = {'N': {'L': 'W', 'R': 'E'}, 'S': {'L': 'E', 'R': 'W'}, 'E': {'L': 'N', 'R': 'S'},
                 'W': {'L': 'S', 'R': 'N'}}

    def __init__(self, name, x, y, direction, commands):
        self.name, self.x, self.y, self.direction, self.commands = name, x, y, direction, commands
        self.current_step = 0

    def move(self, field, occupied_positions):
        # Check if all commands already executed
        if self.current_step >= len(self.commands):
            return False, None, None #if true, return no collision

        command = self.commands[self.current_step]
        self.current_step += 1 #iterate every commands

        if command == 'F':
            return self.move_forward(field, occupied_positions)

        # turning left right won't hit collision
        self.direction = self.ROTATIONS[self.direction][command]
        return False, None, None

    def move_forward(self, field, occupied_positions):
        dx, dy = self.DIRECTIONS[self.direction]
        new_x, new_y = self.x + dx, self.y + dy

        if new_x in range(field[0]) and new_y in range(field[1]): #is to check if the car is fit to move
            if (new_x, new_y) in occupied_positions:
                return True, new_x, new_y

            occupied_positions.remove((self.x, self.y))
            self.x, self.y = new_x, new_y
            occupied_positions.add((new_x, new_y))
        return False, None, None


class Simulation:
    def __init__(self, field, cars):
        self.field, self.cars = field, cars

    def run(self):
        occupied_positions = {(car.x, car.y) for car in self.cars} #a record of x, y positions of the cars
        max_steps = max(len(car.commands) for car in self.cars)
        collisions = []

        print("\nYour current list of cars are:")
        for car in self.cars:
            print(f"- {car.name}, ({car.x},{car.y}) {car.direction}, {car.commands}")

        for step in range(max_steps):
            for car in self.cars:
                collision, cx, cy = car.move(self.field, occupied_positions)

                if collision:
                    for other_car in self.cars:
                        if other_car != car and (other_car.x, other_car.y) == (cx, cy):
                            collisions.append((car.name, other_car.name, cx, cy, step + 1))
                            break

        print("\nAfter simulation, the result is:\n")
        if collisions:
            for car_name, other_car_name, cx, cy, step in collisions:
                print(f"- {car_name} collides with {other_car_name} at ({cx}, {cy}) at step {step}")

        for car in self.cars:
            if not any(car.name == car_name or car.name == other_car_name for car_name, other_car_name, _, _, _ in collisions):
                print(f"- {car.name}, ({car.x},{car.y}) {car.direction}")

        # Prompt user for next action
        while True:
            choice = input("\nPlease choose from the following options:\n[1] Start over\n[2] Exit\n")

            if choice == '1':
                main()  # Restart the simulation
                break  # Ensure loop exits after calling main()
            elif choice == '2':
                print("\nExiting simulation. Goodbye!")
                exit()  # Terminate the program
            else:
                print("Invalid choice. Please enter 1 or 2.")

def input_car_details():
    cars = []
    name = input("Please enter the name of the car:\n")
    try:
        x, y, direction = input(f"Please enter initial position of car {name} in x y Direction format:").split()
        x, y = int(x), int(y)

        if direction.upper() not in {'N', 'S', 'E', 'W'}:
            print("Invalid direction. Use N, S, E, or W.")
            return[]

        commands = input(f"Please enter the commands for car {name}:").strip().upper()

        if not all(c in {'L', 'R', 'F'} for c in commands):
            print("Invalid commands. Only L, R, and F are allowed.")
            return[]

        cars.append(Car(name, x, y, direction.upper(), commands))
    except ValueError:
        print("Invalid input. Please enter x and y as integers followed by a direction.")
        return []

    return cars


def main():
    cars = []
    print("Welcome to Auto Driving Car Simulation!")
    width, height = map(int, input("Please enter the width and height of the simulation field in x y format: ").split())
    print(f"You have created a field of {width} x {height}.")

    while True:
        choice = input("\nPlease choose from the following options:\n[1] Add a car to field\n[2] Run simulation:")

        if choice == '1':
            cars.extend(input_car_details())
        elif choice == '2':
            if cars:
                simulation = Simulation((width, height), cars)
                simulation.run()
            else:
                cars.extend(input_car_details())
        else:
            print("Invalid choice. Please enter 1, 2, or 3.")
            break

        print("Your current list of cars are:")
        for car in cars:
            print(f"- {car.name}, ({car.x},{car.y}) {car.direction}, {car.commands}")


if __name__ == "__main__":
    main()
