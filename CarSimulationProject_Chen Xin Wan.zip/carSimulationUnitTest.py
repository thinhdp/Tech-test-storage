import unittest
from carSimulation import Car


class CarSimulationTestCase(unittest.TestCase):
    def setUp(self):
        self.car = Car("Ferrari", 0, 0, "N", "FFFFFFFF")

    def test_initial_position(self):
        """Test car's initial position."""
        self.assertEqual(self.car.x, 0)
        self.assertEqual(self.car.y, 0)
        self.assertEqual(self.car.direction, "N")

    def test_move_forward(self):
        occupied_positions = {(self.car.x, self.car.y)}
        collision, _, _ = self.car.move((5, 5), occupied_positions)
        self.assertEqual(self.car.x, 0)
        self.assertEqual(self.car.y, 1)
        self.assertFalse(collision)

if __name__ == '__main__':
    unittest.main()
