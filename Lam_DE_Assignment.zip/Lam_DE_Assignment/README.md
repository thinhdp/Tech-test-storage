## NOTE:

- SQL.md conatains my answers for the SQL test.
- The source code for the Raffle App is inside the folder called raffle. Please refer to [README.md](./raffle/README.md) file in that folder for details on running the app.