from src import RaffleApp

if __name__ == "__main__":
    app = RaffleApp()
    while True:
        option = input()
        if option == "1":
            app.start_new_draw()
        elif option == "2":
            print("Enter your name, no of tickets to purchase")
            name, no_of_tickets = input().split(",")
            app.buy_tickets(name, int(no_of_tickets))
        elif option == "3":
            app.run_raffle()
        else:
            app.display_main()