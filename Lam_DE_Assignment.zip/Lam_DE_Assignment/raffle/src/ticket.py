import random

class Ticket():
    def __init__(self):
        self._code = random.sample(range(1,16), 5)

    def __str__(self):
        return " ".join(map(str, self._code))

    def get_code(self):
        return self._code
    
    def set_code(self, code):
        self._code = code
        return self
    
    def compare_with(self, ticket):

        other_code = ticket.get_code()
        match_numbers = 0
        for i in range(5):
            if self._code[i] == other_code[i]:
                match_numbers += 1

        return match_numbers