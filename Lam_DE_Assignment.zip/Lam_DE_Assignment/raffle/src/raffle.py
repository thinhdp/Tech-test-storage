from .ticket import Ticket
from collections import Counter

class RaffleApp():
    def __init__(self):
        self._pot = 0
        self._status = "Draw has not started"
        self._attendees = {}
        self._winning_ticket = None
        self.display_main()

    def get_pot(self):
        return self._pot
    
    def get_attendees(self):
        return self._attendees

    def display_main(self):
        print("Welcome to My Raffle App")
        print(f"Status: {self._status}")
        print("\n[1] Start a New Draw\n[2] Buy Tickets\n[3] Run Raffle\n")

    def start_new_draw(self):
        self._pot += 100
        self._status = f"Draw is on going. Raffle pot size is ${self._pot}"
        self._attendees = {}
        print(f"New Raffle draw has been started. Initial pot size: ${self._pot}")
        print("Press any key to return to main menu")

    def buy_tickets(self, attendee, no_of_tickets):

        for i in range(no_of_tickets):
            if self._attendees.get(attendee):
                self._attendees[attendee].append(Ticket())
            else:
                self._attendees[attendee] = [Ticket()]

        # increase pot
        self._pot += (5 * no_of_tickets)
        self._status = f"Draw is on going. Raffle pot size is ${self._pot}"

        self._display_tickets(attendee, self._attendees[attendee])

    def _display_tickets(self, attendee, tickets):
        no_of_tickets = len(tickets)
        print(f"Hi {attendee}, you have purchased {no_of_tickets} tickets")
        for i, ticket in enumerate(tickets):
            print(f"Ticket {i+1}: {ticket}")

        print("\nPress any key to return to main menu")


    def run_raffle(self):
        print("Running raffle..")
        winners = self._get_winner()
        self._calculate_money(winners)
        self._attendees = {}
        self._status = "Draw has not started"

    def _get_winner(self):
        winners = {
            "Group 2": [],
            "Group 3": [],
            "Group 4": [],
            "Group 5": []
        }
        if self._winning_ticket is None:
            self._winning_ticket = Ticket()
        print(f"Winning ticket is {self._winning_ticket}")
        for attendee in self._attendees:
            for ticket in self._attendees[attendee]:
                group = self._winning_ticket.compare_with(ticket)
                if group >= 2:
                    winners[f"Group {group}"].append(attendee)

        return winners
    
    def _calculate_money(self, winners):
        rate = {
            "Group 2": 0.1,
            "Group 3": 0.15,
            "Group 4": 0.25,
            "Group 5": 0.5
        }

        for group in winners:
            if len(winners[group]) > 0:
                total_money = self._pot * rate[group]
                self._pot -= total_money
            print(f"{group} winners:")
            if len(winners[group]) > 0:
                self._display_winner(total_money, winners[group])
            else:
                print("Nil")

    def _display_winner(self, total_money, group):
        no_of_winners = len(group)
        money_for_each = total_money / no_of_winners

        winners_counter = Counter(group)

        for winner in winners_counter:
            print(f"{winner} with {winners_counter[winner]} winning ticket - ${money_for_each * winners_counter[winner]}")

    # test running raffle
    def simulate(self):
        self._winning_ticket = Ticket().set_code([2,1,4,3,5])
        self._attendees = {
            "james": [
                Ticket().set_code([2,1,4,3,5]),
                Ticket().set_code([4,12,10,6,9])
            ],
            "harry": [
                Ticket().set_code([2,1,4,3,9])
            ],
            "lily": [
                Ticket().set_code([2,1,3,5,7])
            ],
            "ron": [
                Ticket().set_code([2,1,4,6,9])
            ]
        }
        self._pot = 125
    
    def test(self):
        return self._get_winner()