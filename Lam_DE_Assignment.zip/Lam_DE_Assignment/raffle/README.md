## For running the app:
```
python main.py
```

## For running unit tests:
```
cd tests
python test.py -v
```