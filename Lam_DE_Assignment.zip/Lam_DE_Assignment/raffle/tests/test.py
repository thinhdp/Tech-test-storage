import unittest
from context import src

class TestRaffleApp(unittest.TestCase):
    app = src.RaffleApp()

    def test_1_start_new_draw(self):
        TestRaffleApp.app.start_new_draw()
        self.assertEquals(TestRaffleApp.app.get_pot(), 100)

    def test_2_buy_tickets(self):
        TestRaffleApp.app.buy_tickets("james",2)
        self.assertIsNotNone(TestRaffleApp.app.get_attendees().get("james"))
        self.assertEquals(TestRaffleApp.app.get_pot(), 110)

    # one person multiple purchases
    def test_3_buy_tickets_2(self):
        TestRaffleApp.app.buy_tickets("james",3)
        self.assertEquals(TestRaffleApp.app.get_pot(), 125)
        self.assertEquals(len(TestRaffleApp.app.get_attendees().get("james")), 5)

    # more people to purchase:
    def test_4_buy_tickets_3(self):
        TestRaffleApp.app.buy_tickets("harry",3)
        self.assertIsNotNone(TestRaffleApp.app.get_attendees().get("harry"))
        self.assertEquals(len(TestRaffleApp.app.get_attendees()), 2)

    def test_5_run_raffle(self):
        TestRaffleApp.app.simulate()
        winners = TestRaffleApp.app.test()
        self.assertEquals(winners["Group 2"], ["lily"])
        self.assertEquals(winners["Group 3"], ["ron"])
        self.assertEquals(winners["Group 4"], ["harry"])
        self.assertEquals(winners["Group 5"], ["james"])

if __name__ == "__main__":
    unittest.main()