## Question 1:
``` 
SELECT first_name, last_name, email
FROM Customers;
```

## Question 2:
```
SELECT product_name, unit_price
FROM Products
WHERE unit_price > 50
ORDER BY unit_price DESC;
```

## Question 3:
```
SELECT c.first_name, o.total_amount
FROM Orders o
JOIN Customers c ON c.customer_id = o.customer_id;
```

## Question 4:
```
UPDATE Products
SET unit_price = unit_price * 1.1
WHERE category = "Electronics";
```

