from account.bank_account import BankAccount

def main():
    account = BankAccount()
    print("Welcome to AwesomeGIC Bank! What would you like to do?")
    while True:
        print("\nPlease enter your choice:")
        print("[D]eposit\n[W]ithdraw\n[P]rint statement\n[Q]uit")
        choice = input(">").strip().lower()

        if choice == 'd':
            amount = float(input("Please enter the amount to deposit:\n>"))
            account.deposit(amount)

        elif choice == 'w':
            amount = float(input("Please enter the amount to withdraw:\n>"))
            account.withdraw(amount)

        elif choice == 'p':
            account.print_statement()

        elif choice == 'q':
            print("Thank you for banking with AwesomeGIC Bank.\nHave a nice day!")
            break
        else:
            print("Invalid input. Please enter another value")


if __name__ == "__main__":
    main()