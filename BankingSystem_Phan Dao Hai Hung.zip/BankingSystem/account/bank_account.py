import datetime

class BankAccount:
    def __init__(self):
        self.balance = 0.0
        self.transactions = []

    def deposit(self, amount):
        self.balance += amount
        self.transactions.append((datetime.datetime .now(), amount, self.balance))
        print(f"\nThank you. {amount:.2f} has been deposited to your account.")

    def withdraw(self, amount):
        self.balance -= amount
        self.transactions.append((datetime.datetime.now(), amount, self.balance))
        print(f"\nThank you. {amount:.2f} has been withdraw to your account.")

    def print_statement(self):
        rows = []
        for date, amount, balance in self.transactions:
            date_str = date.strftime('%d %b %Y %I:%M:%S%p')
            rows.append((date_str, f"{amount:.2f}", f"{balance:.2f}"))

        date_width = max(len("Date"), max(len(row[0]) for row in rows)) if rows else len("Date")
        amount_width = max(len("Amount"), max(len(row[1]) for row in rows)) if rows else len("Amount")
        balance_width = max(len("Balance"), max(len(row[2]) for row in rows)) if rows else len("Balance")

        header = f"\n{'Date':<{date_width}} | {'Amount':>{amount_width}} | {'Balance':>{balance_width}}"
        print(header)
        print("-" * len(header))

        for row in rows:
            print(f"{row[0]:<{date_width}} | {row[1]:>{amount_width}} | {row[2]:>{balance_width}}")
