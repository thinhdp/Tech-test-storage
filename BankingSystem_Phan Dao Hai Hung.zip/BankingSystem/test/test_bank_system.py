import pytest
from account.bank_account import BankAccount


@pytest.fixture
def account():
    return BankAccount()

def test_initial_balance_is_zero(account):
    assert account.balance == 0

def test_deposit_positive_amount(account):
    account.deposit(100)
    assert account.balance == 100
    assert len(account.transactions) == 1

def test_deposit_negative_amount(account):
    account.deposit(100)
    account.deposit(-50)
    assert account.balance == 50
    assert len(account.transactions) == 2

def test_withdraw_less_than_balance(account):
    account.deposit(200)
    account.withdraw(50)
    assert account.balance == 150
    assert len(account.transactions) == 2

def test_withdraw_more_than_balance(account):
    account.deposit(100)
    account.withdraw(200)
    assert account.balance == -100
    assert len(account.transactions) == 2

def test_withdraw_negative_amount(account):
    account.deposit(100)
    account.withdraw(-30)
    assert account.balance == 130
    assert len(account.transactions) == 2
