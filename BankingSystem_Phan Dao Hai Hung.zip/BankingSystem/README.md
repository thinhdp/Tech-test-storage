# Banking System

This is a simple banking system implemented in Python. It allows users to deposit money, withdraw money, and print a transaction statement. The project also includes unit tests to ensure the correctness of the functionality.

## Features

- Deposit money into the account.
- Withdraw money from the account.
- Print a transaction statement with a history of deposits and withdrawals.
- Unit tests for core functionalities.

## How to Run

1. Clone the repository to your local machine.
2. Ensure you have Python 3.9 or later installed.
3. Install `pipenv` with command line:
```bash
brew install pipenv
```
4. Install dependence using this command line:
```bash
pipenv install
```
5. Run the application using the following command:
```bash
pipenv run main
```
6. Run unit test using this command line:
```bash
pipenv run test
```
