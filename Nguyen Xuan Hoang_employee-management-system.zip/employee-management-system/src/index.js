import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import store, {persistor} from './redux/store'
import { Provider } from 'react-redux'
import { ToastContainer } from 'react-toastify';
import "react-toastify/dist/ReactToastify.min.css";
import { PersistGate } from 'redux-persist/lib/integration/react';

ReactDOM.render(
  <React.StrictMode>
    <Provider store={store}>
      <PersistGate  persistor={persistor}>
      <App />
      <ToastContainer 
        position="top-right"
        autoClose={2000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
      </PersistGate>
      
    </Provider>
  </React.StrictMode>,
  document.getElementById('root')
);


