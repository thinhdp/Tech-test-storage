export const capitalizeString = (str) => {
    if (!str) return '';
    return `${str[0].toUpperCase()}${str.slice(1)}`
}
export const getGenderColor = (gender) => {
    if (gender === 'Male') return 'green'
    if (gender === 'Female') return 'red'
    return 'goldenrod'
}