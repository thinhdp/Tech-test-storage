import { BrowserRouter, Redirect, Route, Switch } from "react-router-dom";
import ListPage from "./modules/Dashboard/Pages/ListPage";
import AddEditPage from "./modules/Dashboard/Pages/AddEditPage";


function App() {
  return (
    <div>
      <BrowserRouter>
        <Switch >
          <Redirect exact from="/" to="/employee/list" />
          <Route path="/employee/list" component={ListPage} />
          <Route path="/employee/add" component={AddEditPage} />
          <Route path="/employee/edit/:id" component={AddEditPage} />
        </Switch>
      </BrowserRouter>
    </div>
  );
}

export default App;
