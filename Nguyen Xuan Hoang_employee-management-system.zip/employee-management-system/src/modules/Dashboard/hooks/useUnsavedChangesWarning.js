import React, { useEffect, useState } from 'react'
import { Prompt } from 'react-router-dom'


const useUnsavedChangesWarning = (message = "Form has been modified. You will lose your unsaved changes. Are you sure you want to close this form?") => {
    const [isDirty, setIsDirty] = useState(false)
    useEffect(() => {
        //detecting browser closing
        window.onbeforeunload = isDirty && (() => message)
        return () => {
            window.onbeforeunload = null;
        }
    }, [isDirty])
    const routerPrompt = <Prompt when={isDirty} message={message} />
    return [routerPrompt, () => setIsDirty(true), () => setIsDirty(false)]
}

export default useUnsavedChangesWarning