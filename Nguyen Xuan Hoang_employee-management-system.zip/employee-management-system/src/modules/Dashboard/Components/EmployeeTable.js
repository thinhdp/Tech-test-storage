import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  makeStyles,
} from "@material-ui/core";
import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";
import { deleteEmployee } from "../../../redux";
import { capitalizeString, getGenderColor } from "../../../utils/common";

const useStyles = makeStyles((theme) => ({
  root: {
    position: "relative",
    paddingTop: theme.spacing(1),
    marginLeft: theme.spacing(2),
    marginRight: theme.spacing(2),
  },
  edit: {
    marginRight: theme.spacing(1),
  },
  loading: {
    position: "absolute",
    top: theme.spacing(-1),
    width: "100%",
  },
}));

const EmployeeTable = ({ employees }) => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const [open, setOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);

  const handleClose = () => {
    setOpen(false);
  };
  const handleRemoveClick = (employee) => {
    setSelectedEmployee(employee);
    setOpen(true);
  };

  const handleRemoveConfirm = (employee) => {
    dispatch(deleteEmployee(employee.id));
    toast.success("Remove Employee Successfully");
    setOpen(false);
  };
  return (
    <Box className={classes.root} >
      <Paper elevation={3}>
      <TableContainer>
        <Table className={classes.table} size="small" aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell>No.</TableCell>
              <TableCell>First Name</TableCell>
              <TableCell>Last Name</TableCell>
              <TableCell>Email address</TableCell>
              <TableCell>Phone number</TableCell>
              <TableCell>Gender</TableCell>
              <TableCell align="center">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {employees.map((employee) => (
              <TableRow key={employee.id}>
                <TableCell>{employee.id}</TableCell>
                <TableCell>{capitalizeString(employee.firstName)}</TableCell>
                <TableCell>{capitalizeString(employee.lastName)}</TableCell>
                <TableCell>{employee.email}</TableCell>
                <TableCell>{employee.phoneNumber}</TableCell>
                <TableCell><Box color={getGenderColor(employee.gender)}>
                  {employee.gender}
                </Box></TableCell>
                <TableCell align="center">
                <Link to={`/employee/edit/${employee.id}`} style={{ textDecoration: "none" }}>
                  <Button
                    size="small"
                    className={classes.edit}
                    color="primary"
                  >
                    Edit
                  </Button>
                </Link>
                  <Button
                    color="secondary"
                    onClick={() => handleRemoveClick(employee)}
                  >
                    Remove
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      </Paper>
      {/* Remove Dialog */}
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">Remove an employee?</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            Are you sure you want to remove an employee named "
            {selectedEmployee?.firstName} {selectedEmployee?.lastName}"? <br />
            This action can&apos;t be undo.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="default" variant="outlined">
            Cancel
          </Button>

          <Button
            onClick={() => handleRemoveConfirm(selectedEmployee)}
            color="secondary"
            variant="contained"
            autoFocus
          >
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default EmployeeTable;
