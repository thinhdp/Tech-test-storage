import { yupResolver } from "@hookform/resolvers/yup";
import {
  Box,
  Button,
  FormControl,
  FormControlLabel,
  FormLabel,
  Grid,
  Radio,
  RadioGroup,
  TextField,
  makeStyles,
} from "@material-ui/core";
import React, { useEffect, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { toast } from "react-toastify";
import { v4 as uuidv4 } from "uuid";
import { addEmployee, updateEmployee } from "../../../redux";
import useUnsavedChangesWarning from "../hooks/useUnsavedChangesWarning";
import { schema } from "../schema";

const useStyles = makeStyles((theme) => ({
  textError: {
    color: "red",
    marginLeft: "1px",
    fontFamily: "Roboto"
  },
}));

const EmployeeForm = ({ isEdit, selectedEmployee }) => {
  const dispatch = useDispatch();
  const classes = useStyles();
  const history = useHistory();
  const id = selectedEmployee?.id;
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [gender, setGender] = useState("Female");
  const [Prompt, setIsDirty, setPristine] = useUnsavedChangesWarning();

  const {
    register,
    handleSubmit,
    formState: { errors },
    control,
  } = useForm({
    resolver: yupResolver(schema),
    values: {
      firstName,
      lastName,
      email,
      phoneNumber,
      gender,
    },
  });

  useEffect(() => {
    if (isEdit) {
      setFirstName(selectedEmployee?.firstName);
      setLastName(selectedEmployee?.lastName);
      setEmail(selectedEmployee?.email);
      setPhoneNumber(selectedEmployee?.phoneNumber);
      setGender(selectedEmployee?.gender);
    }
  }, [isEdit, selectedEmployee]);

  const handleSubmitForm = () => {
    if (isEdit) {
      const updatedEmployee = {
        id,
        firstName,
        lastName,
        email,
        phoneNumber,
        gender,
      };
      dispatch(updateEmployee(id, updatedEmployee));
      setPristine();
      toast.success("Update Employee Successfully");
      history.push("/employee/list");
    } else {
      const id = uuidv4();
      const newEmployee = {
        id,
        firstName,
        lastName,
        email,
        phoneNumber,
        gender,
      };
      dispatch(addEmployee(newEmployee));
      setPristine();
      toast.success("Add New Employee Successfully");
      history.push("/employee/list");
    }
  };
  return (
    <Box>
      <form onSubmit={handleSubmit(handleSubmitForm)}>
        <Grid container spacing={1}>
          <Grid item xs={12}>
            <TextField
              placeholder="Enter first name"
              label="First Name"
              variant="outlined"
              fullWidth
              {...register("firstName")}
              onChange={(e) => {
                setFirstName(e.target.value);
                setIsDirty();
              }}
              value={firstName}
              error={!!errors.firstName?.message}
            />
            <p className={classes.textError}>
              {errors.firstName?.message}
            </p>
          </Grid>
          <Grid item xs={12}>
            <TextField
              placeholder="Enter last name"
              label="Last Name"
              variant="outlined"
              fullWidth
              {...register("lastName")}
              onChange={(e) => {
                setLastName(e.target.value);
                setIsDirty();
              }}
              value={lastName}
              error={!!errors.lastName?.message}
            />
            <p className={classes.textError}>
              {errors.lastName?.message}
            </p>
          </Grid>
          <Grid item xs={12}>
            <TextField
              placeholder="Enter email name"
              label="Email"
              variant="outlined"
              fullWidth
              {...register("email")}
              onChange={(e) => {
                setEmail(e.target.value);
                setIsDirty();
              }}
              value={email}
              error={!!errors.email?.message}
            />
            <p className={classes.textError}>
              {errors.email?.message}
            </p>
          </Grid>
          <Grid item xs={12}>
            <TextField
              type="string"
              placeholder="Enter phone number"
              label="Phone"
              variant="outlined"
              fullWidth
              {...register("phoneNumber")}
              onChange={(e) => {
                setPhoneNumber(e.target.value);
                setIsDirty();
              }}
              value={phoneNumber}
              error={!!errors.phoneNumber?.message}
            />
            <p className={classes.textError}>
              {errors.phoneNumber?.message}
            </p>
          </Grid>
          <Grid item xs={12}>
            <FormControl>
              <FormLabel id="demo-radio-buttons-group-label">Gender</FormLabel>
              <Controller
                rules={{ required: true }}
                control={control}
                name="promoting2"
                {...register("gender")}
                render={({ field }) => (
                  <RadioGroup
                    {...field}
                    defaultValue={isEdit ? selectedEmployee?.gender : "Female"}
                    row
                    onChange={(e) => {
                      setGender(e.target.value);
                      setIsDirty();
                    }}
                    value={gender}
                    error={!!errors.gender?.message}
                  >
                    <FormControlLabel
                      value="Female"
                      control={<Radio />}
                      label="Female"
                    />
                    <FormControlLabel
                      value="Male"
                      control={<Radio />}
                      label="Male"
                    />
                  </RadioGroup>
                )}
              />
            </FormControl>
            <p className={classes.textError}>
              {errors.gender?.message}
            </p>
          </Grid>
          <Grid item xs={12}>
            <Button type="submit" variant="contained" color="primary" fullWidth>
              &nbsp; Submit
            </Button>
          </Grid>
        </Grid>
      </form>
      {Prompt}
    </Box>
  );
};

export default EmployeeForm;
