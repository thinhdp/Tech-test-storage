import { Box, Button, Typography, makeStyles } from "@material-ui/core";
import React from "react";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import EmployeeTable from "../Components/EmployeeTable";

const useStyles = makeStyles((theme) => ({
  root: {
    position: "relative",
  },
  titleContainer: {
    display: "flex",
    flexFlow: "row nowrap",
    justifyContent: "space-between",
    alignItems: "center",
    paddingLeft: theme.spacing(2),
    paddingRight: theme.spacing(2),
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(2),
  },
  loading: {},
}));
function ListPage() {
  const classes = useStyles();
  const { employees } = useSelector((state) => state.employees);
  
  return (
    <Box className={classes.root}>
      <Box className={classes.titleContainer}>
        <Typography variant="h4">Employee Management</Typography>
          <Link to={`/employee/add`} style={{ textDecoration: "none" }}>
          <Button variant="contained" color="primary">
              Add new employee
          </Button>
        </Link>
      </Box>
      <EmployeeTable
        employees={employees}
      />
      
    </Box>
  );
}

export default ListPage;
