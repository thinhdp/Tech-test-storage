import {
  Box,
  Button,
  Card,
  CardContent,
  Paper,
  Typography,
  makeStyles,
} from "@material-ui/core";
import { ChevronLeft } from "@material-ui/icons";
import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useHistory, useParams } from "react-router-dom";
import EmployeeForm from "../Components/EmployeeForm";

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    justifyContent: "center",
  },
  paper: {
    marginTop: "80px",
  },
  card: {
    maxWidth: 450,
    padding: "0px 5px",
  },
  buttonGoBack: {
    backgroundColor: "transparent",
    marginTop: 10,
  },
  textGoBack: {
    display: "flex",
    alignItems: "center",
    maxWidth: 200,
    color: "#f50057",
    textDecoration: "underline",
  },
  boxCardContent: {
    alignItems: "center",
  },
  textTitle: {
    display: "flex",
    justifyContent: "center",
  },
}));

const AddEditPage = () => {
  const { id } = useParams();
  const classes = useStyles();
  const history = useHistory();
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const { employees } = useSelector((state) => state.employees);
  const employee = employees.find((employee) => employee.id === id);

  useEffect(() => {
    setSelectedEmployee(employee);
  }, [employee]);

  const handleGoBack = () => {
    history.push("/employee/list");
  };
  const isEdit = Boolean(id);
  return (
    <Box className={classes.root}>
      <Paper elevation={4} className={classes.paper}>
        <Card className={classes.card}>
          <Button onClick={handleGoBack} className={classes.buttonGoBack}>
            <Typography variant="caption" className={classes.textGoBack}>
              <ChevronLeft /> Back to Employee list
            </Typography>
          </Button>
          <CardContent>
            <Box className={classes.boxCardContent}>
              <Typography variant="h4" className={classes.textTitle}>
                {isEdit ? "Edit employee info" : "Add new employee"}
              </Typography>
            </Box>

            <Box mt={3}>
              <EmployeeForm
                isEdit={isEdit}
                selectedEmployee={selectedEmployee}
              />
            </Box>
          </CardContent>
        </Card>
      </Paper>
    </Box>
  );
};

export default AddEditPage;
