import * as yup from "yup";
const phoneRegExp = /^\+65(6|8|9)\d{7}$/;
export const schema = yup.object().shape({
    firstName: yup
      .string()
      .required("Please Enter Your First Name")
      .min(6)
      .max(10),
    lastName: yup
      .string()
      .required("Please Enter Your Last Name")
      .min(6)
      .max(10),
    email: yup.string().email().required("Please Enter Your Email"),
    phoneNumber: yup
      .string()
      .required("Please Enter Your Phone Number")
      .matches(
        phoneRegExp,
        "Phone number is not valid, make sure you entered valid SG phone number started with +65"
      ),
    gender: yup
      .string()
      .oneOf(["Male", "Female"], "Please select either male or female.")
      .required("Please select gender."),
  });