import { v4 as uuidv4 } from "uuid";
const employeesData = [
  {
    id: uuidv4(),
    firstName: 'Susan',
    lastName: 'Jordon',
    email: 'susan@example.com',
    phoneNumber: '0123456789',
    gender: 'Female'
  },
  {
    id: uuidv4(),
    firstName: 'Adrienne',
    lastName: 'Doak',
    email: 'adrienne@example.com',
    phoneNumber: '0123456789',
    gender: 'Female'
  },
  {
    id: uuidv4(),
    firstName: 'Rolf',
    lastName: 'Hegdal',
    email: 'rolf@example.com',
    phoneNumber: '0123456789',
    gender: 'Male'
  },
  {
    id: uuidv4(),
    firstName: 'Kent',
    lastName: 'Rosner',
    email: 'kent@example.com',
    phoneNumber: '0123456789',
    gender: 'Male'
  },
  {
    id: uuidv4(),
    firstName: 'Arsenio',
    lastName: 'Grant',
    email: 'arsenio@example.com',
    phoneNumber: '0123456789',
    gender: 'Male'
  },
  {
    id: uuidv4(),
    firstName: 'Laurena',
    lastName: 'Lurie',
    email: 'laurena@example.com',
    phoneNumber: '0123456789',
    gender: 'Female'
  },
  {
    id: uuidv4(),
    firstName: 'George',
    lastName: 'Tallman',
    email: 'george@example.com',
    phoneNumber: '0123456789',
    gender: 'Male'
  },
  {
    id: uuidv4(),
    firstName: 'Jesica',
    lastName: 'Watlington',
    email: 'jesica@example.com',
    phoneNumber: '0123456789',
    gender: 'Female'
  },
  {
    id: uuidv4(),
    firstName: 'matthew',
    lastName: 'warren',
    email: 'matthew@example.com',
    phoneNumber: '0123456789',
    gender: 'Male'
  },
  {
    id: uuidv4(),
    firstName: 'lyndsey',
    lastName: 'follette',
    email: 'lyndsey@example.com',
    phoneNumber: '0123456789',
    gender: 'Female'
  }
];

export { employeesData };
